//==This code is part of the Multi-scale Cardiac Codelling Framework=======================//
//======== Developed by Michael Colman; m.a.colman@leeds.ac.uk ============================//
//== This specific instance is for structurally-detailed modelling ========================//
//
//  COPYRIGHT MICHAEL A. COLMAN 2017. THIS SOFTWARE IS PROVIDED OPEN SOURCE ===============//
//  AND MAY BE FREELY USED, DISTRIBUTED AND UPDATED, PROVIDED: ============================//
//  (i) THE BELOW CITATIONS ARE MADE AS APPOPRIATE; =======================================//
//  (ii) THIS TEXT IS RETAINED WITHIN THE CODE OR ASSOCIATED WITH IT. ANY =================//
//  INTENDED COMMERCIAL USE OF THIS SOFTWARE MUST BE BY EXPRESS PERMISSION ================//
//  OF MICHAEL A. COLMAN ONLY.  IN NO EVENT ARE THE COPYRIGHT HOLDERS =====================//
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY OR ====================//
//  CONSEQUENTIAL DAMAGES ASSOCIATED WITH USE OF THIS SOFTWARE. ===========================//
//
//  ANY use of this code MUST cite this associated paper: A Computational =================//
//  Model of Spatio-Temporal Cardiac Intracellular Calcium Handling with ==================//
//  Realistic Structure and Spatial Flux Distribution from Sarcoplasmic ===================//
//  Reticulum and T-tubule Reconstructions PLOS Comp Biol. 2017 ===========================//
//
//  Use of the structural datasets provided MUST also cite ================================//
//  Pinali C et al Circ Res. 2013 Nov 8;113(11):1219. =====================================//
//
//  Use of the implementation of the ORd ionic cell model MUST cite the original ==========//
//  paper: O'Hara T. et al PLoS Comput Biol. 2011 May;7(5):e1002061. ======================//
//  PLEASE ALSO SEE TEXT AT THE TOP OF lib/memrbane_ord_currents.cpp FOR THEIR ============//
//  OWN STATEMENT REGARDING USE OF THEIR MODEL. ===========================================//
//
//  The Ca handling model uses equations from Shiferaw Y. et al Biophys J. 2003 ===========//
//  Dec;85(6):3666 and Shannon TR et al Biophys J. 2004 Nov;87(5):3351., ==================//
//  as well as using approaches from Restrepo JG et al Biophys J. 2008 Oct;95(8):3767 =====//
//  and Nivala M et al Front Physiol. 2012;3:114: =========================================// 
//  It would also be polite to cite those papers.==========================================//
//
//  =======================================================================================//
//  ******* PLEASE CHECK FOR UPDATES AND FIXES ON http://physicsoftheheart.com and ********//
//  **** Github: https://github.com/michaelcolman/CODE---PLOS-Comp-Biol-2017-Model-SR *****//
//  ******* This version: v1, provided with publication, 25/08/2017. **********************//
//  ******* v1.1 provided with proof: CORRECTED linescan out error ************************//
//  =======================================================================================//

#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <cstring>
#include <time.h>

#include "lib/Params.h"
#include "lib/Membrane.h"
#include "lib/Arguments.h"
#include "lib/Het_and_modulation.h"
#include "lib/CRU.h"
#include "lib/FDM.h"
#include "lib/Intracellular_structure.h"
#include "lib/myofilament.hpp"

using namespace std;

// Data output functions
void output_membrane(ostream& out, double sim_time, Current_variables currents, State_variables state, double Vm);
void output_excitation_properties(ostream& out, double sim_time, Current_variables currents, State_variables state, double Vm);
void output_Ca(ostream& out, double sim_time, Ca_variables Ca, CRU_averages cru, double Force, double Vm);
void output_RyR(ostream& out, double sim_time, CRU_averages cru, int N);
void vtk_3D_output(const char *string, double *variable, FDM_variables fdm, int count, int *geo);
void array_output(const char *string, double *variable, int Ncell, int count);
void linescan_out_X(ostream& out, FDM_variables fdm, double * variable, int y, int z);
void linescan_out_Y(ostream& out, FDM_variables fdm, double * variable, int x, int z);
void linescan_out_Z(ostream& out, FDM_variables fdm, double * variable, int x, int y);
// End Data output functions

int main(int argc, char *argv[])
{
    // First, read in the path for the geometry and state files=======
    char PATH[1000];
    FILE *path_in;
    path_in = fopen("PATH.txt", "r");
    if (path_in == NULL)
    {
        printf("!!ERROR!!:::Cannot open \"PATH.txt\"\n");
        exit(1);
    }
    fscanf(path_in,"%[^\n]", PATH);
    printf("\n\nPath for geometry and state files is %s\n", PATH);
    fclose(path_in);
    // End read path ===============================================//

    // Output model type to screen
    printf("\n\n");
    printf("*****************************************************************************\n");
    printf("** Code for multi-scale simulation of cardiac cellular and tissue dynamics **\n");
    printf("************ Version: SINGLE CELL MODEL :: Full 3D structural ***************\n");
    printf("***************************no sub-space version******************************\n");
    printf("\n\n");

    // Command line arguments / settings handling ====================
    // This happens here, as some parameters (e.g. Array sizes, total time) depend on input arguments
    // lib/Arguments.c
    Argument_parameters Argin;                                              // Initiate struct containing command line arguments
    Argument_handling(argc, argv, &Argin);                                  // Read command line arguments into struct
    Argument_screen_output(Argin, "Single_cell_structural_3D");             // Output settings to screen

    // Error check Ionic model exists
    if (strcmp(Argin.Ionic_model, "ORd") == 0);
    else 
    {
        printf("***ERROR %s- Ionic model invalid***\n\n", Argin.Ionic_model);
        exit(EXIT_FAILURE);
    }
    // End command line arguments / settings handling ================

    // Variable declaration ==========================================
    // Simulation time variables
    double                  sim_time;       // time in simulation land, ms 
    double                  total_time;     // total time in simulation land, ms
    double                  stim_period;    // period of time to apply stimulus (S1)
    double                  dt;             // integration time step, ms
    int                     beats;          // Number of beats
    double                  BCL;            // basic pacing cycle length
    double                  S2;             // S2 stimulus interval

    // output loop counters
    int                     time_counter    = 0; // counter of iterations over dt 
    int                     outcount        = 0; // counter of interger times in ms for outputs

    // Initialise structs
    Cell_params             params;     // lib/Params.h       contains all parameters
    State_variables         state;      // lib/Membrane.h     contains all membrane state variables (time dependent)
    Current_variables       currents;   // lib/Membrane.h     contains all non-time dependent variables (e.g., steady state, scaling factors)

    // Ca handling structs
    Ca_variables            Ca;          // lib/CRU.h        contains the variables for Ca concentration in different compartments
    SR_fluxes               *SERCA;      // lib/CRU.h        contains the SR flux variables (Jup/leak || N_SR)
    Membrane_fluxes         *MEM;        // lib/CRU.h        contains membrane Ca flux variables
    Dyad_variables          *Dyad;       // lib/CRU.h        contains dyad flux variables (Jrel, JCaL)
    CRU_averages            CRU;         // lib/CRU.h        contains the averages of spatial variables

    FDM_variables           FDM_Cyto;   // struct which contains parameters and variables for FDM || only need one here as sizes/neighbours same for all domains in compartmentalised model
    FDM_variables           FDM_SR;     // SR may have different structure, so needs its own FDM || ss and cyto are the same

    Intracellular_structural_parameters ST; // contains parametrs for full sturct, such as geoemtry name etc

    // trpn and force lib/myofilament.cpp
    Myofilament             *myofil;
    double                  Force;

    // Declare voltage
    double Vm;
    printf("\nVariables declared...\n");
    // End variable declaration ====================================//

    // Create output files ===========================================
    ofstream out_cu("Whole_cell_out/Currents.dat"); // Contains all membrane current outputs
    ofstream out_ex("Whole_cell_out/Excitation.dat"); // Contains all excitation properties outputs (e.g. APD, dvdt)
    ofstream out_cru("Whole_cell_out/CRU.dat"); // Contains all Ca handling ourputs (Ca, RyR, ICaL, Iup etc)
    ofstream out_ryr("Whole_cell_out/RyR_states.dat"); // Contains state occupancy for RyR model
    ofstream out_lsZ("Whole_cell_out/Ca_linescan_Z.dat"); // linescan in the z (longitudinal) direction
    //ofstream out_lsY("Whole_cell_out/Ca_linescan_Y.dat"); // uncomment if you want these
    ofstream out_lsX("Whole_cell_out/Ca_linescan_X.dat");
    if (out_cu == NULL)
    {
        printf("!!ERROR!!:::Must have 'Whole_cell_out' directory to run\n");
        exit(1);
    }
    printf("Output files created...\n");
    // End output files ============================================//

    // Full structural spatial model setup ===========================
    // All functions in lib/Intracellular_structure.cpp
    ST.red_factor = Argin.red_factor;
    set_structure_geometry_parameters(&ST, Argin.Structure_model, Argin.Dyad_density);  // this is where dimension sizes, geometry files etc are specified
    set_and_allocate_FDM_arrays(&ST, &FDM_Cyto, &FDM_SR);                               // allocate arrays size NX*NY*NZ
    create_or_read_geometries(&ST, &FDM_Cyto, &FDM_SR, PATH, Argin.Structure_model);    // what is says
    allocate_Ncell_arrays_and_set_linear_geometry_index(&ST, &FDM_Cyto, &FDM_SR);       // allocate arrays size Ncell ; populate the linear to 3D relation index
    set_dyad_and_membrane_maps(&ST, FDM_Cyto, PATH, Argin.Structure_model);             // load or set the maps for different geometries || here, all in 3D space

    // FDM neighbour setup lib/FDM.cpp
    FDM_set_neighbours_3D(&FDM_Cyto);
    if (strcmp(ST.nsr_neighbour_file, "None") == 0) FDM_set_neighbours_3D(&FDM_SR);
    else read_SR_neighbours(&ST, &FDM_SR, PATH);
    printf("Neighbours set...\n");

    // And now Ca and variables  lib/CRU.cpp
    Ca_array_allocation_struct(FDM_Cyto.Ncell, FDM_SR.Ncell, ST.Ndyads, &Ca); // allocates Ca, reac and buffering arrays
    Dyad            = new Dyad_variables[ST.Ndyads];
    SERCA           = new SR_fluxes[ST.NSR];
    MEM             = new Membrane_fluxes[ST.NMem];
    array_allocation_indexes(&ST);
    printf("Ca variable arrays allocated...\n");

    // trpn and force
    myofil          = new Myofilament[FDM_Cyto.Ncell];
    for (int i =0; i < FDM_Cyto.Ncell; i++) myofil[i].LSODA_set();

    // Set the indexes
    set_geometry_relation_indexes(&ST, &FDM_Cyto, &FDM_SR, Argin.Structure_model);      // Sets the index relations between different geometries, in 1D space
    array_deallocation_maps(&ST);                                                       // Delete maps, as only needed them to create indexes

    // ratio params
    params.N_mem_dyads          = ((float)ST.NMem/(float)ST.Ndyads);
    params.N_cyto_mem           = ((float)FDM_Cyto.Ncell/(float)ST.NMem);
    params.N_cyto_SR            = ((float)FDM_Cyto.Ncell/(float)FDM_SR.Ncell);

    printf("Ratios: mem/dyads = %f\tcyto/mem = %f\tcyto/SR = %f\n", params.N_mem_dyads, params.N_cyto_mem, params.N_cyto_SR);

    set_D_dx(&FDM_Cyto, ST.dx, ST.D, 0);                        // Set FDM properties from tissue settings || lib/FDM.cpp
    set_D_isotropic(&FDM_Cyto);                                 // Set D from FDM properties || lib/FDM.cpp
    set_D_dx(&FDM_SR, ST.dx, ST.D, 0);                          // Set FDM properties from tissue settings || lib/FDM.cpp
    set_D_isotropic(&FDM_SR);                                   // Set D from FDM properties || lib/FDM.cpp
    // End Full struct model setup =================================//

    // Variable and parameter setup ==================================
    // sim time and integration step ===
    sim_time                    = 0.0;      // ms
    dt                          = 0.01;     // ms
    BCL                         = Argin.BCL;// ms
    S2                          = Argin.S2;
    Set_sim_time_variables_from_arguments(Argin, &total_time, &stim_period, BCL, &beats); // lib/Arguments.c
    for (int i =0; i < FDM_Cyto.Ncell; i++) myofil[i].dt_myof = dt; // dt for LSODA solver same as for whole model
    //printf("Sim time variables set...\n");
    // End sim time and step setup ===//

    // Initialise parameters  
    // Set all defaults (e.g. current conductances, constants such as Faraday constant, membrane capacitance)
    Set_params_default(&params, ST.red_factor); // lib/Params.c
    set_params_full_struct_no_SS(&params, Argin.Ionic_model); // lib/Params.c
    //update_default_params(&params, Argin.Ionic_model); // lib/Params.c || if you add an ionic model, add details here and uncomment
    //printf("Default parameters set...\n");

    // Default scale factors  lib/Het_and_modulation.c
    // Sets multipliers to 1.0 and shifts to 0.0. Set for all possible scale factors (thus all models)
    set_scale_factor_defaults_integrated(&currents, &Dyad[0], &SERCA[0], &MEM[0]);
    //printf("Heterogeneity and modulation defaults set...\n");

    // Set params determined by input args directly
    // Sets: Ionic model, ISO, Remodelling, Drug, celltype, direct control scale factors
    Set_variables_from_arguments_integrated(Argin, &currents, &Dyad[0], &SERCA[0], &MEM[0]); // lib/Het_and_modulation.c || Sets some model-dependent defaults
    //printf("Parameters set from command line arguments...\n");

    // Set scale factors based :: Ionic model dependent functions 
    // set_scale_factors_het_X :: sets the heterogeneity parameters; difference to "baseline" model (whichever the params correspond to)
    // Set_modulation_params_X :: sets the modulation parameters; remodelling, autonomic, drug; multiplies the defaults
    set_scale_factors_het_integrated(params, &currents, &Dyad[0], &SERCA[0], &MEM[0], currents.Ionic_model); // lib/Het_and_modulation.c
    set_scale_factors_modulation_integrated(&currents, &Dyad[0], &SERCA[0], &MEM[0], currents.ISO, currents.Remodelling, currents.Drug, currents.Ionic_model); // lib/Het_and_modulation.c
    //printf("Heterogeneity and modulation parameters set...\n");

    // Set local values to global values, as in general these are not heterogeneous within the cell; can add easily enough here if desired
    for (int i = 1; i < ST.Ndyads; i++) 
    {
        Dyad[i].RyR_Po          = Dyad[0].RyR_Po;
        Dyad[i].LTCC_Po         = Dyad[0].LTCC_Po;
        Dyad[i].RyR_expression  = Dyad[0].RyR_expression;
        Dyad[i].LTCC_expression = Dyad[0].LTCC_expression;
    }
    for (int i = 1; i < ST.NSR; i++)
    {
        SERCA[i].Gup            = SERCA[0].Gup;
        SERCA[i].Gleak          = SERCA[0].Gleak;
    }
    for (int i = 1; i < ST.NMem; i++)
    {
        MEM[i].GNaCa            = MEM[0].GNaCa; 
        MEM[i].GCab             = MEM[0].GCab;
        MEM[i].GCap             = MEM[0].GCap;
    } 
    // End scale factors =============//

    // Stim current variable setup  lib/Membrane.c
    Stim_setup(&currents, BCL, S2, dt);
    //printf("Stimulus variables setup...\n");

    // Excitation properties variables
    initiate_measurement_variables(&currents); // lib/Membrane.c
    //printf("Excitation variables initiated...\n");
    // End variable and parameter setup ============================//

    // ************************************ RUN SIMULATION ************************************** //

    // Output start time of simulation running =======================
    time_t rawtime;
    time (&rawtime);
    printf("================================================\n\n");
    printf("Code is now running. Started at %s\n", ctime (&rawtime));
    printf("================================================\n\n");
    // End output time =============================================//

    // Set Nryr, NLTCC and vol ds ( = params 0D || spatially varied spatial models)
    for (int i = 0; i < ST.Ndyads; i++) 
    {
        Dyad[i].NLTCC  = params.NLTCC * Dyad[i].LTCC_expression;
        Dyad[i].NRyR   = params.NRyR  * Dyad[i].RyR_expression;
        
        Dyad[i].vol_ds = params.vds_CRU; // homogeneous
      
        // het  
        double rand = Dyad[0].mtrand1(); 
        Dyad[i].vol_ds = 1e-9*(-(0.00004*log(1.0/rand - 1)  - 1e9*params.vds_CRU));

        Dyad_array_allocation(&Dyad[i]);        
    }
    printf("\nDyad channel numbers and volumes set, local arrays allocated...\n\n");   
    printf("NLTCC = %d NRYR = %d\n\n", Dyad[0].NLTCC,  Dyad[0].NRyR);

    // Initial conditions ============================================
    initial_conditions_membrane(&state, currents.Ionic_model); //lib/Membrane.c || Ion currents
    initial_conditions_calcium(&Ca, Argin); // lib/CRU.c   || Ca handling ICs

    for (int i = 0; i < ST.Ndyads; i++) // sets local values to global averages
    {
        Ca.ds[i]    = Ca.DS;
        Ca.jsr[i]   = Ca.JSR;
        initial_conditions_dyad_stochastic(&Dyad[i]);
    }
    for (int i = 0; i < FDM_Cyto.Ncell; i++) // sets local values to global averages
    {
        Ca.ss[i]    = Ca.SS;
        Ca.cyto[i]  = Ca.CYTO;  
    }  
    for (int i = 0; i < FDM_SR.Ncell; i++) 
    {
        Ca.nsr[i]   = Ca.NSR;
    }

    // Set Vm from state
    Vm = state.Vm;
    //printf("\nInitial conditions set...\n\n");
    // End intitial conditions =====================================//

    // Time loop =========================================================================
    printf("Time = %.0fms\n",sim_time);
    for (sim_time = 0.0; sim_time < total_time; sim_time += dt)
    {
        currents.Cai       = 1e-3*Ca.CYTO; // for Ca-dependent currents, which need Ca in mM 

        // Comp stimulus current lib/Membrane.c
        comp_Istim(&currents, stim_period, sim_time, time_counter);
        if (Argin.S2 > 0) comp_Istim_S2(&currents, stim_period-2, S2, sim_time, time_counter); // Stim_period -2 : stim period is 2 ms > final stim

        // Ca handling ===============================================  
        // First, loop over all space (due to zeroing reacs, int makes sense to first loop over largest to smallest arrays
#pragma omp parallel for default(none) shared(FDM_Cyto, ST, Ca, Dyad, params, myofil)
        for (int i = 0; i < FDM_Cyto.Ncell; i++)
        {
            Ca.ss_reac[i]      = 0;
            Ca.cyto_reac[i]    = 0;   

            buffering_cyto(params, &Ca.bcyto[i], Ca.cyto[i]);
            buffering_subspace(params, &Ca.bss[i], Ca.ss[i]);

            // lib/FDM.c
            calc_diff_3D_iso(&FDM_Cyto, Ca.cyto, i);
            Ca.cyto_reac[i] += FDM_Cyto.diff[i]; // NOTE :: reac is really "differential" as we are adding the diffusion term

            calc_diff_3D_iso(&FDM_Cyto, Ca.ss, i);
            Ca.ss_reac[i]   += FDM_Cyto.diff[i];

            // trpn and force
            myofil[i].run_step_myofilament(1e-3*Ca.cyto[i], 8, 0.015);
            Ca.cyto_reac[i] += -myofil[i].Jtrpn;
        }

        // Now, loop over all SR voxels
#pragma omp parallel for default(none) shared(FDM_SR, ST, Ca, Dyad, SERCA, params)
        for (int i = 0; i < FDM_SR.Ncell; i++)
        {
            Ca.nsr_reac[i]     = 0;

            int j = ST.SR_cyto_index[i]; // index for Ca cyto, as this loop is over SR

            // lib/CRU.cpp || computes Jup and Jleak
            comp_SR_fluxes(params, &SERCA[i], Ca.cyto[j], Ca.nsr[i], &Ca.cyto_reac[j], &Ca.nsr_reac[i]);

            // lib/FDM.c
            calc_diff_3D_iso(&FDM_SR, Ca.nsr, i);
            Ca.nsr_reac[i] += FDM_SR.diff[i];
        }

        // Loop over all membrane voxels
#pragma omp parallel for default(none) shared(ST, Ca, MEM, Vm, params)
        for (int i = 0; i < ST.NMem; i++)
        {
            int j = ST.Mem_cyto_index[i];
            // lib/CRU.cpp || computes JNaCa, JCab, JCap
            comp_membrane_fluxes_struct(params, &MEM[i], Ca.cyto[j], Ca.ss[j], &Ca.cyto_reac[j], &Ca.ss_reac[j], Vm);
        }

        // Loop over all dyads
#pragma omp parallel for default(none) shared(ST, Ca, Dyad, params, currents, sim_time, Vm, dt)
        for (int i = 0; i < ST.Ndyads; i++)
        {
            Ca.jsr_reac[i]     = 0;

            int j = ST.Dyad_cyto_index[i];
            int k = ST.Dyad_nsr_index[i];

            buffering_jSR(params, &Ca.bjsr[i], Ca.jsr[i]);

            // lib/CRU.cpp || transfer between ds and ss, nsr and jsr
            comp_J_ds_cyto(params, Dyad[i], Ca.ds[i], Ca.cyto[j], &Ca.cyto_reac[j]);
            comp_J_nsr_jsr(params, Dyad[i], Ca.nsr[k], Ca.jsr[i], &Ca.nsr_reac[k], &Ca.jsr_reac[i]);

            // lib/CRU.cpp || computes Jrel and JCaL, solves and updates RyRs and LTCCs
            comp_dyad_3D(params, &Dyad[i], Ca.ds[i], Ca.jsr[i], Ca.ss[j], &Ca.jsr_reac[i], sim_time - currents.t_ex, Vm,  dt);
        }

        // Update concentrations
        #pragma omp parallel for default(none) shared(Ca, dt, FDM_Cyto, ST)
        for (int i = 0; i < FDM_Cyto.Ncell; i++)
        {
            Ca.cyto[i] = Ca.cyto[i]   + Ca.bcyto[i] * dt * Ca.cyto_reac[i];
        //    Ca.ss[i]   = Ca.ss[i]     + Ca.bss[i]   * dt * Ca.ss_reac[i];
        }
        #pragma omp parallel for default(none) shared(Ca, dt, FDM_SR)
        for (int i = 0; i < FDM_SR.Ncell; i++)
        {
            Ca.nsr[i]  = Ca.nsr[i]    +               dt * Ca.nsr_reac[i];   
        }
        #pragma omp parallel for default(none) shared(Ca, ST, Dyad, params, dt)
        for (int i = 0; i < ST.Ndyads; i++)
        {
            Ca.ds[i]   = (Ca.cyto[ST.Dyad_cyto_index[i]] + params.tau_ds*(Dyad[i].Krel*Ca.jsr[i] + Dyad[i].JCaL))/(1 + params.tau_ds*Dyad[i].Krel); // quasi-steady-state approximation 
            Ca.jsr[i]  = Ca.jsr[i]    + Ca.bjsr[i]  * dt * Ca.jsr_reac[i];
        }
        // End Ca handling =========================================//

        // Averages ==================================================
        Ca.CYTO = Ca.SS = Ca.DS = Ca.NSR = Ca.JSR = 0;
        currents.ICaL  = 0;
        CRU.JCAL = CRU.JREL = CRU.JUP = CRU.JLEAK = 0;
        CRU.NRYR_O1 = CRU.NRYR_O2 = CRU.NRYR_C1 = CRU.NRYR_C2 = CRU.MONOMER = 0;
        CRU.JNACA = CRU.JNACA_SS = CRU.JCAB = CRU.JCAB_SS = CRU.JCAP = CRU.JCAP_SS = 0;
        Force = 0;

        for (int i = 0; i < FDM_Cyto.Ncell; i++)
        {
            Ca.CYTO     += Ca.cyto[i]/FDM_Cyto.Ncell;
            Ca.SS       += Ca.ss[i]/FDM_Cyto.Ncell;
            Force       += myofil[i].Force/FDM_Cyto.Ncell;
        }
        for (int i = 0; i < FDM_SR.Ncell; i++)
        {
            Ca.NSR          += Ca.nsr[i]/FDM_SR.Ncell;
            CRU.JUP         += SERCA[i].Jup/FDM_SR.Ncell;
            CRU.JLEAK       += SERCA[i].Jleak/FDM_SR.Ncell;
        }
        for (int i = 0; i < ST.NMem; i++)
        {   
            CRU.JNACA        += MEM[i].JNaCa/ST.NMem;
            CRU.JNACA_SS     += MEM[i].JNaCa_ss/ST.NMem;
            CRU.JCAB         += MEM[i].JCab/ST.NMem;
            CRU.JCAB_SS      += MEM[i].JCab_ss/ST.NMem;
            CRU.JCAP         += MEM[i].JCap/ST.NMem;
            CRU.JCAP_SS      += MEM[i].JCap_ss/ST.NMem;
        }
        for (int i = 0; i < ST.Ndyads; i++)
        {
            Ca.DS           += Ca.ds[i]/ST.Ndyads;
            Ca.JSR          += Ca.jsr[i]/ST.Ndyads;

            CRU.JCAL        += Dyad[i].JCaL/ST.Ndyads;
            CRU.JREL        += Dyad[i].Jrel/ST.Ndyads;
            CRU.NRYR_O1     += (float)Dyad[i].NRyR_O1/(ST.Ndyads*Dyad[i].NRyR);     
            CRU.NRYR_C1     += (float)Dyad[i].NRyR_C1/(ST.Ndyads*Dyad[i].NRyR);
            CRU.NRYR_C2     += (float)Dyad[i].NRyR_C2/(ST.Ndyads*Dyad[i].NRyR);
            CRU.NRYR_O2     += (float)Dyad[i].NRyR_O2/(ST.Ndyads*Dyad[i].NRyR);
            CRU.MONOMER     += Dyad[i].Monomer/ST.Ndyads; 

            currents.ICaL += (-compute_current_from_flux(params, Dyad[i].JCaL, 2, Dyad[i].vol_ds))/ST.Ndyads; // vol_ds can vary, so current needs to be computed at each CRU
        }
        // End averages ============================================//

        // compute the ionic current 
        compute_IMEM_Struct(params, CRU, &currents);  // Converts fluxes to currents lib/CRU.c || pass in MEM[0] as this now contains the average
        state.ICaL_va = Dyad[0].ICaL_va_2; // mainly for file outputs
        state.ICaL_vi = Dyad[0].ICaL_vi;

        compute_Itot_integrated(params, &currents, &state, Vm, dt, currents.Ionic_model); // lib/Membrane.c

        // Update voltage :: after state.Vm has been updated, state.Vm is at time (t) and Vm is at time (t-dt)
        state.Vm = state.Vm + dt*(-(currents.Itot + currents.Istim + currents.Istim_S2));

        // Determine if in excited state (voltage), dvdt/dvdt_max, and apd
        determine_excitation_state_integrated(&currents, &Dyad[0].Ca_JSR_t_ex, Ca.JSR, Vm, -30, -70, sim_time); // -30 mV is excitation threshdold; -70 is repolarisation
        dvdt_and_dvdt_max(&currents, state, Vm, dt);
        APD_voltage_threshold(&currents, Vm, -75, sim_time); // APD to -75 mV

        // Update global Vm from state :: now both Vm at current t
        Vm = state.Vm; 

        // Output files
        if (time_counter%(int)(1/dt) == 0) // if sim_time is an integer (i.e. per ms)
        {
            output_membrane(out_cu, sim_time, currents, state, Vm); // Defined below :: out_cu = "Whole_cell_out/Currents.dat"
            output_excitation_properties(out_ex, sim_time, currents, state, Vm); // Defined below :: out_ex = "Whole_cell_out/Excitation.dat"
            output_Ca(out_cru, sim_time,  Ca, CRU, Force, Vm); // out_cru = Whole_cell_out/CRU.dat"
            output_RyR(out_ryr, sim_time, CRU, ST.Ndyads); // out_ryr = Whole_cell_out/RyR_states.dat"

            // linescans
            linescan_out_Z(out_lsZ, FDM_Cyto, Ca.cyto, FDM_Cyto.NX/4, FDM_Cyto.NY/4);
            linescan_out_X(out_lsX, FDM_Cyto, Ca.cyto, FDM_Cyto.NY/4, FDM_Cyto.NZ/4); // output other linescans if you want
            //linescan_out_Y(out_lsY, FDM_Cyto, Ca.cyto, FDM_Cyto.NX/4, FDM_Cyto.NZ/4);

            // output every x ms
            if (outcount %Argin.Spatial_output_interval == 0)
            {
                vtk_3D_output("Ca", Ca.cyto, FDM_Cyto, outcount, FDM_Cyto.geo);
                vtk_3D_output("CaSR", Ca.nsr, FDM_SR, outcount, FDM_SR.geo);
                array_output("Ca", Ca.cyto, FDM_Cyto.Ncell, outcount);
                array_output("CaSR", Ca.nsr, FDM_SR.Ncell, outcount);
            }

            outcount++;
        }

        time_counter++; // iterate time counter :: i.e. counts how many times iterated over dt (dt_max) 
        if (time_counter%(200*((int)(1/dt))) == 0) printf("Time = %.0fms\n",sim_time); // output to screen every 200 ms
    }
    // End time loop ===================================================================//

    // Write state files at end of simulation ============================================
    state.Vm = Vm; // make most recent Vm
    // End write state files at end of simulation ======================================//

    printf("Final Time = %.0fms\n\n",sim_time);
    printf("Final beat properties: APD = %f ms\t dvdt_max = %f mV/ms\n\n\n", currents.APD, currents.dvdt_max); 
    time (&rawtime);
    printf("================================================\n\n");
    printf("Code has now finished. Finished at %s\n", ctime (&rawtime));
    printf("================================================\n\n");

    // free dynamically allocated arrays
    for (int i = 0; i < ST.Ndyads; i++) // de allocates state arrays per dyad
    {
        Dyad_array_deallocation(&Dyad[i]);
    }

    delete [] params.LK_V;
    delete [] Dyad;
    delete [] SERCA;
    delete [] MEM;
    Ca_array_deallocation(&Ca);
    FDM_array_deallocation(&FDM_Cyto);
    FDM_array_deallocation(&FDM_SR);
    array_deallocation_indexes(&ST);

} // end main

void output_membrane(ostream& out, double sim_time, Current_variables c, State_variables s, double Vm)
{

    out<</*1*/sim_time<<" "<</*2*/Vm<<" "<</*3*/c.INa<<" "<</*4*/s.INa_va<<" "<</*5*/s.INa_vi_1<<" "<</*6*/s.INa_vi_2<<" "<</*7*/c.Ito<<" "<</*8*/s.Ito_va<<" "<</*9*/s.Ito_vi<<" "<</*10*/c.ICaL<<" "<</*11*/s.ICaL_va<<" "<</*12*/s.ICaL_vi<<" "<<

        /*13*/c.IKur<<" "<</*14*/s.IKur_va<<" "<</*15*/s.IKur_vi<<" "<</*16*/c.IKr<<" "<</*17*/s.IKr_va<<" "<</*18*/c.IKr_vi_ti<<" "<</*19*/c.IK1<<" "<</*20*/c.INaCa<<" "<</*21*/c.INaCa_ss<<" "<</*22*/c.ICab+c.ICab_ss<<" "<</*23*/c.ICap+c.ICap_ss<<" "<</*24*/c.Istim<<" "<</*25*/c.Istim_S2<<endl;
}

void output_excitation_properties(ostream& out, double sim_time, Current_variables c, State_variables s, double Vm)
{
    out<</*1*/sim_time<<" "<</*2*/Vm<<" "<< /*3*/c.ex_switch<<" "<</*4*/c.dvdt<<" "<</*5*/c.dvdt_max<<" "<</*6*/c.APD<<endl;
}

void output_Ca(ostream& out, double sim_time, Ca_variables Ca, CRU_averages cru, double Force, double Vm)
{
    out<</*1*/sim_time<<" "<</*2*/Vm<<"  "<</*3*/Ca.DS<<"    "<</*4*/Ca.SS<<"    "<</*5*/Ca.CYTO<<"    "<</*6*/Ca.JSR<<"    "<</*7*/Ca.NSR<<"    "<</*8*/cru.JUP<<"    "<</*9*/cru.JLEAK<<"    "<</*10*/cru.JCAL<<"    "<</*11*/cru.NRYR_O1<<"  "<</*12*/cru.JREL<<"    "<<

        /*13*/cru.JNACA<<"    "<</*14*/cru.JNACA_SS<<" "<</*15*/cru.JCAB<<"    "<</*16*/cru.JCAB_SS<<"    "<</*17*/cru.JCAP<<"    "<</*18*/cru.JCAP_SS<<"    "<</*19*/Force<<endl;
}

void output_RyR(ostream& out, double sim_time, CRU_averages cru, int N)
{
    out<</*1*/sim_time<<" "<</*2*/cru.NRYR_C1<<"    "<</*3*/cru.NRYR_C2<<"    "<</*4*/cru.NRYR_O1<<"    "<</*5*/cru.NRYR_O2<<"    "<</*6*/cru.MONOMER<<"  "<</*7*/cru.JREL<<endl;
}

void vtk_3D_output(const char *string, double *variable, FDM_variables fdm, int count, int *geo)
{

    FILE * out;
    //char *str = (char*)malloc(50);
    char str[100];

    int cell_count = 0;
    int idx;

    sprintf(str, "Spatial_diff_out/%s_output_%04d.vtk", string, count);
    out = fopen(str, "wt");
    if (out == NULL)
    {
        printf("!!!!!!Must have 'Spatial_diff_out' directory to run!!!!!!\n");
        exit(1);
    }

    fprintf(out, "# vtk DataFile Version 3.0\n");
    fprintf(out, "vtk output\n");
    fprintf(out, "ASCII\n");
    fprintf(out, "DATASET STRUCTURED_POINTS\n");
    fprintf(out, "DIMENSIONS %d %d %d\n", fdm.NX, fdm.NY, fdm.NZ);
    fprintf(out, "SPACING 1 1 1\n");
    fprintf(out, "ORIGIN 0 0 0\n");
    fprintf(out, "POINT_DATA %d\n", fdm.NX*fdm.NY*fdm.NZ);
    fprintf(out, "SCALARS ImageFile float 1\n");
    fprintf(out, "LOOKUP_TABLE default\n");

    for (int z = 0; z < fdm.NZ; z++) {
        for (int y = 0; y < fdm.NY; y++) {
            for (int x = 0; x < fdm.NX; x++){
                idx = x + (fdm.NX*y) + (fdm.NX*fdm.NY*z);
                if (geo[idx] > 0)
                {
                    fprintf(out, "%f ", variable[cell_count]);
                    cell_count++;
                }
                else fprintf(out, "-100 ");
            }
            fprintf(out, "\n");
        }
    }

    fclose(out);
}

void array_output(const char *string, double *variable, int Ncell, int count)
{

    FILE * out;
    char str[100];

    int cell_count = 0;
    int idx;

    sprintf(str, "Spatial_diff_out/%s_1D_output_%04d.dat", string, count);
    out = fopen(str, "wt");
    if (out == NULL)
    {
        printf("!!!!!!Must have 'Spatial_diff_out' directory to run!!!!!!\n");
        exit(1);
    }

    for (int i = 0; i < Ncell; i++) fprintf(out, "%f\n", variable[i]);
}

void linescan_out_X(ostream& out, FDM_variables fdm, double * variable, int y, int z)
{
    for (int x=0;x<fdm.NX;x++)
    {
        int idx = x + (fdm.NX * y) + (fdm.NX * fdm.NY * z);

        if (fdm.geo[idx] > 0)
        {
            out<<variable[fdm.geo_index[idx]]<<"  ";
        }
        else  out<<"-100 "<<"  ";
    }
    out<<endl;
}

void linescan_out_Y(ostream& out, FDM_variables fdm, double * variable, int x, int z)
{
    for (int y=0;y<fdm.NY;y++)
    {
        int idx = x + (fdm.NX * y) + (fdm.NX * fdm.NY * z);

        if (fdm.geo[idx] > 0)
        {
            out<<variable[fdm.geo_index[idx]]<<"  ";
        }
        else  out<<"-100 "<<"  ";
    }
    out<<endl;
}

void linescan_out_Z(ostream& out, FDM_variables fdm, double * variable, int x, int y)
{
    for (int z=0;z<fdm.NZ;z++)
    {
        int idx = x + (fdm.NX * y) + (fdm.NX * fdm.NY * z);

        if (fdm.geo[idx] > 0)
        {
            out<<variable[fdm.geo_index[idx]]<<"  ";
        }
        else  out<<"-100 "<<"  ";
    }
    out<<endl;
}


