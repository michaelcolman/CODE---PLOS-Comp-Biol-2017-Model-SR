#include <stdio.h>

#define NX (400)
#define NY (208)
#define NZ (350)//(358)

#define NX3 (100)
#define NY3 (52)
#define NZ3 (52)

#define NX2 (50)
#define NY2 (26)
#define NZ2 (52)

int SR_geo[NX][NY][NZ];
float Ca_SR[NX3*NY3*NZ3];
float Ca_SR_CR[NX2*NY2*NZ2];

int main(int argc, char *argv[])
{
    FILE * in;
    FILE * out;

    int i, j, k;

    int time;
    time = atoi(argv[1]);

    in = fopen("SR_full_geo_map.map", "r");

    printf("Map loaded\n");

    for ( k = 0; k < NZ; k++)
    {
        for (j = 0; j < NY; j++)
        {
            for (i = 0; i < NX; i++)
            {
                fscanf(in, "%d\n", &SR_geo[i][j][k]);
            }
        }
    }
    
    fclose(in);
    
    printf("Map read\n");
    
    char *str = (char*)malloc(50);

    sprintf(str, "CaSR_1D_output_%04d.dat", time); 

    in = fopen(str, "r");

    FILE *in2;
    float temp;
    str = argv[2];
    in2 = fopen(str, "r");

    for (k = 0; k < NZ3; k++)
    {
        for (j = 0; j < NY3; j++)
        {
            for (i = 0; i < NX3; i++)
            {
                int idx = i + (NX3*j) + (NX3*NY3*k);
                fscanf(in2, "%f ", &temp);
                if (temp > 0) fscanf(in, "%f ", &Ca_SR[idx]);
                else Ca_SR[idx] = -100;
            }
        }
    }

    for ( k = 0; k < NZ2; k++)
    {
        for (j = 0; j < NY2; j++)
        {
            for (i = 0; i < NX2; i++)
            {
                int idx1 = i + (NX3*j) + (NX3*NY3*k);
                int idx2 = i + (NX2*j) + (NX2*NY2*k);
                Ca_SR_CR[idx2] = Ca_SR[idx1]; 
                //printf("%d %d %f %f\n", idx1, idx2, Ca_SR[idx1], Ca_SR_CR[idx2]);
            }
        }
    }

    printf("data file read\n");

    sprintf(str, "Ca_SR_full_%04d.vtk", time);

    out = fopen(str, "wt");

    fprintf (out, "# vtk DataFile Version 3.0\n");
    fprintf (out, "vtk output\n");
    fprintf (out, "ASCII\n");
    fprintf (out, "DATASET STRUCTURED_POINTS\n");
    fprintf (out, "DIMENSIONS %d %d %d\n",NX,NY,NZ);
    fprintf (out, "SPACING 0.125 0.125 0.142857143\n");
    fprintf (out, "ORIGIN 0 0 0\n");
    fprintf (out, "POINT_DATA %d\n", NX*NY*NZ);
    fprintf (out, "SCALARS ImageFile float 1\n"); 
    fprintf (out, "LOOKUP_TABLE default\n");


    for ( k = 0; k < NZ; k++)
    {
        for (j = 0; j < NY; j++)
        {
            for (i = 0; i < NX; i++)
            {
                if (SR_geo[i][j][k] == -1) fprintf(out, "0 ");
                else fprintf(out, "%f ", Ca_SR_CR[SR_geo[i][j][k]]);
            }
            fprintf(out, "\n");
        }
        fprintf(out, "\n");
    }

    fclose(out);

    printf("Whole portion VTK done\n");

    sprintf(str, "Ca_SR_full_slice_1_%04d.vtk", time);

    out = fopen(str, "wt");

    fprintf (out, "# vtk DataFile Version 3.0\n");
    fprintf (out, "vtk output\n");
    fprintf (out, "ASCII\n");
    fprintf (out, "DATASET STRUCTURED_POINTS\n");
    fprintf (out, "DIMENSIONS %d %d %d\n",NX,NY,NZ);
    fprintf (out, "SPACING 0.125 0.125 0.142857143\n");
    fprintf (out, "ORIGIN 0 0 0\n");
    fprintf (out, "POINT_DATA %d\n", NX*NY*NZ);
    fprintf (out, "SCALARS ImageFile float 1\n");
    fprintf (out, "LOOKUP_TABLE default\n");


    for ( k = 0; k < NZ; k++)
    {
        for (j = 0; j < NY; j++)
        {
            for (i = 0; i < NX; i++)
            {
                if (SR_geo[i][j][k] == -1 || (j < (NY/2 - 10) || j > (NY/2) + 10 ) )fprintf(out, "0 ");
                else fprintf(out, "%f ", Ca_SR_CR[SR_geo[i][j][k]]);
            }
            fprintf(out, "\n");
        }
        fprintf(out, "\n");
    }

    fclose(out);

    sprintf(str, "Ca_SR_full_slice_2_%04d.vtk", time);

    out = fopen(str, "wt");

    fprintf (out, "# vtk DataFile Version 3.0\n");
    fprintf (out, "vtk output\n");
    fprintf (out, "ASCII\n");
    fprintf (out, "DATASET STRUCTURED_POINTS\n");
    fprintf (out, "DIMENSIONS %d %d %d\n",NX,NY,NZ);
    fprintf (out, "SPACING 0.125 0.125 0.142857143\n");
    fprintf (out, "ORIGIN 0 0 0\n");
    fprintf (out, "POINT_DATA %d\n", NX*NY*NZ);
    fprintf (out, "SCALARS ImageFile float 1\n");
    fprintf (out, "LOOKUP_TABLE default\n");


    for ( k = 0; k < NZ; k++)
    {
        for (j = 0; j < NY; j++)
        {
            for (i = 0; i < NX; i++)
            {
                if (SR_geo[i][j][k] == -1 || (k < (NZ/2 - 10) || k > (NZ/2) + 10 ) )fprintf(out, "0 ");
                else fprintf(out, "%f ", Ca_SR_CR[SR_geo[i][j][k]]);
            }
            fprintf(out, "\n");
        }
        fprintf(out, "\n");
    }

    fclose(out);

}
