#include "Params.h"
#include "Arguments.h"
#include <string.h>

// Set the default parameters=============================================================
void Set_params_default(Cell_params *p, int red_factor)
{
    // General and global parameters =================================
    p->R            = 8.314;    // J mol^-1 K^-1
    p->F            = 96.485;   // C mmol-1
    p->T            = 310;      // K
    p->FRT          = p->F/(p->R*p->T);

    p->Cm           = 100;      // pF
    p->Ntot_CRUs    = 20000;    

    p->cao          = 1.8;      // mM
    p->nao          = 140;      // mM
    p->ko           = 4.5;      // mM

    p->nai          = 7.95;     // mM       
    p->ki           = 143.103;  // mM
    // End general and global ======================================//

    // Ion current params ============================================
    p->gNa          = 16;       // Conductance of sodium current s/mF
    p->gNaL         = 0.0075;   // Conductance of late sodium current s/mF
    p->gto          = 0.02;
    p->gCaL         = 0.75;     // Conductance of ICaL simplified s/mF 
    p->gKur         = 0.017622; // Conductance of IKur s/mF 
    p->gKr          = 0.75*0.0529;
    p->gK1          = 0.85*0.20988;
    p->gKs          = 0.75*0.00391;  // Conductance of IKs  s/mF
    p->gKb          = 0.003;
    p->PNab         = 3.75e-10;
    // End ion current params ======================================//

    // Cell-structure (volumes) ======================================
    p->vcyt_CRU     = 1e-9*0.0343;
    p->vnsr_CRU     = p->N_cyto_SR * 1e-9*0.0011526;  // scale by N voxels corresponding to SR out of cyto
    p->vjsr_CRU     = 1e-9*0.035;
    p->vds_CRU      = 1e-9*1.512e-3;

    p->vss_CRU                           = 1.2*1e-9*0.00033792;
    if (red_factor > 3) p->vss_CRU       = 0.5*1e-9*0.000225;

    p->v_ss_cyt     = p->vss_CRU/p->vcyt_CRU;
    p->v_cyt_nsr    = p->vcyt_CRU/p->vnsr_CRU;
    p->v_jsr_nsr    = p->vjsr_CRU/p->vnsr_CRU;

    printf("Voxel volume params: vcyt = %f vss = %f vnsr = %f\n", 1e9*p->vcyt_CRU, 1e9*p->vss_CRU ,1e9*p->vnsr_CRU);
    printf("Ratios: vss/cyt = %f vcyt/nsr = %f vjsr/nsr = %f\n", p->v_ss_cyt, p->v_cyt_nsr, p->v_jsr_nsr);
    // End cell structure ==========================================//

    // Jup and Jleak params =========================================
    p->rup          = 0.12161;//0.75*1.1*0.5*0.29481;
    p->Hup          = 2;
    p->Kup_i        = 0.15; // microM
    p->Kup_nsr      = 1700; // microM
    p->rleak        = 0.52974405e-5;//0.75*1.1*0.5*1.284228e-5;
    p->Kleak        = 450; // microM

    // Multiply by ratio, as rate is set for whole cell || if nvoxels SR is < cyto, flux rate needs to be increased accordingly
    p->rup                  *= p->N_cyto_SR;
    p->rleak                *= p->N_cyto_SR;
    // End Jup  ===================================================//

    // ICaL/LTCC params ==============================================
    p->NLTCC        = 15;
    p->rLTCC        = 0.018;        // micro mol C-1 ms^-1 * (micro m^3) || 11.9 micro mol C-1 ms^-1 * 1.712e-3 micro m^3 and rescaled to give same total for vol ds
    p->ICaL_Por     = 0.3;          // ms^-1
    p->ICaL_Pcr     = 6.0;          // ms^-1
    p->ICaL_Ca_bar  = 6.0;          // microM
    p->gammaCa      = 0.341;
    // End ICaL/LTCC params ========================================//

    // RyR params ====================================================
    p->NRyR         = 100;
    p->rRyR         = 0.000205;     // micro m ^3 ms ^-1
    p->RyR_Po       = 0.617203e-4;
    p->RyR_power    = 2.5;
    p->RyR_Koc      = 1.0;

    p->RyR_monomer_tau      = 5;        // ms
    p->RyR_mi_tau           = 5;        // ms
    p->RyR_monomer_beta_tau = 213;      // ms
    p->RyR_mi_beta_tau      = 30;       // ms
    p->RyR_monomer_grad     = 2.0;
    // End RyR params ==============================================//

    // INaCa params ==================================================
    p->SS_prop              = 0;
    p->INaCa_KCai   = 3.59;         // microM
    p->INaCa_KCao   = 1.3;          // mM
    p->INaCa_KNai   = 12.3;         // Nai constant || mM
    p->INaCa_KNao   = 87.5;         // mM
    p->INaCa_Kda    = 0.11;         // microM
    p->INaCa_Ksat   = 0.27;         
    p->INaCa_eta    = 0.35;     

    //  the approach has changed so that now no longer divide by volume -
    //  the 1/3.1365 factor accounts for this based on what the flux rate is now set to
    p->rCab                 = (1.0/3.1365)*0.639555*1e-5;//0.7*0.5*1.8237*1e-5;  
    p->rCap                 = (1.0/3.1365)*0.04795*1e-2;//0.7*0.5*0.137*1e-2;
    p->rNaCa                = (1.0/3.1365)*0.13041;//0.7*0.5*0.3726;

    // Multiply by ratio, as rate is set for whole cell || if nvoxels mem is < cyto, flux rate needs to be increased accordingly
    p->rCab                 *= p->N_cyto_mem;
    p->rCap                 *= p->N_cyto_mem;
    p->rNaCa                *= p->N_cyto_mem;
    // End INaCa params ============================================//

    // Diffusion time constants ====================================== 
    // between different compartments
    p->tau_ss_cyt   = 0.1;      // ms
    p->tau_ds       = 0.022;    // ms
    p->tau_nsr_jsr  = 5;        // ms
    // End diffusion time constants ================================//

    // Buffering =====================================================
    // Ca i (cyto/ss)
    p->Kcam         = 7.0;      // microM
    p->Bcam         = 24.0;     // microM
    p->Kbsr         = 1.08;//1.2*1.5*0.6;
    p->Bbsr         = 47.0;     // microM
    p->Kmca         = 0.01155;//0.7*0.5*0.033;
    p->Bmca         = 49;//0.7*0.5*140.0;
    p->Kmmg         = 5.552;//1.2*1.5*3.64;
    p->Bmmg         = 140.0;    // microM

    // JSR || Csqn buffering
    p->Kcsqn        = 0.8;      // mM
    p->Bcsqn        = 10;       // mM
    // End buffering ===============================================// 
}

// updates the defaults (i.e., PRE het and modulation, model dependent)
void update_default_params(Cell_params *p, const char * Ionic_model)
{
    // Default params for a new model model which are different to global defaults
    if (strcmp(Ionic_model, "Other_model") == 0)
    {
        printf("Setting New model params\n");
    }
    // End New model defaults ==============================================
}

void set_params_full_struct_no_SS(Cell_params *p, const char * Ionic_model) // Just params which are different to default
{
    //Volumes 
    p->vcyt_CRU     = 1e-9*0.02;
    p->vds_CRU      = 1e-9*1.212e-3;
    p->v_cyt_nsr    = p->vcyt_CRU/p->vnsr_CRU;

    printf("Voxel volume params (updated): vcyt = %f vss = %f vnsr = %f\n", 1e9*p->vcyt_CRU, 1e9*p->vss_CRU ,1e9*p->vnsr_CRU);

    p->RyR_monomer_tau      = 5;        // ms
    p->RyR_mi_tau           = 5;        // ms
    p->RyR_monomer_beta_tau = 212.5;    // ms
    p->RyR_mi_beta_tau      = 50;       // ms
    p->RyR_monomer_grad     = 4.0;

    p->RyR_Po               = 2.586015e-4;//0.95*0.55*1.18125e-4; // 0.55

    // SERCA
    p->rup                  = 0.133771;//0.75*1.1*0.5*0.29481;
    p->rleak                = 0.52974405e-5;//0.75*1.1*0.5*1.284228e-5;

    p->rup                  *= p->N_cyto_SR;
    p->rleak                *= p->N_cyto_SR;
}
// End defaults ========================================================================//

