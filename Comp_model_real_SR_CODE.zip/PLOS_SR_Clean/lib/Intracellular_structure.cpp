#include "Intracellular_structure.h"
#include "Membrane.h"
#include "FDM.h"
#include "CRU.h"
#include "Params.h"
#include "Arguments.h"
#include <fstream>
#include <stdlib.h>

// Settings (sizes, filenames etc) =======================================================

// Very basic
void set_array_sizes(Intracellular_structural_parameters *st)
{
    st->NX      = 26;
    st->NY      = 26;
    st->NZ      = 52;       

    st->NX2     = (st->NX+1)/st->red_factor; 
    st->NY2     = (st->NY+1)/st->red_factor; 
    st->NZ2     = (st->NZ+1)/st->red_factor; 
}

// Full
void set_structure_geometry_parameters(Intracellular_structural_parameters *st, const char * Structure_model, const char * Dyad_density)
{
    st->dx          = 0.35;     // microns
    st->D           = 0.3;      // um/ms

    st->nsr_neighbour_file  = "None"; // This will be overwritten if a neighbour file is passed, but otherwise is this for all other cases
    st->dyad_geo_file       = "None"; // same as above
    
    // Idealised settings ============================================
    if (strcmp(Structure_model, "Idealised_small") == 0)
    {
        st->NX      = 26;
        st->NY      = 26;
        st->NZ      = 52;

        st->NX2     = (st->NX+1)/st->red_factor;
        st->NY2     = (st->NY+1)/st->red_factor;
        st->NZ2     = (st->NZ+1)/st->red_factor;
    }
    else if (strcmp(Structure_model, "Idealised_full") == 0)
    {
        st->NX      = 52;//104;
        st->NY      = 52;
        st->NZ      = 104;//316;

        st->NX2     = (st->NX+1)/st->red_factor;
        st->NY2     = (st->NY+1)/st->red_factor;
        st->NZ2     = (st->NZ+1)/st->red_factor;
    }

    // Real structure settings =======================================
    else if (strcmp(Structure_model, "Cross_section") == 0)
    {
        st->NX      = 100;
        st->NY      = 52;
        st->NZ      = 52;

        st->NX2     = (st->NX+1)/st->red_factor;
        st->NY2     = (st->NY+1)/st->red_factor;
        st->NZ2     = (st->NZ+1)/st->red_factor;

        st->cyto_geo_file       = "CYTO_cross_section.geom";
        st->nsr_geo_file        = "SR_1D_cross_section.geom";
        st->membrane_geo_file   = "SL_TT_geometry_cross_section.geom";
        st->nsr_neighbour_file  = "Neighbours_SR_cross_section.geom"; 
        
        if (strcmp(Dyad_density, "Normal") == 0) st->dyad_geo_file       = "JSR_cross_section.geom";
        else if (strcmp(Dyad_density, "High") == 0) st->dyad_geo_file    = "JSR_cross_section_increased.geom";
        else
        {
            printf("***ERROR %s- Dyad density invalid or no map specified***\n\n", Dyad_density);
            exit(EXIT_FAILURE);
        }
    }
    else if (strcmp(Structure_model, "Full_cell") == 0)
    {
        st->NX      = 100;
        st->NY      = 52;
        st->NZ      = 312;

        st->NX2     = (st->NX+1)/st->red_factor;
        st->NY2     = (st->NY+1)/st->red_factor;
        st->NZ2     = (st->NZ+1)/st->red_factor;

        st->cyto_geo_file       = "CYTO_full.geom"; 
        st->nsr_geo_file        = "SR_1D_full.geom"; 
        st->membrane_geo_file   = "SL_TT_geometry_full.geom"; 
        st->nsr_neighbour_file  = "Neighbours_SR_full.geom"; 

        if (strcmp(Dyad_density, "Normal") == 0) st->dyad_geo_file       = "JSR_full.geom";
        else if (strcmp(Dyad_density, "High") == 0) st->dyad_geo_file    = "JSR_full_increased.geom";
        else
        {
            printf("***ERROR %s- Dyad density invalid or no map specified***\n\n", Dyad_density);
            exit(EXIT_FAILURE);
        }
    }
    else if (strcmp(Structure_model, "Full_cell_extended") == 0)
    {
        st->NX      = 100;
        st->NY      = 52;
        st->NZ      = 416;

        st->NX2     = (st->NX+1)/st->red_factor;
        st->NY2     = (st->NY+1)/st->red_factor;
        st->NZ2     = (st->NZ+1)/st->red_factor;

        st->cyto_geo_file       = "CYTO_full_extended.geom"; 
        st->nsr_geo_file        = "SR_1D_full_extended.geom"; 
        st->membrane_geo_file   = "SL_TT_geometry_full_extended.geom"; 
        st->dyad_geo_file       = "JSR_full_extended.geom";
        st->nsr_neighbour_file  = "Neighbours_SR_full_extended.geom";

        if (strcmp(Dyad_density, "Normal") == 0) st->dyad_geo_file       = "JSR_full_extended.geom";
        else if (strcmp(Dyad_density, "High") == 0) st->dyad_geo_file    = "JSR_full_extended_increased.geom"; 
        else
        {
            printf("***ERROR %s- Dyad density invalid or no map specified***\n\n", Dyad_density);
            exit(EXIT_FAILURE);
        }
    }

    // Semi-idealised models (can chose different aspects to keep as real structure or ideal)
    else if (strcmp(Structure_model, "Cross_section_idealised") == 0) // real dyad and cyto geometry, idealised mem and SR (= cyto)
    {
        st->NX      = 100;
        st->NY      = 52;
        st->NZ      = 52;

        st->NX2     = (st->NX+1)/st->red_factor;
        st->NY2     = (st->NY+1)/st->red_factor;
        st->NZ2     = (st->NZ+1)/st->red_factor;

        st->cyto_geo_file       = "CYTO_cross_section.geom";
        st->nsr_geo_file        = "CYTO_cross_section.geom";
        st->membrane_geo_file   = "CYTO_cross_section.geom";
        st->dyad_geo_file       = "None"; // These don't need to be here, as already set as default
        st->nsr_neighbour_file  = "None"; // so are just here for clarity || can use dyad map
    }
    else if (strcmp(Structure_model, "Full_cell_idealised") == 0)
    {
        st->NX      = 100;
        st->NY      = 52;
        st->NZ      = 312;

        st->NX2     = (st->NX+1)/st->red_factor;
        st->NY2     = (st->NY+1)/st->red_factor;
        st->NZ2     = (st->NZ+1)/st->red_factor;

        st->cyto_geo_file       = "CYTO_full.geom";
        st->nsr_geo_file        = "CYTO_full.geom"; 
        st->membrane_geo_file   = "CYTO_full.geom"; 
        st->dyad_geo_file       = "JSR_full.geom";
    }
    else
    {
        printf("***ERROR %s- Structure model invalid  %s***\n\n", Structure_model);
        exit(EXIT_FAILURE);
    }

}
// End Settings (sizes, filenames etc) =================================================//

// Setup functions =======================================================================
void set_and_allocate_FDM_arrays_SS(Intracellular_structural_parameters *st, FDM_variables *fdm_cyto, FDM_variables *fdm_sr, FDM_variables *fdm_ss)
{
    FDM_set_array_sizes(fdm_cyto, st->NX, st->NY, st->NZ);
    FDM_set_array_sizes(fdm_sr, st->NX, st->NY, st->NZ);
    FDM_set_array_sizes(fdm_ss, st->NX2, st->NY2, st->NZ2);
    printf("Array dimensions = %d %d %d\n", fdm_cyto->NX, fdm_cyto->NY, fdm_cyto->NZ);
    printf("And for reduced SS = %d %d %d\n", fdm_ss->NX, fdm_ss->NY, fdm_ss->NZ);

    FDM_array_allocation_N(fdm_cyto);
    FDM_array_allocation_N(fdm_sr);
    FDM_array_allocation_N(fdm_ss);
    array_allocation_maps(st);
}

void set_and_allocate_FDM_arrays(Intracellular_structural_parameters *st, FDM_variables *fdm_cyto, FDM_variables *fdm_sr)
{
    FDM_set_array_sizes(fdm_cyto, st->NX, st->NY, st->NZ);
    FDM_set_array_sizes(fdm_sr, st->NX, st->NY, st->NZ);
    printf("Array dimensions = %d %d %d\n", fdm_cyto->NX, fdm_cyto->NY, fdm_cyto->NZ);

    FDM_array_allocation_N(fdm_cyto);
    FDM_array_allocation_N(fdm_sr);
    array_allocation_maps(st);
}

void create_or_read_geometries(Intracellular_structural_parameters *st, FDM_variables *fdm_cyto, FDM_variables *fdm_sr, const char * PATH, const char * Structure_model)
{
    if (strcmp(Structure_model, "Idealised_small") == 0 || strcmp(Structure_model, "Idealised_full") == 0)
    {
        create_idealised_geometry(st, fdm_cyto);       // Sets FDM.Ncell
        create_idealised_geometry(st, fdm_sr);       // Sets FDM.Ncell
    }
    else
    {
        read_geometry(st, fdm_cyto, PATH, st->cyto_geo_file);  // read cyto geometry
        read_geometry(st, fdm_sr, PATH, st->nsr_geo_file);     // read nsr geometry
    }
}

void allocate_Ncell_arrays_and_set_linear_geometry_index(Intracellular_structural_parameters *st, FDM_variables *fdm_cyto, FDM_variables *fdm_sr)
{
    FDM_array_allocation_Ncell(fdm_cyto);
    set_cell_index(fdm_cyto);                       // Assigns geoemtry 1D array and index relation || Do for each geo when different

    FDM_array_allocation_Ncell(fdm_sr);
    set_cell_index(fdm_sr);                       // Assigns geoemtry 1D array and index relation || Do for each geo when different
    st->NSR = fdm_sr->Ncell;

    printf("FDM and Structural arrays allocated and geometry setup...\n");
    printf("Nvoxels cyto = %d\tand Nvoxels SR = %d\n", fdm_cyto->Ncell, fdm_sr->Ncell);
}

void set_dyad_and_membrane_maps(Intracellular_structural_parameters *st, FDM_variables fdm_cyto, const char * PATH, const char * Structure_model)
{
    // Dyad map
    if (strcmp(st->dyad_geo_file, "None") == 0) create_idealised_dyad_map(st, fdm_cyto.geo);    // Sets ST.Ndyads
    else read_map(st, st->Dyad_map, &st->Ndyads,  PATH, st->dyad_geo_file);
    printf("Dyad map created. Ndyads = %d...\n", st->Ndyads);

    // Membrane map (map not used in idealised, as index is just set to idx ; so here must set only Ncell for idealised)
    if (strcmp(Structure_model, "Idealised_small") == 0 || strcmp(Structure_model, "Idealised_full") == 0) st->NMem = fdm_cyto.Ncell;    // Sets ST.Ndyads
    else read_map(st, st->Mem_map, &st->NMem,  PATH, st->membrane_geo_file);
    printf("Membrane map created. NMem = %d...\n", st->NMem);
}

void set_geometry_relation_indexes(Intracellular_structural_parameters *st, FDM_variables *fdm_cyto, FDM_variables *fdm_sr, const char * Structure_model)
{
    create_dyad_cyto_index(st, fdm_cyto->geo_index, fdm_cyto->geo);
    create_dyad_nsr_index(st, fdm_sr->geo_index, fdm_sr->geo); 
    if (strcmp(Structure_model, "Idealised_small") == 0 || strcmp(Structure_model, "Idealised_full") == 0)
    {
        for (int i = 1; i < st->NMem; i++)  st->Mem_cyto_index[i] = i;
        for (int i = 1; i < st->NSR; i++)   st->SR_cyto_index[i] = i;
    }
    else
    { 
        create_Mem_cyto_index(st, fdm_cyto->geo_index, fdm_cyto->geo);
        create_SR_cyto_index(st, fdm_sr->geo, fdm_cyto->geo_index, fdm_cyto->geo);
    }
    printf("Index relations set...\n");
}
// End setup functions =================================================================//

// Idealised geometry functions ==========================================================
void create_idealised_geometry(Intracellular_structural_parameters *st, FDM_variables *fdm)
{
    int NX = st->NX;
    int NY = st->NY;
    int NZ = st->NZ;

    fdm->Ncell = 0;

    for (int z=0;z<NZ;z++)
    {
        for (int y=0;y<NY;y++)
        {
            for (int x=0;x<NX;x++)
            {
                int idx = x + NX*y + NX*NY*z;
                if (x > 1 && x < NX-1 && y > 1 && y < NY-1 && z > 1 && z < NZ-1)
                {
                    fdm->geo[idx] = 1; // Useful stuff
                    fdm->Ncell++;
                }
                else  fdm->geo[idx] = 0; // empty space
            }
        }
    }

    printf("Idealised geometry created. Ncell = %d\n", fdm->Ncell);

}

void create_idealised_dyad_map(Intracellular_structural_parameters *st, int *geo)
{
    int NX = st->NX;
    int NY = st->NY;
    int NZ = st->NZ;

    st->Ndyads = 0;

    for (int z=0;z<NZ;z++)
    {
        for (int y=0;y<NY;y++)
        {
            for (int x=0;x<NX;x++)
            {
                int idx = x + NX*y + NX*NY*z;
                if ((x+2)%4 == 0 && (y+3)%4 == 0 && (z+3)%4 == 0 && geo[idx] > 0) // last clause is to ensure real tissue only
                {
                    st->Dyad_map[idx] = st->Ndyads; // Ndyads is a counter within the loop
                    st->Ndyads++;
                }
                else  st->Dyad_map[idx] = -1; // 0 is the first dyad, so negative numbers needed for no dyad
            }
        }
    }

    printf("Idealised dyad map created. Ndyads = %d\n", st->Ndyads);
}
// Idealised geometry functions ==========================================================

// Read geometry and map =================================================================
// This functions reads in geometry for a variable with coupling (FDM) || cyto and nsr, not mem
void read_geometry(Intracellular_structural_parameters *st, FDM_variables *fdm, const char * PATH, const char * file_in)
{
    FILE *in;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/Intracellular_structure_geometries/%s", PATH, file_in);

    in = fopen(string, "r");

    if (in == NULL)
    {
        printf("Cannot load geometry file %s\t :: is the path correct? Does the file exist in that path?\n", string);
        exit(1);
    }

    int temp; // temporary int for reading from file
    int idx, cell_count;
    cell_count = 0;

    for (int k = 0; k < fdm->NZ; k++)
    {
        for (int j = 0; j < fdm->NY; j++)
        {
            for (int i = 0; i < fdm->NX; i++)
            {
                idx = i + (fdm->NX*j) + (fdm->NX * fdm->NY * k);
                fscanf(in, "%d ", &temp);
                fdm->geo[idx] = temp;
                if (fdm->geo[idx] > 0) cell_count++;
            }
        }
    }

    fdm->Ncell = cell_count;
    printf("Geometry file %s read || Ncells = %d\n", file_in, fdm->Ncell);
    fclose(in);
}

// Read map || similar, but doesn't populate an FDM geo or calculate and FDM Ncell ; geo and Ncell passed in instead
void read_map(Intracellular_structural_parameters *st, int * map, int *Ncell, const char * PATH, const char * file_in)
{
    FILE *in;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/Intracellular_structure_geometries/%s", PATH, file_in);

    in = fopen(string, "r");

    if (in == NULL)
    {
        printf("Cannot load geometry file %s\t :: is the path correct? Does the file exist in that path?\n", string);
        exit(1);
    }

    int temp; // temporary int for reading from file
    int idx, cell_count;
    cell_count = 0;

    for (int k = 0; k < st->NZ; k++)
    {
        for (int j = 0; j < st->NY; j++)
        {
            for (int i = 0; i < st->NX; i++)
            {
                idx = i + (st->NX*j) + (st->NX * st->NY * k);
                fscanf(in, "%d ", &temp);
                if (temp > 0) 
                {
                    map[idx] = cell_count;
                    cell_count++;
                }
                else map[idx] = -1;
            }
        }
    }

    *Ncell = cell_count;
    //printf("Map file %s read || Ncells = %d\n", file_in, *Ncell);
    fclose(in);
}
// End Read geometry and map ===========================================================//

// Create indexes from maps ==============================================================
// These functions relate 1D indexes of different geometries ================
// Eg., Ndyads < Nvoxels < NX*NY*NZ ; index of a voxel is not same as 3D index
// Dyad array only size of Ndyads. These functions relate Ndyad m with voxel n for 3D array element x,y,z
void create_dyad_cyto_index(Intracellular_structural_parameters *st, int *geo_index, int *geo) // note, geo index is the voxel n to element x, y, z, part of FDM
{
    int NX = st->NX;
    int NY = st->NY;
    int NZ = st->NZ;

    int q, w, e;    // counters for looping around a certain point
    int found;      // is there a cyto voxel there?? || these are to be used if it there is an issue with mapping, to shift map by +- 1 node in any direction to make it fit

    for (int z=0;z<NZ;z++)
    {
        for (int y=0;y<NY;y++)
        {
            for (int x=0;x<NX;x++)
            {
                int idx = x + NX*y + NX*NY*z;
                if (st->Dyad_map[idx] > -1)
                {
                    // So this says that Dyad index (size = Ndyads) at x, where x is the dyad number (given by Dyad_map[idx])
                    // returns the 1D index of the geometry (calculated at 3D index idx)
                    st->Dyad_cyto_index[st->Dyad_map[idx]] = geo_index[idx]; 

                    // Check and adjust if not cyto voxel at dyad location
                    if (geo[idx] < 1) 
                    {
                       printf("No cyto geometry at dyad %d\n", st->Dyad_map[idx]); 
                    }

                }
            }
        }
    }
}

void create_dyad_nsr_index(Intracellular_structural_parameters *st, int *geo_index, int *geo)
{
    int NX = st->NX;
    int NY = st->NY;
    int NZ = st->NZ;

    int q, w, e;    // counters for looping around a certain point
    int found;      // is there an nsr voxel there??  || these are to be used if it there is an issue with mapping, to shift map by +- 1 node in any direction to make it fit

    for (int z=0;z<NZ;z++)
    {
        for (int y=0;y<NY;y++)
        {
            for (int x=0;x<NX;x++)
            {
                int idx = x + NX*y + NX*NY*z;
                if (st->Dyad_map[idx] > -1)
                {
                    st->Dyad_nsr_index[st->Dyad_map[idx]] = geo_index[idx];

                    // Check and adjust if not cyto voxel at dyad location
                    if (geo[idx] < 1)
                    {  
                        //printf("No nsr geometry at dyad %d || adjusting\n", st->Dyad_map[idx]);
                        found = 0;
                        for (q = -1; q < 2; q++) for (w = -1; w < 2; w++) for (e = -1; e < 2; e++)
                        {
                            int idx2 = (x+e) + NX*(y+w) + NX*NY*(z+q);
                            if (geo[idx2] > 0)
                            {
                                st->Dyad_nsr_index[st->Dyad_map[idx]] = geo_index[idx2];
                                found = 1;
                            }
                        }
                        if (found == 0) printf("JSR not mapped to SR properly for JSR number %d\n", st->Dyad_map[idx]);
                    }
                }
            }
        }
    }
}

void create_Mem_cyto_index(Intracellular_structural_parameters *st, int *geo_index, int *geo) // note, geo index is the voxel n to element x, y, z, part of FDM
{
    int NX = st->NX;
    int NY = st->NY;
    int NZ = st->NZ;

    int q, w, e;    // counters for looping around a certain point
    int found;      // is there a cyto voxel there?? || these are to be used if it there is an issue with mapping, to shift map by +- 1 node in any direction to make it fit

    for (int z=0;z<NZ;z++)
    {
        for (int y=0;y<NY;y++)
        {
            for (int x=0;x<NX;x++)
            {
                int idx = x + NX*y + NX*NY*z;
                if (st->Mem_map[idx] > -1)
                {
                    // So this says that Mem index (size = NMem) at x, where x is the membrane voxel number number (given by Mem_map[idx])
                    // returns the 1D index of the geometry (calculated at 3D index idx)
                    st->Mem_cyto_index[st->Mem_map[idx]] = geo_index[idx];

                    // Check and adjust if not cyto voxel at dyad location
                    if (geo[idx] < 1)
                    {
                        printf("No cyto geometry at dyad %d\n", st->Mem_map[idx]);
                    }

                }
            }
        }
    }
}

void create_SR_cyto_index(Intracellular_structural_parameters *st, int *geo_SR, int *geo_cyto_index, int *geo_cyto) // note, geo index is the voxel n to element x, y, z, part of FDM
{
    int NX = st->NX;
    int NY = st->NY;
    int NZ = st->NZ;

    int q, w, e;    // counters for looping around a certain point
    int found;      // is there a cyto voxel there?? || these are to be used if it there is an issue with mapping, to shift map by +- 1 node in any direction to make it fit

    int count = 0;  // as we have a geo (1s and 0s) not a map (0-Ncell), we need to count in this loop

    for (int z=0;z<NZ;z++)
    {
        for (int y=0;y<NY;y++)
        {
            for (int x=0;x<NX;x++)
            {
                int idx = x + NX*y + NX*NY*z;
                if (geo_SR[idx] > 0)
                {
                    // So this says that SR index (size = NSR) at x, where x is the SR voxel number number (given by count)
                    // returns the 1D index of the geometry (calculated at 3D index idx)
                    st->SR_cyto_index[count] = geo_cyto_index[idx];
                    count++;
                    //printf("%d\n", geo_cyto[idx]);

                    // Check and adjust if not cyto voxel at dyad location
                    if (geo_cyto[idx] < 1)
                    {
                        printf("No cyto geometry at SR voxel %d\n", count);
                    }

                }
            }
        }
    }
}
// End create indexes ==================================================================//

// Read SR neighbour map =================================================================
void read_SR_neighbours(Intracellular_structural_parameters *st, FDM_variables *fdm, const char * PATH)
{
    FILE *in;
    char *string = (char*)malloc(500);

    sprintf(string, "%s/Intracellular_structure_geometries/%s", PATH, st->nsr_neighbour_file);

    in = fopen(string, "r"); 

    if (in == NULL)
    {
        printf("Cannot load geometry file %s\t :: is the path correct? Does the file exist in that path?\n", string);
        exit(1);
    }

    int idx, xm, xp, ym, yp, zm, zp; // not technically these, but as fully isotropic, it reduces to the same thing, so doesn't matter

    for(int i = 0; i < fdm->Ncell; i++)
    {
        fscanf(in, "%d %d %d %d %d %d %d\n", &idx, &xm, &xp, &ym, &yp, &zm, &zp);
        fdm->x_minus[i]   = fdm->geo_index[xm];     // xm is the 3D index of neighbour; geo_index[xm] is 1D index
        fdm->x_plus[i]    = fdm->geo_index[xp];
        fdm->y_minus[i]   = fdm->geo_index[ym];
        fdm->y_plus[i]    = fdm->geo_index[yp];
        fdm->z_minus[i]   = fdm->geo_index[zm];
        fdm->z_plus[i]    = fdm->geo_index[zp];
    }

    fclose(in);
}
// End read SR neighbour map ===========================================================//

// Reduced resolution SS setup ===========================================================
void create_reduced_resolution_geometry(Intracellular_structural_parameters *st, FDM_variables fdm_cyto, FDM_variables *fdm_ss)
{
    int NX = st->NX;
    int NY = st->NY;
    int NZ = st->NZ;

    int NX2 = st->NX2;
    int NY2 = st->NY2;
    int NZ2 = st->NZ2;

    int red_factor = st->red_factor;

    fdm_ss->Ncell = 0;

    // zero it first
    for (int z=0;z<NZ2;z++)
    {
        for (int y=0;y<NY2;y++)
        {
            for (int x=0;x<NX2;x++)
            {
                int idx = x + NX2*y + NX2*NY2*z;
                fdm_ss->geo[idx] = 0;
                st->Nv1v2[idx]  = 0;
            }   
        }
    }

    int i, j, k, q, w, e;
    k = 0;
    for (int z=0;z<NZ2;z++)
    {
        j = 0;
        for (int y=0;y<NY2;y++)
        {
            i = 0;
            for (int x=0;x<NX2;x++)
            {
                for (q = 0; q < red_factor; q++) for (w = 0; w < red_factor; w++) for (e = 0; e < red_factor; e++)
                {
                    int idx_hr = (i+e) + NX*(j+w) + NX*NY*(k+q);
                    int idx_lr = x + NX2*y + NX2*NY2*z;
                    if (i+e < NX && j+w < NY && k+q < NZ && fdm_cyto.geo[idx_hr] == 1) // ensure within bounds, and only for actual geometry 
                    {
                        fdm_ss->geo[idx_lr] = 1;
                        st->Nv1v2[idx_lr]++;
                    }
                }
                i += red_factor;
            }
            j += red_factor;
        }
        k += red_factor;
    }

    for (int z=0;z<NZ2;z++)
    {
        for (int y=0;y<NY2;y++)
        {
            for (int x=0;x<NX2;x++)
            {
                int idx = x + NX2*y + NX2*NY2*z;
                if (fdm_ss->geo[idx] > 0) fdm_ss->Ncell++;
            }
        }
    }

    //printf("Reduced resolution SS geometry created. Ncell = %d\n", fdm_ss->Ncell);
}

void create_full_reduced_resolution_index(Intracellular_structural_parameters *st, FDM_variables fdm_cyto, FDM_variables fdm_ss)
{
    int NX = st->NX;
    int NY = st->NY;
    int NZ = st->NZ;

    int NX2 = st->NX2;
    int NY2 = st->NY2;
    int NZ2 = st->NZ2;

    int red_factor = st->red_factor;       

    int i, j, k, q, w, e;
    k = 0;
    for (int z=0;z<NZ2;z++)
    {
        j = 0;
        for (int y=0;y<NY2;y++)
        {
            i = 0;
            for (int x=0;x<NX2;x++)
            {
                for (q = 0; q < red_factor; q++) for (w = 0; w < red_factor; w++) for (e = 0; e < red_factor; e++)
                {
                    int idx_hr = (i+e) + NX*(j+w) + NX*NY*(k+q);    // 3D index hi res
                    int idx_lr = x + NX2*y + NX2*NY2*z;             // 3D index low res
                    if (i+e < NX && j+w < NY && k+q < NZ && fdm_cyto.geo[idx_hr] == 1) // ensure within bounds, and only for actual geometry
                    {
                        st->ss_SS_index[fdm_cyto.geo_index[idx_hr]] = fdm_ss.geo_index[idx_lr]; // fdm_cyto.geo_index[idx_hr] gives 1D index for 3D value, full geo. Thus, this relates 1D indexes of both geos
                    }
                }
                i += red_factor;
            }
            j += red_factor;
        }
        k += red_factor;
    }

    int count = 0;
    for (int z=0;z<NZ2;z++)
    {
        for (int y=0;y<NY2;y++)
        {
            for (int x=0;x<NX2;x++)
            {
                int idx = x + NX2*y + NX2*NY2*z;           
                if (fdm_ss.geo[idx] > 0)
                {
                    st->Nv1v2_linear[count]  = st->Nv1v2[idx];
                    count++;
                }
            }
        }
    }
}
// End Reduced resolution SS setup =====================================================//

// Reduced resolution SS simulation functions ============================================
void map_and_solve_diff_reduced_res_SS(Cell_params p, double * Ca_ss_reduced, FDM_variables *FDM_SS_reduced, FDM_variables FDM_Cyto, Intracellular_structural_parameters st, Ca_variables Ca, double dt)
{
#pragma omp parallel for default(none) shared(Ca_ss_reduced, FDM_SS_reduced) // zero reduced res SS ready for averaging
    for (int i = 0; i < FDM_SS_reduced->Ncell; i++)
    {           
        Ca_ss_reduced[i] = 0;
    }       
    #pragma omp parallel for default(none) shared(Ca_ss_reduced, FDM_Cyto, st, Ca)
    for (int i = 0; i < FDM_Cyto.Ncell; i++)
    {
        Ca_ss_reduced[st.ss_SS_index[i]] += Ca.ss[i]/st.Nv1v2_linear[st.ss_SS_index[i]]; // reduced res SS is average of full res contained
    }
#pragma omp parallel for default(none) shared(Ca_ss_reduced, FDM_SS_reduced)
    for (int i = 0; i < FDM_SS_reduced->Ncell; i++)
    {
        calc_diff_3D_iso(FDM_SS_reduced, Ca_ss_reduced, i);        // do diff on reduced res
    }
#pragma omp parallel for default(none) shared(Ca_ss_reduced, FDM_SS_reduced, p, dt)
    for (int i = 0; i < FDM_SS_reduced->Ncell; i++)
    {
        buffering_subspace(p, &FDM_SS_reduced->buff[i], Ca_ss_reduced[i]);
        Ca_ss_reduced[i] = Ca_ss_reduced[i] + FDM_SS_reduced->buff[i]*dt*FDM_SS_reduced->diff[i]; // Ca_ss_reduced is now updated from diffusion
    }
}

void map_and_solve_diff_reduced_res_SS_alternative(Cell_params p, double * Ca_ss_reduced, FDM_variables *FDM_SS_reduced, FDM_variables FDM_Cyto, Intracellular_structural_parameters st, Ca_variables Ca, double dt)
{
#pragma omp parallel for default(none) shared(Ca_ss_reduced, FDM_SS_reduced) // zero reduced res SS ready for averaging
    for (int i = 0; i < FDM_SS_reduced->Ncell; i++)
    {
        Ca_ss_reduced[i] = 0;
    }
    //#pragma omp parallel for default(none) shared(Ca_ss_reduced, FDM_Cyto, st, Ca)
    for (int i = 0; i < FDM_Cyto.Ncell; i++)
    {
        Ca_ss_reduced[st.ss_SS_index[i]] += Ca.ss[i]/st.Nv1v2_linear[st.ss_SS_index[i]]; // reduced res SS is average of full res contained
    }
#pragma omp parallel for default(none) shared(Ca_ss_reduced, FDM_SS_reduced)
    for (int i = 0; i < FDM_SS_reduced->Ncell; i++)
    {
        calc_diff_3D_iso(FDM_SS_reduced, Ca_ss_reduced, i);        // do diff on reduced res
    }
#pragma omp parallel for default(none) shared(Ca_ss_reduced, FDM_SS_reduced, p, dt)
    for (int i = 0; i < FDM_SS_reduced->Ncell; i++)
    {
        buffering_subspace(p, &FDM_SS_reduced->buff[i], Ca_ss_reduced[i]);
        Ca_ss_reduced[i] = Ca_ss_reduced[i] + FDM_SS_reduced->buff[i]*dt*FDM_SS_reduced->diff[i]; // Ca_ss_reduced is now updated from diffusion
    }
}
// End Reduced resolution SS simulation functions ======================================//

// Array allocation and deallocation =====================================================
void array_allocation_maps(Intracellular_structural_parameters *st)
{
    st->Dyad_map    = new int [st->NX * st->NY * st->NZ];
    st->Mem_map     = new int [st->NX * st->NY * st->NZ];
    st->Nv1v2       = new int [st->NX2 * st->NY2 * st->NZ2];
}

void array_allocation_indexes(Intracellular_structural_parameters *st)
{
    st->Dyad_cyto_index     = new int [st->Ndyads];
    st->Dyad_nsr_index      = new int [st->Ndyads];

    st->SR_cyto_index       = new int [st->NSR];
    st->Mem_cyto_index      = new int [st->NMem];
}

void array_deallocation_maps(Intracellular_structural_parameters *st)
{
    delete [] st->Dyad_map;
    delete [] st->Mem_map;
    delete [] st->Nv1v2;
}

void array_deallocation_indexes(Intracellular_structural_parameters *st)
{
    delete [] st->Dyad_cyto_index;
    delete [] st->Dyad_nsr_index;
    delete [] st->SR_cyto_index;
    delete [] st->Mem_cyto_index;
}
// End Array allocation and deallocation ===============================================//
