// Contains all the CRU functions and variables ::
// Ca, fluxes etc

#ifndef CRU_H
#define CRU_H

#include <math.h>
#include "Params.h"
#include "FDM.h"
#include "MersenneTwister.h"
#include "Arguments.h"

typedef struct{

    // Whole-cell averages || ALL concentrations in mircoM
    double DS; // concentration in the dyadic cleft
    double SS; // subspace
    double CYTO; // bulk-intracellular space
    double JSR; // Junctional SR 
    double NSR; // Network SR

    // local concentrations
    double *ds;
    double *ss;
    double *cyto;
    double *jsr;
    double *nsr;

    // Reaction variable for global Ca
    double SS_reac; 
    double CYTO_reac;
    double JSR_reac;
    double NSR_reac;

    // local reaction terms
    double *ss_reac;
    double *cyto_reac;
    double *jsr_reac;
    double *nsr_reac;
    
    // Buffering
    double Bcyto;       // Buffering in the cytoplasm
    double Bss;         // Buffering in subspace
    double Bjsr;        // Buffering in JSR
    
    // Local buffering
    double *bcyto;
    double *bss;
    double *bjsr;

} Ca_variables;

typedef struct{

    // Jup and leak
    double Jup;         // Uptake from cyto to NSR          || micro M. ms-1
    double Jleak;       // Leak from NSR to cyto            || micro M. ms-1

    double cai_term;    // Cai term of Jup
    double casr_term;   // CaSR term of Jup

    // Scale facors
    double Gup;
    double Gleak;

} SR_fluxes; // Contains the Jup/Jleak flux parameters

typedef struct{

    // Fluxes
    double JCa;         // Total flux from Ca currents      || micro M. ms-1
    double JCa_ss;      // Total flux in subspace           || micro M. ms-1
    double JNaCa;       // Flux through sodium-Ca exchanger || micro M. ms-1
    double JNaCa_ss;    // Flux through sodium-Ca exchanger || micro M. ms-1   
    double JCab;
    double JCab_ss;
    double JCap;
    double JCap_ss;

    // General JNaCa variables (terms in equation)
    double z;           // VF/RT term
    double Ka;          
    double t1, t2, t3; 
    double numerator;
    double denomenator;

    // Scale factors
    double GNaCa;
    double GCab;
    double GCap;

} Membrane_fluxes; // Contrains all membrane Ca currents (except ICaL/LTCC which is in dyad)

typedef struct{
    
    double vol_ds;      // Volume of individual dyadic clef

    // RyR =============================
    int NRyR;           // Number channels

    double Jrel;        // Flux through RyRs
    double Krel;        // RyR release parameter for Ca_ds update

    MTRand mtrand1;     // Random number
    double rand;        // and a place to store it

    // Stochastic RyR model variables
    double KCO;         // Rate from closed to open (activated or inactivated) || ms^-1
    double KOC;         // Rate from open to closed                            || ms^-1
    double KAI;         // Rate from activated to inactivated                  || ms^-1
    double KIA;         // Rate from inactivated to activated                  || ms^-1

    int NRyR_O1;        // Number of channels (per dyad) in state O1
    int NRyR_C1;        // Number of channels (per dyad) in state C1
    int NRyR_C2;        // Number of channels (per dyad) in state C2 (inactivated)
    int NRyR_O2;        // Number of channels (per dyad) in state O2 (inactivated)
    int NRyR_O;         // Number in open state (if this state is a sum of states, otherwise O1 is sufficient)
    
    int * RyR_state;     // Ca2+ dependent state of individual RyR || 0 = closed, 1 = open

    // Analytical model variables
    double NRyR_O_an;   // Proportion of open channels, analytical
    double NRyR_max_an; // Maximum number of open channels, analytical 
    double uptime;      // Time for full upstroke of RyR transient, ms
    double downtime;    // Time for full decary of RyR transeitn, ms
    double Kup;     // Sigmoidal function gradient parameter to give uptime
    double Kdown;   // Sigmoidal function gradient parameter to give downtime
    double t12_up;  // Sigmoidal function t 1/2 upstroke
    double t12_down;// Sigmoidal function t 1/2 downstroke
    double S1;          // Sigmoidal function 1 (upstroke)
    double S2;          // Sigmoidal function 2 (downstroke)
    double ti;      // Initiation time of RyR analytical excitation waveform
    double Ca_JSR_t_ex; // Ca_JSR conc at time of excitation
    int RyR_properties_switch; // identifies if they need to be calculated, or have been already

    // Monomer inactivation
    double csqn;        // concenration of csqn
    double csqn_ca;     
    double Monomer;     // proportion of monomer form
    double Mi;          // proportion of monomer bound to inactivate RyR
    double mon_al;
    double mon_b;
    double mon_ss;
    double mi_ss;
    double mi_al;
    double mi_b;
    // End RyR =======================//

    // LTCC ============================
    // Flux 
    double JCaL;

    // Ntotal and open
    int NLTCC;          // Number LTCCs per dyad
    int NLTCC_O;        // Number of open LTCCs per dyad (stochastic only)

    // State variables (deterministic)
    double ICaL_va_0;   // Voltage-dependent activation, state 0 (3 state gate)
    double ICaL_va_1;   // state 1
    double ICaL_va_2;   // State 2 (active | open state)
    double ICaL_vi;     // Voltage-dependent inactivation
    double ICaL_ci;     // Ca2+ -dependent inactivation

    // State occupancy (stochastic)
    int *va_state;      // 0-2, voltage activation state (state 2 is open)
    int *vi_state;      // 0-1, voltage inactivation state (0 is inactivated; 1 is NOT inactivated)
    int *ci_state;      // 0-1, Ca inactivation state (same as vi)

    // steady-state, rates, tau
    double ICaL_va_al_01;   // alpha rate from state va 0 to 1
    double ICaL_va_b_01;    // beta rate state va 0 to 1 (i.e., rate 1 -> 0) 
    double ICaL_va_al_12;   // alpha, 1->2
    double ICaL_va_b_12;    // beta, 1->2
    double ICaL_va_ss;      // steady-state va (voltage dependent part, states 0-1)
    double ICaL_va_tau;     // time constant ms (voltage dependent part, states 0-1)

    double ICaL_vi_al;      // alpha vi
    double ICaL_vi_b;       
    double ICaL_vi_ss;      
    double ICaL_vi_tau;

    double ICaL_ci_al;      // Ca dependent inactivation, alpha
    double ICaL_ci_b;
    double ICaL_ci_ss;
    double ICaL_ci_tau;

    double Ca_Ca_bar;       // Ca divided by Ca_bar

    // ICaL bar variables
    double ICaL_bar;        // Flux rate of ICaL single channel  (micro M ms^-1 ??????)
    double z;
    double Ca_eff;          // Effective Ca seen by LTCC
    // End LTCC ======================//
    
    // Scale factors
    double RyR_Po;          // Open probability factor / opening rate scale
    double LTCC_Po;         // same || va_1 -> va_2 rate scale
    double RyR_expression;  // Modifies NRyR
    double LTCC_expression;

} Dyad_variables;

typedef struct{ //this struct contains averages of spatial variables, for outputs and currents

    double JCAL;
    double JREL;
    double NRYR_O1;
    double NRYR_O2;
    double NRYR_C1;
    double NRYR_C2;
    double JNACA;
    double JNACA_SS;
    double JCAB;
    double JCAB_SS;
    double JCAP;
    double JCAP_SS;
    double JUP;
    double JLEAK;
    double MONOMER;

} CRU_averages;

// Sets ICs for Ca and dyad state variables
void initial_conditions_calcium(Ca_variables *Ca,  Argument_parameters A);
void initial_conditions_dyad_stochastic(Dyad_variables *d);

// Comp CRU functions ====================================================================
void comp_J_ds_ss(Cell_params p, Dyad_variables d, double Ca_ds, double Ca_ss, double *reac_ss);
void comp_J_ds_cyto(Cell_params p, Dyad_variables d, double Ca_ds, double Ca_cyto, double *reac_cyto);
void comp_J_ss_cyto(Cell_params p, Dyad_variables d, double Ca_ss, double Ca_cyto, double *reac_ss, double *reac_cyto);
void comp_J_nsr_jsr(Cell_params p, Dyad_variables d, double Ca_nsr, double Ca_jsr, double *reac_nsr, double *reac_jsr);

void comp_dyad_3D(Cell_params p, Dyad_variables *d, double Ca_ds, double Ca_jsr, double Ca_couple, double *reac_jsr, double time, double Vm, double dt);
void comp_SR_fluxes(Cell_params p, SR_fluxes *sr, double Ca_cyto, double Ca_nsr, double *reac_cyto, double *reac_nsr);
void comp_membrane_fluxes_struct(Cell_params p, Membrane_fluxes *mem, double Ca_cyto, double Ca_ss, double *reac_cyto, double *reac_ss, double Vm);
// End Comp CRU functions ==============================================================//

// Dyad functions ========================================================================
void set_RyR_rates(Cell_params p, Dyad_variables *d, double Ca_ds);
void update_RyR_stochastic(Dyad_variables *d, double dt);
void update_LTCC_stochastic(Dyad_variables *d, double dt);

void set_and_update_monomer_state(Cell_params p, Dyad_variables *d, double Ca_jsr, double dt);

void comp_Krel(Cell_params p, Dyad_variables *d, double NRyR_O);

void set_LTCC_rates(Cell_params p, Dyad_variables *d, double Ca_ds, double Vm);
void comp_ICaL_bar(Cell_params p, Dyad_variables *d, double Ca_ds, double Vm);
// End dyad functions ==================================================================//

// Flux functions ========================================================================
// Jup and leak
void comp_Jup_Jleak(Cell_params p, SR_fluxes *sr, double Ca_cyto, double Ca_nsr);
void comp_Jup(Cell_params p, SR_fluxes *sr, double Ca_cyto, double Ca_nsr);
void comp_Jleak(Cell_params p, SR_fluxes *sr, double Ca_cyto, double Ca_nsr);

// Membrane current fluxes =============
// Currents
void compute_IMEM_Struct(Cell_params p, CRU_averages cru, Current_variables *c);
double compute_current_from_flux(Cell_params p, double flux, int valence, double vol);
// Fluxes
void compute_JMEM_struct(Cell_params p, Membrane_fluxes *mem, double Ca_cyto, double Ca_ss, double Vm); 
double comp_JNaCa(Cell_params p, Membrane_fluxes *mem, double Cai, double Vm);
double comp_JCab(Cell_params p, double Cai, double Vm);
double comp_JCap(Cell_params p, double Cai);
// End membrane ======================//
// End flux functions ==================================================================//

// Buffering =============================================================================
void comp_buffering(Cell_params p, double *Bcyto, double *Bss, double *Bjsr, double Ca_cyto, double Ca_ss, double Ca_jsr);
void buffering_cyto(Cell_params p, double *Bcyto, double Ca);
void buffering_subspace(Cell_params p, double *Bss, double Ca);
void buffering_jSR(Cell_params p, double *Bjsr, double Ca);
// End buffering =======================================================================//

// Array allocation
void Ca_array_allocation_compart(int Ncell, Ca_variables *Ca);
void Ca_array_allocation_struct(int NCYTO, int NSR, int NDYADS, Ca_variables *Ca);
void Ca_array_deallocation(Ca_variables *Ca);
void Dyad_array_allocation(Dyad_variables *d);
void Dyad_array_deallocation(Dyad_variables *d);
#endif

