#include "Membrane.h"
#include "Params.h"

// From original ORD code || This code is not modified from the ORd code (written from the equations) but please
// still respect the disclaimer associated with that code

// Copyright (c) 2011-2015 by Thomas O'Hara, Yoram Rudy, 
 //                            Washington University in St. Louis.
 // All rights reserved.
 //
 // Redistribution and use in source and binary forms, with or without
 // modification, are permitted provided that the following conditions are
 // met:
 //
 // 1. Redistributions of source code must retain the above copyright notice,
 // this list of conditions and the following disclaimer.
 //
 // 2. Redistributions in binary form must reproduce the above copyright 
 // notice, this list of conditions and the following disclaimer in the 
 // documentation and/or other materials provided with the distribution.
 // 
 // 3. Neither the names of the copyright holders nor the names of its
 // contributors may be used to endorse or promote products derived from 
 // this software without specific prior written permission.
 //
 // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS 
 // IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 // TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
 // PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 // HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 // SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 // LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF 
 // USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 // ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 // OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF 
 // THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 // DAMAGE.
 //

 // C++ Implementation of the O'Hara-Rudy dynamic (ORd) model for the
 // undiseased human ventricular action potential and calcium transient
 //
 // The ORd model is described in the article "Simulation of the Undiseased
 // Human Cardiac Ventricular Action Potential: Model Formulation and
 // Experimental Validation"
 // by Thomas O'Hara, Laszlo Virag, Andras Varro, and Yoram Rudy
 //
 // The article and supplemental materails are freely available in the
 // Open Access jounal PLoS Computational Biology
 // Link to Article:
 // http://www.ploscompbiol.org/article/info:doi/10.1371/journal.pcbi.1002061
 // 
 // Email: tom.ohara@gmail.com / rudy@wustl.edu
 // Web: http://rudylab.wustl.edu
// End from original ORd code ===========================================================

// Compute currents, Itot and update gates (i.e. call all curerent functions) ============
// This may seem convoluted to have them all as separate, but it allows -------
// the rates to be set separately from updating the current or gates, ---------
// which makes implementation of lookup tables (and adaptive dt) much cleaner--
void compute_Itot_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm)
{
    c->Itot = 0;
    
    compute_INa(p, c, s, Vm);
    compute_INaL_ORd(p, c, s, Vm);
    compute_Ito_ORd(p, c, s, Vm);
    compute_IKr_ORd(p, c, s, Vm);
    compute_IKs_ORd(p, c, s, Vm);
    compute_IK1_ORd(p, c, s, Vm);
    compute_IKb(p, c, s,  Vm);
    compute_INab(p, c, s,  Vm);

    c->Itot = c->INa + c->INaL + c->Ito + c->IKr + c->IKs + c->IK1 + c->IKb + c->INab;
}

void compute_Itot_ORd_integrated(Cell_params p, Current_variables *c, State_variables *s, double Vm)
{
    c->Itot = 0;

    compute_INa(p, c, s, Vm);
    compute_INaL_ORd(p, c, s, Vm);
    compute_Ito_ORd(p, c, s, Vm);
    compute_IKr_ORd(p, c, s, Vm);
    compute_IKs_ORd(p, c, s, Vm);
    compute_IK1_ORd(p, c, s, Vm);
    compute_IKb(p, c, s,  Vm);
    compute_INab(p, c, s,  Vm);

    c->Itot = c->INa + c->INaL + c->Ito + c->IKr + c->IKs + c->IK1 + c->IKb + c->INab;
    c->Itot += c->ICaL + c->INaCa + c->INaCa_ss + c->ICab + c->ICab_ss + c->ICap + c->ICap_ss; // Ca currents, computed in CRU.c
}


void set_gate_rates_ORd(Cell_params p, Current_variables *c, double Vm)
{
    set_INa_rates(p, c, Vm);
    set_INaL_rates_ORd(p, c, Vm);
    set_Ito_rates_ORd(p, c, Vm);
    set_IKr_rates_ORd(p, c, Vm);
    set_IKs_rates_ORd(p, c, Vm);
    set_IK1_rates_ORd(p, c, Vm);
    set_variables_IKb(p, c, Vm);
}

void update_gates_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt)
{
    update_gates_INa(p, c, s, Vm, dt);
    update_gates_INaL_ORd(p, c, s, Vm, dt);
    update_gates_Ito_ORd(p, c, s, Vm, dt);
    update_gates_IKr_ORd(p, c, s, Vm, dt);
    update_gates_IKs_ORd(p, c, s, Vm, dt);
    update_gates_IK1_ORd(p, c, s, Vm, dt);
}
// End compute Itot ====================================================================//

// End voltage lookup ==================================================================//

// Reversal potentials ===============================================
void comp_Erevs(Cell_params p, Current_variables *c)
{
    double prnak    = 0.01833; 

    c->ENa      = ((p.R * p.T)/p.F)*log(p.nao/p.nai);
    c->EK       = ((p.R * p.T)/p.F)*log(p.ko/p.ki);
    c->EKs      = ((p.R * p.T)/p.F)*log((p.ko + p.nao)/(p.ki + (prnak * p.nai)));
}
// End reversal potentials =========================================//

// Set and compute the currents ==========================================================
// INa ===============================================================
void compute_INa(Cell_params p, Current_variables *c, State_variables *s, double Vm)
{
    // Compute the current
    c->INa                          = p.gNa * s->INa_va*s->INa_va*s->INa_va * s->INa_vi_1 * s->INa_vi_2 * (Vm - 64);
    c->INa                          *= c->GNa;
}

void set_INa_rates(Cell_params p, Current_variables *c, double Vm)
{

    // Set Activation gate alpha and beta
    c->INa_va_al                    = 0.32*(Vm+47.13)/(1-exp(-0.1*(Vm+47.13)));
    c->INa_va_b                     = 0.08*exp(-Vm/11);

    // Set inactivation gates alphas and betas
    if (Vm < -40.0)
    {
        c->INa_vi_1_al              = 0.135*exp((80+Vm)/-6.8);
        c->INa_vi_1_b               = 3.56*exp(0.079*Vm)+310000*exp(0.35*Vm);
        c->INa_vi_2_al              = (-127140*exp(0.2444*Vm)-0.00003474*exp(-0.04391*Vm))*((Vm+37.78)/(1+exp(0.311*(Vm+79.23))));
        c->INa_vi_2_b               = (0.1212*exp(-0.01052*Vm))/(1+exp(-0.1378*(Vm+40.14)));
    }
    else
    {
        c->INa_vi_1_al              = 0;
        c->INa_vi_1_b               = 1/(0.13*(1+exp((Vm+10.66)/-11.1)));
        c->INa_vi_2_al              = 0;
        c->INa_vi_2_b               = (0.3*exp(-0.0000002535*Vm))/(1+exp(-0.1*(Vm+32)));
    }

    // Set tau and SS from alpha and beta
    c->INa_va_tau                   = 1/(c->INa_va_al + c->INa_va_b); // 1/(a+b)
    c->INa_vi_1_tau                 = 1/(c->INa_vi_1_al + c->INa_vi_1_b);
    c->INa_vi_2_tau                 = 1/(c->INa_vi_2_al + c->INa_vi_2_b );
    c->INa_va_ss                    = c->INa_va_al * c->INa_va_tau; // a*tau
    c->INa_vi_1_ss                  = c->INa_vi_1_al * c->INa_vi_1_tau;
    c->INa_vi_2_ss                  = c->INa_vi_2_al * c->INa_vi_2_tau;
}

void update_gates_INa(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt)
{
    // Update gating variables  (Rush-larsen method)  y = ss - (ss-y)*e^(-dt/tau)
    s->INa_va                       = rush_larsen(s->INa_va, c->INa_va_ss, c->INa_va_tau, dt); // lib/Membrane.c
    s->INa_vi_1                     = rush_larsen(s->INa_vi_1, c->INa_vi_1_ss, c->INa_vi_1_tau, dt);
    s->INa_vi_2                     = rush_larsen(s->INa_vi_2, c->INa_vi_2_ss, c->INa_vi_2_tau, dt);

}
// End INa =========================================================//

// INaL ==============================================================
void compute_INaL_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm)
{
    c->INaL                         = p.gNaL * s->INaL_va * s->INaL_vi * (Vm - c->ENa);
    c->INaL                         *= c->GNaL;
}

void set_INaL_rates_ORd(Cell_params p, Current_variables *c, double Vm)
{
    c->INaL_va_ss                   = 1.0/(1.0+exp((-(Vm+42.85))/5.264));
    c->INaL_va_tau                  = 1.0/(6.765*exp((Vm+11.64)/34.77)+8.552*exp(-(Vm+77.42)/5.955));
    
    c->INaL_vi_ss                   = 1.0/(1.0+exp((Vm+87.61)/7.488));
    c->INaL_vi_tau                  = 200.0;   
}

void update_gates_INaL_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt)
{
    s->INaL_va                      = rush_larsen(s->INaL_va, c->INaL_va_ss, c->INaL_va_tau, dt);
    s->INaL_vi                      = rush_larsen(s->INaL_vi, c->INaL_vi_ss, c->INaL_vi_tau, dt);
}
// End INaL ========================================================//

// Ito ==============================================================
void compute_Ito_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm)
{
    // Compute the current
    c->Ito                          = p.gto * (s->Ito_va * s->Ito_vi) * (Vm - c->EK);
    c->Ito                          *= c->Gto; 
}

void set_Ito_rates_ORd(Cell_params p, Current_variables *c, double Vm)
{
    // Set voltage activation gate
    c->Ito_va_ss                    = 1.0/(1.0+exp((-(Vm-14.34))/14.82)); // Steady-state
    c->Ito_va_tau                   = 1.0515/(1.0/(1.2089*(1.0+exp(-(Vm-18.4099)/29.3814)))+3.5/(1.0+exp((Vm+100.0)/29.3814)));  // Time constant

    // Set the voltage inactivation gate
    c->Ito_vi_ss                    = 1.0/(1.0+exp((Vm+43.94)/5.711)); // Steady-state
    c->Ito_vi_f_tau                 = 4.562+1/(0.3933*exp((-(Vm+100.0))/100.0)+0.08004*exp((Vm+50.0)/16.59));
    c->Ito_vi_s_tau                 = 23.62+1/(0.001416*exp((-(Vm+96.52))/59.05)+1.780e-8*exp((Vm+114.1)/8.079));

    // Proportion of fast and slow gate
    c->Ito_vi_pF                    = 1.0/(1.0+exp((Vm-214.6)/151.2));
    c->Ito_vi_pS                    = 1 - c->Ito_vi_pF;     // Proportion must sum to 1 (obvs) 
}

void update_gates_Ito_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt)
{
    // Update gating variables  (Rush-larsen method)  y = ss - (ss-y)*e^(-dt/tau)
    s->Ito_va                       = rush_larsen(s->Ito_va, c->Ito_va_ss, c->Ito_va_tau, dt);
    s->Ito_vi_f                     = rush_larsen(s->Ito_vi_f, c->Ito_vi_ss, c->Ito_vi_f_tau, dt);
    s->Ito_vi_s                     = rush_larsen(s->Ito_vi_s, c->Ito_vi_ss, c->Ito_vi_s_tau, dt);
    s->Ito_vi                       = (c->Ito_vi_pF * s->Ito_vi_f) + (c->Ito_vi_pS * s->Ito_vi_s); // inactivation is porportional sum of fast and slow
}
// End Ito ========================================================//

// IKr ==============================================================
void compute_IKr_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm)
{
    // Compute the current
    c->IKr                          = p.gKr * s->IKr_va * c->IKr_vi_ti * (Vm - c->EK);
    c->IKr                          *= c->GKr; 
}
void set_IKr_rates_ORd(Cell_params p, Current_variables *c, double Vm)
{
    // Voltage activation gate
    c->IKr_va_ss                    = 1.0/(1.0+exp((-(Vm-(-8.337)))/6.789));  // Steady-state
    c->IKr_va_f_tau                 = 12.98+1.0/(0.3652*exp((Vm-31.66)/3.869)+4.123e-5*exp((-(Vm-47.78))/20.38));  // Time constant
    c->IKr_va_s_tau                 = 1.865+1.0/(0.06629*exp((Vm-34.70)/7.355)+1.128e-5*exp((-(Vm-29.74))/25.94));  // Time constant

    // Set the voltage inactivation gate (time indepedent)
    c->IKr_vi_ti                    = 1.0/(1.0+exp((Vm-(-55.0))/75.0))*1.0/(1.0+exp((Vm-(10.0))/30.0));
    c->IKr_vi_ti                    *= sqrt(p.ko/5.4);

    // Proportion of fast and slow
    c->IKr_va_pF                    = 1.0/(1.0+exp((Vm+54.81)/38.21));
    c->IKr_va_pS                    = 1 - c->IKr_va_pF;
}

void update_gates_IKr_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt)
{
    // Update gating variables  (Rush-larsen method)  y = ss - (ss-y)*e^(-dt/tau)
    s->IKr_va_f                     = rush_larsen(s->IKr_va_f, c->IKr_va_ss, c->IKr_va_f_tau, dt);
    s->IKr_va_s                     = rush_larsen(s->IKr_va_s, c->IKr_va_ss, c->IKr_va_s_tau, dt);
    s->IKr_va                       = (c->IKr_va_pF * s->IKr_va_f) + (c->IKr_va_pS * s->IKr_va_s);
}
// End IKr ========================================================//

// IKs ==============================================================
void compute_IKs_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm)
{
    c->IKs                          = p.gKs * s->IKs_va_1 * s->IKs_va_2 * c->IKs_ca_ti *  (Vm - c->EKs);
    c->IKs                          *= c->GKs;
}

void set_IKs_rates_ORd(Cell_params p, Current_variables *c, double Vm)
{
    c->IKs_va_ss                    = 1.0/(1.0+exp((-(Vm+11.60))/8.932));
    c->IKs_va_1_tau                 = 817.3+1.0/(2.326e-4*exp((Vm+48.28)/17.80)+0.001292*exp((-(Vm+210.0))/230.0));
    c->IKs_va_2_tau                 = 1.0/(0.01*exp((Vm-50.0)/20.0)+0.0193*exp((-(Vm+66.54))/31.0));
    c->IKs_ca_ti                    = 1.0+0.6/(1.0+pow(3.8e-5/c->Cai,1.4));
}

void update_gates_IKs_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt)
{
    // Update gating variables  (Rush-larsen method)  y = ss - (ss-y)*e^(-dt/tau)
    s->IKs_va_1                     = rush_larsen(s->IKs_va_1, c->IKs_va_ss, c->IKs_va_1_tau, dt);
    s->IKs_va_2                     = rush_larsen(s->IKs_va_2, c->IKs_va_ss, c->IKs_va_2_tau, dt);
}
// End IKs =========================================================//


// IK1 ===============================================================
void compute_IK1_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm)
{
    // Compute the current
    c->IK1                          = p.gK1 * c->IK1_va_ti * s->IK1_va * (Vm - c->EK);
    c->IK1                          *= c->GK1; 
}

void set_IK1_rates_ORd(Cell_params p, Current_variables *c, double Vm)
{
    c->IK1_va_ss                    = 1.0/(1.0+exp(-(Vm+2.5538*p.ko+144.59)/(1.5692*p.ko+3.8115)));
    c->IK1_va_tau                   = 122.2/(exp((-(Vm+127.2))/20.36)+exp((Vm+236.8)/69.33)); 
    c->IK1_va_ti                    = 1.0/(1.0+exp((Vm+105.8-2.6*p.ko)/9.493));
    c->IK1_va_ti                    *= sqrt(p.ko);
}

void update_gates_IK1_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt)
{
    // Update gating variables  (Rush-larsen method)  y = ss - (ss-y)*e^(-dt/tau)
    s->IK1_va                       = rush_larsen(s->IK1_va, c->IK1_va_ss, c->IK1_va_tau, dt);
}
// End IK1 =========================================================// 

// Background currents ===============================================
void compute_IKb(Cell_params p, Current_variables *c, State_variables *s, double Vm)
{
    c->IKb                          = p.gKb * c->IKb_x * (Vm - c->EK);
    c->IKb                          *= c->GKb;
}

void set_variables_IKb(Cell_params p, Current_variables *c, double Vm)
{
    c->IKb_x                        = 1.0/(1.0+exp(-(Vm-14.48)/18.34));
} 

void compute_INab(Cell_params p, Current_variables *c, State_variables *s, double Vm)
{
    c->INab                         = p.PNab * c->FNab;
    c->IKb                          *= c->GKb;
} 

void set_variables_INab(Cell_params p, Current_variables *c, double Vm)
{
    c->vffrt                        = Vm * p.F * p.FRT;
    c->vfrt                         = Vm * p.FRT;
    c->FNab                         = c->vffrt*(p.nai*exp(c->vfrt)-p.nao)/(exp(c->vfrt)-1.0);
} 
// End Background currents =========================================//
// End set and compute the currents ====================================================//

