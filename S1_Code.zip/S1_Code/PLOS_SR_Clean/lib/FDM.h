#ifndef FDM_H
#define FDM_H

#include <math.h>

typedef struct{

    int NX, NY, NZ; // geometry sizes
    int Ncell;      // Number of nodes/cells corresponding to actual geometry
    double D1; // Diffusion coefficient (mm/ms) || Transverse D if anisotropic  || microm/ms for Ca2+
    double D2; // Diffusion coefficient (mm/ms) || Longitudinal D for anisotropic (not used for isotropic)
    double *D;    // Diffusion coefficient array
    double dx; // Space step in X direction (mm)

    double *diff; // diffusion term for reaction-diffusion equation
    double *reac; // reaction term (given by single cell code)
    double *buff; // Buffering, if needed

    int * geo;         // contains information about the geometry
    int * geo_linear;  // contrains linearsed geometry
    int * geo_index;   // returns the index of the 1D array when passed 3D array value

    // Neighbour map arrays
    int *x_plus;
    int *x_minus;
    int *y_plus;
    int *y_minus;
    int *z_plus;
    int *z_minus;

} FDM_variables;

// Set array sizes
void FDM_set_array_sizes(FDM_variables *fdm, int NX, int NY, int NZ);

// Allocate and de-allocate spatial arrays
void FDM_array_allocation_N(FDM_variables *fdm); // allocates arrays which are total size
void FDM_array_allocation_Ncell(FDM_variables *fdm); // allocates arrays which are of size Ncell
void FDM_array_deallocation(FDM_variables *fdm);

// Set the linear index for different dimensional models
void set_cell_index(FDM_variables *fdm);

// populate the neighbourhood map
void FDM_set_neighbours(FDM_variables *fdm, const char *Tissue_type);
void FDM_set_neighbours_1D(FDM_variables *fdm);
void FDM_set_neighbours_2D(FDM_variables *fdm);
void FDM_set_neighbours_3D(FDM_variables *fdm);

// Set diffusion parameters
void set_D_dx(FDM_variables *fdm, double dx, double D1, double D2);
void set_D_isotropic(FDM_variables *fdm);

// Calculate diffusion term
void calc_diff_1D_iso(FDM_variables *fdm, double *v, int i); // v is "variable" (not volatge) (array)
void calc_diff_2D_iso(FDM_variables *fdm, double *v, int i); // v is "variable" (not volatge) (array)
void calc_diff_3D_iso(FDM_variables *fdm, double *v, int i); // v is "variable" (not volatge) (array)
void calc_diff_3D_time_constant(FDM_variables *fdm, double *v, int i, double tau_trans, double tau_long); 
#endif


