#include "Arguments.h"
#include "Params.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

void Set_sim_time_variables_from_arguments(Argument_parameters Argin, double *total_time, double *stim_period, double BCL, int *beats)
{
    if (Argin.beats_arg == 0) // If beats argument is not passed, set total time etc from own arguments
    {
        *total_time              = Argin.Total_time; // ms
        *stim_period             = *total_time - 2000; // ms, defaults to leave 2s quiescent
        if (*stim_period < 0)    *stim_period = *total_time;
        if (Argin.Stim_period_arg !=0) *stim_period = Argin.Stim_period; // ms if argument is passed, set it
        *beats                   = (*stim_period + (BCL-2))/BCL;
        *stim_period             = *beats*BCL - (BCL-2); // resets the stim period to be just 2 ms longer than final applied stimulus
    }
    else // Set these parameters based on BCL and number of beats
    {
        *beats                   = Argin.beats;
        *stim_period             = *beats*BCL - (BCL-2);
        if (Argin.Total_time_arg == 0) // if total time arg is not set, define it from beats
        {
            *total_time          = *stim_period + 2000 - 2; // removing the 2 ms after final stimulus
        }
        else *total_time         = Argin.Total_time; // Otherwise define it from arg
    }
}

void Argument_handling(int argc, char *argv[], Argument_parameters *A)
{
    // Set up counter and filename for saving arguments
    int arg_counter = 1;
    FILE *out;
    out = fopen("Argument_list.out", "a");

    // To print time of simulation in arg file
    time_t rawtime;
    time (&rawtime);
    fprintf(out, "User defined arguments for simulation ran on %s\n", ctime (&rawtime)); 

    // Default values of argument parameters =============================================
    // Simulation time parameters ====================================
    A->BCL              = 1000; // ms
    A->Total_time       = 10000; // ms
    A->Total_time_arg   = 0; // Not been passed
    A->Stim_period      = 8000; // Doesn't actually need this
    A->Stim_period_arg  = 0; // Not been passed
    A->beats            = 8; // Doesn't actually need to be set here
    A->beats_arg        = 0; // Not been passed
    A->S2               = 0; // No S2 stimulus
    A->Spatial_output_interval = 10; // ms
    // End sim time params =========================================//

    // Celltype ======================================================
    A->Ionic_model      = "ORd";
    A->celltype         = "EPI";
    A->celltype_arg     = 0; // Not been passed
    // End Celltype ================================================//

    // Modulation ====================================================
    A->ISO              = 0.0;
    A->Remodelling      = "None";
    A->Drug             = "None";
    // End modulation ==============================================//

    // Read/Write state ==============================================
    A->Write_state      = 0; // Don't write state
    A->Read_state       = 0; // Don't read state
    // End read/write state ========================================//

    // Spatial cell ==================================================
    A->cell_size        = "Portion";        // compartmentalised cell
    A->Structure_model  = "Cross_section";  // detailed structre cell
    A->Dyad_density     = "Normal";
    A->Dss_scale        = 1.0;
    A->red_factor       = 2;                // does nothing in main which has it set to 1, so default may as well be 2
    // End spatial cell ============================================//

    // Direct control over variables =================================
    A->DC_arg           = 0;            // None have been passed
    A->RyR_Po           = 1.0;          // Open rate scale RyR
    A->RyR_Po_arg       = 0;            // Not passed  
    A->LTCC_Po          = 1.0; 
    A->LTCC_Po_arg      = 0;
    A->RyR_expression   = 1.0;
    A->RyR_exp_arg      = 0;
    A->LTCC_expression  = 1.0;
    A->LTCC_exp_arg     = 0;
    A->Jup_scale        = 1.0;
    A->Jup_scale_arg    = 0;
    A->Jleak_scale      = 1.0;
    A->Jleak_scale_arg  = 0;
    A->Jmem_scale       = 1.0;
    A->Jmem_scale_arg   == 0;
    // End direct control ==========================================//
    // End default values of argument parameters =======================================//
    
    // Read command line arguments into Arg struct =======================================
    while (arg_counter < argc){ // Loop while less than number arguments

        // Simulation time parameters ================================
        // BCL
        if (strcmp(argv[arg_counter], "BCL") == 0) // this looks for the differences between the two strings: if difference is == 0, they are the same
        {
            A->BCL = atoi(argv[arg_counter+1]);
            fprintf(out, "BCL %s ", argv[arg_counter+1]);
            arg_counter++;
        }
        // Total time
        else if (strcmp(argv[arg_counter], "Total_time") == 0 || strcmp(argv[arg_counter], "total_time") == 0 || strcmp(argv[arg_counter], "Total_Time") == 0)
        {
            A->Total_time = atoi(argv[arg_counter+1]);
            fprintf(out, "Total_time %s ", argv[arg_counter+1]);
            A->Total_time_arg = 1;
            arg_counter++;
        }     
        // Stim period
        else if (strcmp(argv[arg_counter], "Stim_period") == 0 || strcmp(argv[arg_counter], "stim_period") == 0 || strcmp(argv[arg_counter], "Stim_Period") == 0)
        {
            A->Stim_period = atoi(argv[arg_counter+1]);
            fprintf(out, "Stim_period %s ", argv[arg_counter+1]);
            arg_counter++;
            A->Stim_period_arg = 1; // Argument has been passed
        } 
        // Number beats
        else if (strcmp(argv[arg_counter], "Beats") == 0 || strcmp(argv[arg_counter], "beats") == 0)
        {
            A->beats = atoi(argv[arg_counter+1]);
            fprintf(out, "Beats %s ", argv[arg_counter+1]);
            arg_counter++;
            A->beats_arg = 1; // Argument has been passed
        }
        // S2 interval
        else if (strcmp(argv[arg_counter], "S2") == 0)
        {
            A->S2 = atoi(argv[arg_counter+1]);
            fprintf(out, "S2 %s ", argv[arg_counter+1]);
            arg_counter++;
        }
        // End sim time params =====================================//

        // Ionic model and Celltype ==================================
        else if (strcmp(argv[arg_counter], "Ionic_model") == 0)
        {
            A->Ionic_model = argv[arg_counter+1];
            fprintf(out, "Ionic_model %s ", argv[arg_counter+1]);
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "Celltype") == 0 || strcmp(argv[arg_counter], "celltype") == 0)
        {
            A->celltype = argv[arg_counter+1];
            fprintf(out, "Celltype %s ", argv[arg_counter+1]);
            arg_counter++;
            A->celltype_arg = 1;
        }
        // End Ionic model and Celltype ============================//       
        
        // Model modulation (ISO, remod, drug) =======================
        else if (strcmp(argv[arg_counter], "ISO") == 0 || strcmp(argv[arg_counter], "iso") == 0)
        {
            A->ISO = atof(argv[arg_counter+1]);
            fprintf(out, "ISO %s ", argv[arg_counter+1]);
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "Remodelling") == 0 || strcmp(argv[arg_counter], "remodelling") == 0)
        {
            A->Remodelling = argv[arg_counter+1];
            fprintf(out, "Remodelling %s ", argv[arg_counter+1]);
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "Drug") == 0 || strcmp(argv[arg_counter], "drug") == 0)
        {
            A->Drug = argv[arg_counter+1];
            fprintf(out, "Drug %s ", argv[arg_counter+1]);
            arg_counter++;
        }
        // End model modulation ====================================//

        // Spatial_output_interval====================================
        else if (strcmp(argv[arg_counter], "Spatial_output_interval") == 0)
        {
            A->Spatial_output_interval = atoi(argv[arg_counter+1]);
            fprintf(out, "Spatial_output_interval %s ", argv[arg_counter+1]);
            arg_counter++;
        }
        // Spatial_output_interval= ================================//

        // Fully detailed structural model ===========================
        else if (strcmp(argv[arg_counter], "Structure_model") == 0 || strcmp(argv[arg_counter], "structure_model") == 0 || strcmp(argv[arg_counter], "Structure_Model") == 0)
        {
            A->Structure_model = argv[arg_counter+1];
            fprintf(out, "Structure_model %s ", argv[arg_counter+1]);
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "Dyad_density") == 0 || strcmp(argv[arg_counter], "dyad_density") == 0 || strcmp(argv[arg_counter], "Dyad_Density") == 0)
        {
            A->Dyad_density = argv[arg_counter+1];
            fprintf(out, "Dyad_density %s ", argv[arg_counter+1]);
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "Dss_scale") == 0)
        {
            A->Dss_scale = atof(argv[arg_counter+1]);
            fprintf(out, "Dss_scale %s ", argv[arg_counter+1]);
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "red_factor") == 0)
        {
            A->red_factor = atoi(argv[arg_counter+1]);
            fprintf(out, "red_factor %s ", argv[arg_counter+1]);
            arg_counter++;
        }
        // End Fully detailed structural model =====================//

        // Direct control over variables =============================
        else if (strcmp(argv[arg_counter], "Cai") == 0)
        {
            A->Cai_IC = atof(argv[arg_counter+1]);
            fprintf(out, "Cai %s ", argv[arg_counter+1]);
            A->Cai_IC_arg = 1; // Argument has been passed
            A->DC_arg     = 1; // A direct control arg has been passed
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "CaSR") == 0)
        {
            A->Ca_SR_IC = atof(argv[arg_counter+1]);
            fprintf(out, "CaSR %s ", argv[arg_counter+1]);
            A->Ca_SR_IC_arg = 1; // Argument has been passed
            A->DC_arg     = 1; // A direct control arg has been passed
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "RyR_Po") == 0)
        {
            A->RyR_Po = atof(argv[arg_counter+1]);
            fprintf(out, "RyR_Po %s ", argv[arg_counter+1]);
            A->RyR_Po_arg = 1; // Argument has been passed
            A->DC_arg     = 1; // A direct control arg has been passed
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "LTCC_Po") == 0)
        {
            A->LTCC_Po = atof(argv[arg_counter+1]);
            fprintf(out, "LTCC_Po %s ", argv[arg_counter+1]);
            A->LTCC_Po_arg = 1; // Argument has been passed
            A->DC_arg     = 1; // A direct control arg has been passed
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "RyR_expression") == 0)
        {
            A->RyR_expression = atof(argv[arg_counter+1]);
            fprintf(out, "RyR_expression %s ", argv[arg_counter+1]);
            A->RyR_exp_arg = 1; // Argument has been passed
            A->DC_arg     = 1; // A direct control arg has been passed
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "LTCC_expression") == 0)
        {
            A->LTCC_expression = atof(argv[arg_counter+1]);
            fprintf(out, "LTCC_expression %s ", argv[arg_counter+1]);
            A->LTCC_exp_arg = 1; // Argument has been passed
            A->DC_arg     = 1; // A direct control arg has been passed
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "Jup_scale") == 0 || strcmp(argv[arg_counter], "Iup_scale") == 0)
        {
            A->Jup_scale = atof(argv[arg_counter+1]);
            fprintf(out, "Jup_scale %s ", argv[arg_counter+1]);
            A->Jup_scale_arg = 1; // Argument has been passed
            A->DC_arg     = 1; // A direct control arg has been passed
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "Jleak_scale") == 0 || strcmp(argv[arg_counter], "Ileak_scale") == 0)
        {
            A->Jleak_scale = atof(argv[arg_counter+1]);
            fprintf(out, "Jleak_scale %s ", argv[arg_counter+1]);
            A->Jleak_scale_arg = 1; // Argument has been passed
            A->DC_arg     = 1; // A direct control arg has been passed
            arg_counter++;
        }
        else if (strcmp(argv[arg_counter], "Jmem_scale") == 0 || strcmp(argv[arg_counter], "Imem_scale") == 0)
        {
            A->Jmem_scale = atof(argv[arg_counter+1]);
            fprintf(out, "Jmem_scale %s ", argv[arg_counter+1]);
            A->Jmem_scale_arg = 1; // Argument has been passed
            A->DC_arg     = 1; // A direct control arg has been passed
            arg_counter++;
        }
        // End direct control ======================================//

        // Not valid argument ========================================
        else
        {
            printf("***ERROR %s- Argument invalid***\n\n", argv[arg_counter]);
            printf("Please chose from the following arguments:\n\n");
            printf("Simulation time arguments:\n\tTotal time\t BCL\t Stim_period\t Beats\t S2\n\n");
            printf("Ionic model and celltype arguments:\n\tIonic_model\tCelltype\n\n");
            printf("Modulation arguments\n\tISO\tRemodelling\tDrug\n\n");
            printf("Fully detailed structural model\n\tStructure_model\tDyad_density\tDss_scale\tred_factor\n\n");
            printf("Direct control\n\tRyR_Po\tLTCC_Po\tRyR_expression\tLTCC_expression\n");
            printf("\tJup_scale\tJleak_scale\tJmem_scale\n\n");
            exit(EXIT_FAILURE);
        }
        // End not valid ===========================================//

        arg_counter ++;
    }
    fprintf(out, "\n\n\n");
    // End read command line arguments into Arg struct =================================//
    fclose(out);

}

// Outputs settings to the screen
void Argument_screen_output(Argument_parameters A, const char *Model_type)
{ 
    printf("=============================================================\n");
    printf("MODEL SETTINGS:\n");

    printf("\n");
    printf("\n");

    printf("====Simulation time parameters\n\n");
    if (A.beats_arg == 0) // if beats is not set directly
    {
        printf("\tBCL = %d,\tTotal time = %d,\t", A.BCL, A.Total_time);
        if (A.Stim_period_arg !=0) printf("Stim_period = %d\t", A.Stim_period);
        else printf("Stim_period = %d\t", A.Total_time - 2000); // this is set in main if stim period argument not passed
        printf("number beats = %d,\t", (A.Stim_period+(A.BCL-2))/A.BCL);
        printf("Stim period updated = %d\n", ((A.Stim_period+(A.BCL-2))/A.BCL)*A.BCL - (A.BCL-2)); // This is to make stim period exactly 2 ms longer than final applied stimulus
        printf("\tspatial out interval = %d,\t", A.Spatial_output_interval);
    }
    else 
    {
        printf("**Number of beats has been assigned directly; this controls Stim_period and will override this argument if both are passed***\n\n");
        printf("\tBCL = %d,\t", A.BCL);
        if (A.Total_time_arg ==0) printf("Total time = %d,\t", A.beats*A.BCL - (A.BCL-2) + 2000 - 2);
        else  printf("Total time = %d,\t", A.Total_time);
        printf("Stim period = %d,\tNumber beats = %d\n",  A.beats*A.BCL - (A.BCL-2), A.beats);
    }
    if (A.S2 > 0)
    {
        printf("\n\t**S2 argument has been passed: Model is therefore in S1S2 pacing mode\n");
        printf("\tS2 interval = %d\n", A.S2);
    }

    printf("\n");
    printf("\n");

    printf("====Cell model and region\n\n");
    printf("\tIonic model = %s,\t", A.Ionic_model);
    if (A.celltype_arg == 1) printf("celltype chosen by argument, = %s,\n",A.celltype);
    else 
    {
        printf("celltype will be assigned the default for the Ionic model:\t");
        if (strcmp(A.Ionic_model, "minimal") == 0) printf("Vent_EPI\n");
        if (strcmp(A.Ionic_model, "ORd") == 0) printf("EPI\n"); 
    }

    printf("\n");
    printf("\n");

    printf("====Model modulation\n\n");
    printf("\tISO = %f,\tRemodelling = %s,\tDrug = %s\n", A.ISO, A.Remodelling, A.Drug);

    printf("\n");
    printf("\n");

    if (strcmp(Model_type, "Single_cell_structural_3D") == 0)
    {
        printf("====Full 3D structural model specific parameters\n\n");
        printf("\tStructural model type is\t %s\n", A.Structure_model);
        printf("\tDyad density is\t\t\t %s\n", A.Dyad_density);
        printf("\tD scaled for SS is\t\t %f\n", A.Dss_scale);
        printf("\tSS discretisation resolution relative to cyto  %d  (if using the non-reduced SS main, this has no effect)\n", A.red_factor);
        printf("\n");
        printf("\n");
    }

    if (A.DC_arg  == 1) // if a direct control parameter has been passed, print them all to screen
    {
        printf("====Direct control parameters\n\n");
        if (A.RyR_Po_arg == 1)      printf("\tRyR_Po scale %f\n", A.RyR_Po);
        if (A.RyR_exp_arg == 1)     printf("\tRyR_expression scale %f\n", A.RyR_expression);
        if (A.LTCC_Po_arg == 1)     printf("\tLTCC_Po scale %f\n", A.LTCC_Po);
        if (A.LTCC_exp_arg == 1)    printf("\tLTCC_expression scale %f\n", A.LTCC_expression);
        if (A.Jup_scale_arg == 1)   printf("\tJup scale %f\n", A.Jup_scale);
        if (A.Jleak_scale_arg == 1) printf("\tJleak scale %f\n", A.Jleak_scale);
        if (A.Jmem_scale_arg == 1)  printf("\tJmem scale %f\n", A.Jmem_scale);
        if (A.Cai_IC_arg == 1)      printf("\tCai IC %f\n", A.Cai_IC);
        if (A.Ca_SR_IC_arg == 1)    printf("\tCaSR IC %f\n", A.Ca_SR_IC);
        printf("\n");
        printf("\n");  
    }

    printf("=============================================================\n");

    printf("\n");
    printf("\n");
}
