#ifndef ARGUMENTS_H
#define ARGUMENTS_H


typedef struct {
    
    // All Models ========================================================================
    // Simulation parameters
    int BCL;        // Pacing cycle length, ms
    int Total_time; // Total simulation time, ms
    int Total_time_arg; // identifies if total time has been passed
    int Stim_period;// Period of time to apply S1 stimulus
    int Stim_period_arg; // identifies if the Stim_period argument has been passed
    int beats;          // Number of beats
    int beats_arg;      // identifies if beats argument has been passed
    int S2;             // S2 stimulus length
    int Spatial_output_interval;    // time interval to output vtk and spatial array files

    // Ion model and cell type paramters
    char const *Ionic_model;  // Baseline ionic model
    char const *celltype;   // Celltype (e.g. region)
    int celltype_arg;       // identifies if the celltype argument has been passed 
    
    // Model modulation
    double ISO;             // Sympathetic activity conc
    char const *Remodelling; // Remodelling type
    char const *Drug;        // Drug type

    // Write or read state from file
    int Read_state;         // 1 if read state is on (single cell)
    int Write_state;        // 1 if write state is on (single cell)
    // End all models ==================================================================//

    // Spatial cell only =================================================================
    const char *cell_size;
    int cell_NX;
    int cell_NY;
    int cell_NZ;
    // End spatial cell only ===========================================================//

    // Fully structurally detailed model =================================================
    const char * Structure_model;
    const char * Dyad_density;
    double  Dss_scale;  // Scales D for the subspace
    int red_factor;     // amount to down-scale SS
    // End fully structiurally detailed ================================================//

    // Tissue specific parameters ========================================================
    int homogeneous;        // 0 if heterogeneous
    int homogeneous_arg;    // Identifies if this argument is passed
    const char *Tissue_type;        // 1 - 3 : 1D-3D regular; 4 = 3D geometry
    const char *Tissue_model;   // Sets specific params for different types of tissue model

    // for S2 stimulus only as S1 should be set properly in functions
    int S2_loc_x; // centre of stim in x direction
    int S2_loc_arg; // if it has been passed
    // End Tissue specific parameters ==================================================//
    
    // Direct control ICs ================================================================
    double  Cai_IC;          // Initial condition, Cai
    double  Ca_SR_IC;        // IC, CaSR
    int     Cai_IC_arg;      // has it been passed?
    int     Ca_SR_IC_arg;
    // End Direct control ICs ==========================================================//
    
    // Direct control over scale factors =================================================
    int     DC_arg;          // Have any of these been passed
    double  RyR_Po;          // Open rate scale RyR
    int     RyR_Po_arg;
    double  LTCC_Po;         // Open rate scale LTCC
    int     LTCC_Po_arg;
    double  RyR_expression;  // NRyR per dyad scale
    int     RyR_exp_arg;
    double  LTCC_expression; // LTCC per dyad scale
    int     LTCC_exp_arg;
    double  Jup_scale;       // Maximal rate Jup scale
    int     Jup_scale_arg;
    double  Jleak_scale;     // Maximal rate Jleak
    int     Jleak_scale_arg;
    double  Jmem_scale;      // Maximal rate scale all membrane Ca fluxes 
    int     Jmem_scale_arg;
    // End Direct control over scale factors ===========================================//

}Argument_parameters;

void Set_sim_time_variables_from_arguments(Argument_parameters A, double *total_time, double *stim_period, double BCL, int *beats);
void Argument_handling(int argc, char *argv[], Argument_parameters *A);
void Argument_screen_output(Argument_parameters A, const char *Model_type);
#endif
