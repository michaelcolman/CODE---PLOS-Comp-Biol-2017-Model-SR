#include "Het_and_modulation.h"
#include "CRU.h"
#include "Params.h"
#include "Arguments.h"
#include "Membrane.h"
#include <string.h>


// Model variables (which determine het and modulation) from arguments
void Set_variables_from_arguments(Argument_parameters A, Current_variables *c)
{
    c->celltype         = A.celltype;
    c->Ionic_model      = A.Ionic_model;
    c->ISO              = A.ISO;
    c->Remodelling      = A.Remodelling;
    c->Drug             = A.Drug;
}

void Set_variables_from_arguments_integrated(Argument_parameters A, Current_variables *c, Dyad_variables *d, SR_fluxes *sr, Membrane_fluxes *mem)
{
    c->celltype         = A.celltype;
    c->Ionic_model      = A.Ionic_model;
    c->ISO              = A.ISO;
    c->Remodelling      = A.Remodelling;
    c->Drug             = A.Drug;

    if (A.RyR_Po_arg == 1)      d->RyR_Po           = A.RyR_Po;
    if (A.LTCC_Po_arg == 1)     d->LTCC_Po          = A.LTCC_Po;
    if (A.RyR_exp_arg == 1)     d->RyR_expression   = A.RyR_expression;
    if (A.LTCC_exp_arg == 1)    d->LTCC_expression  = A.LTCC_expression;
    if (A.Jup_scale_arg == 1)   sr->Gup             = A.Jup_scale;
    if (A.Jleak_scale_arg == 1) sr->Gleak           = A.Jleak_scale;
    if (A.Jmem_scale_arg == 1)  mem->GNaCa = mem->GCab = mem->GCap = A.Jmem_scale;

    if (A.celltype_arg == 0) // if celltype has not been passed explicitly, set default from ionic model (overridden in het tissue)
    {
        if (strcmp(A.Ionic_model, "ORd") == 0) c->celltype = "EPI";       
    }
}

// End model variables from arguments ==============================//

// Heterogeneity =========================================================================
// Defaults ==========================================================
// THESE SHOULD BE FOR ALL MODELS :: SET ALTERNATIVE DEFAULS IN
// BELOW HET FUNCTION IF NEEDED (even if not technically "heterogeneity")
void set_scale_factor_defaults_integrated(Current_variables *c, Dyad_variables *d, SR_fluxes *sr, Membrane_fluxes *mem)
{
    // Scale factors default is 1.0
    // Currents ========================    
    c->GNa                  = 1.0;
    c->GNaL                 = 1.0;
    c->Gto                  = 1.0;
    c->GCaL                 = 1.0;
    c->GKur                 = 1.0;
    c->GKr                  = 1.0;
    c->GK1                  = 1.0;
    c->GKs                  = 1.0;
    c->GKb                  = 1.0;
    c->GNab                 = 1.0;

    // Voltage shift default is 0
    c->Ito_va_ss_vshift     = 0.0;
    // End currents ==================//

    // CRU =============================
    d->RyR_Po               = 1.0;
    d->LTCC_Po              = 1.0;
    d->RyR_expression       = 1.0;
    d->LTCC_expression      = 1.0;

    sr->Gup                 = 1.0;
    sr->Gleak               = 1.0;
    
    mem->GNaCa              = 1.0;
    mem->GCab               = 1.0;
    mem->GCap               = 1.0; 
    // End CRU =======================//
}
// End defaults ====================================================//

void set_scale_factors_het_integrated(Cell_params p, Current_variables *c, Dyad_variables *d, SR_fluxes *sr, Membrane_fluxes *mem, char const *Ionic_model)
{
    // ORd model =====================================================
    if (strcmp(Ionic_model, "ORd") == 0)
    {  
    //    c->GKr                  *= 1.8;
    //    c->GK1                  *= 1.8;

        if (strcmp(c->celltype, "ENDO") == 0) // default settings are endo
        {
        }
        else if (strcmp(c->celltype, "M") == 0)
        {
            c->Gto                  *= 4;
            c->GKr                  *= 0.8;
            c->GK1                  *= 1.3;
        }
        else if (strcmp(c->celltype, "EPI") == 0)
        {
            c->Gto                  *= 4;
            c->GKr                  *= 1.3;
            c->GKs                  *= 1.4;
            c->GK1                  *= 1.2;
            c->GNaL                 *= 0.6;
        }
        else
        {
            printf("***ERROR: Celltype %s- has no entry for %s cell model\n\n", c->celltype, Ionic_model);
            exit(EXIT_FAILURE);
        }
    }
    // End ORd =====================================================//
}
// End het =============================================================================//

// Modulation parameters (remodelling, autonomic, pharmacological ========================
// ** Ensure that these functions update (rather than set) variables, such that preceeding cell het etc is not overwritten **
void set_scale_factors_modulation_integrated(Current_variables *c, Dyad_variables *d, SR_fluxes *sr, Membrane_fluxes *mem, double ISO, char const *Remodelling, char const *Drug, char const *Ionic_model)
{
        // Toy Isoprenaline model ; this is NOT a physiological model
        // but rather an approximation suitable for SR loading
        c->GKr                  *= (1.0 + ISO*2);
        c->GK1                  *= (1.0 - ISO*0.25);
        d->LTCC_Po              *= (1.0 + ISO*1.25);
        sr->Gup                 *= (1.0 + ISO*2);
    
    // Have any remodelling or drug modulation in here
}
// End modulation ======================================================================//
