// Global membrane functions

#include "Membrane.h"

// Here are defined all the "Global functions" in Membrane.h

// Comp and update ionic currents functions ==============================================
void compute_Itot_integrated(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt, const char *Ionic_model)
{
    if (strcmp(Ionic_model, "ORd") == 0) //lib/Membrane_ORd_currents.c
    {
        comp_Erevs(p, c);
        set_gate_rates_ORd(p, c, Vm); // Sets all transition rates (inc SS, tau) :: NOT NEEDED IF USING LOOKUP
        update_gates_ORd(p, c, s, Vm, dt); // Updates the gating variables (state variables)
        compute_Itot_ORd_integrated(p, c, s, Vm); // Computes all currents        
    }
}
// End ionic currents functions ========================================================//

// Initial conditions ====================================================================
void initial_conditions_membrane(State_variables *s, const char *Ionic_model)
{
    // Vm (mV)
    s->Vm               = -85;

    // INa state
    s->INa_va           =  0.001231;
    s->INa_vi_1         =  0.992842;
    s->INa_vi_2         =  0.988864;

    // INaL state
    s->INaL_va          = 0.000195011;
    s->INaL_vi          = 0.438143;

    // Ito state
    s->Ito_va               = 0;
    s->Ito_vi               = 1;
    s->Ito_vi_f             = 0.999539;
    s->Ito_vi_s             = 0.361531;

    // ICaL state
    s->ICaL_va              = 0;
    s->ICaL_vi              = 1;

    // IKur state
    s->IKur_va              = 0;
    s->IKur_vi              = 1;

    // IKr state
    s->IKr_va               = 0.000175; 
    s->IKr_va_f             = 0.000264226;
    s->IKr_va_s             = 0.669037;

    // IKs state
    s->IKs_va_1             = 0.397626;
    s->IKs_va_2             = 0.000197522;

    // IK1
    s->IK1_va               = 0.99681;
}
// End initial conditions ==============================================================//

// Integrator methods ====================================================================
double rush_larsen(double y, double ss, double tau, double dt)
{
    double gate;
    gate = ss - (ss-y)*exp(-dt/tau);
    return gate; 
}
// End integrator ======================================================================//

// Stimulus current functions ============================================================
void Stim_setup(Current_variables *c, int BCL, int S2, double dt)
{
    c->stimduration          = 0.5;
    c->durationint           = c->stimduration*(1/dt);

    c->stimmag               = -80.00;

    c->intBCL                = BCL * (int)(1/dt);

    c->stimflag              = 0;
    c->stimcount             = 0;

    c->stimflag_S2           = 0;
    c->stimcount_S2          = 0;

    c->Istim                 = 0.0;
    c->Istim_S2              = 0.0;

}

void comp_Istim(Current_variables *c, double Stim_period, double time, int time_int)
{
    if((time_int == 0 || time_int%c->intBCL == 0) && time < Stim_period) // Determine if within integer step corresponding to stimulus
    {
        c->stimflag          = 1;
    }  // no else, as flag is set in next part back to 0 only if 1 in the first place

    if (c->stimflag == 1)
    {
        c->Istim = c->stimmag; // set stimulus current to its magnitude
        c->stimcount++;
        if (c->stimcount >= c->durationint){
            c->stimflag = 0;
            c->stimcount = 0;
        } // end if
    } // end if
    else c->Istim = 0;      
}

void comp_Istim_S2(Current_variables *c, double Stim_period, double S2, double time, int time_int)
{
    if (c->stimflag_S2 == 0 && time > Stim_period +S2)
    {
        c->stimflag_S2 = 1;
    }

    if (c->stimflag_S2 == 1)
    {
        c->Istim_S2 = c->stimmag; // set stimulus current to its magnitude
        c->stimcount_S2++;
        if (c->stimcount_S2 >= c->durationint){
            c->stimflag_S2 = 2;
            c->stimcount_S2 = 0;
        } // end if

    }
    else c->Istim_S2 = 0;
}
// End Stimulus current functions ======================================================//

// Exictation properties and measurement variable functions ==============================
void initiate_measurement_variables(Current_variables *c)
{
    c->dvdt                 = 0;     // rate of change of voltage respect to time
    c->dvdt_max             = 0;     // max dvdt (updated per excitation)
    c->t_ex                 = -100;  // time of excitation
    c->ex_switch            = 0;     // Not in excitation mode
    c->APD                  = 0;     // APD
    c->apd_switch           = 1;     // Set to "calculated" as default, as will be set to 0 when cell is excited
}

// ex threshold is the voltage above which it is excited
// ; rep_threshold is below which it is no longer excited
void determine_excitation_state_integrated(Current_variables *c, double *Ca_JSR_t_ex, double Ca_JSR, double Vm, double ex_threshold, double rep_threshold, double time)
{
    if (c->ex_switch == 0) // if currently not in excitation mode
    {
        if (Vm > ex_threshold)
        {
            c->ex_switch = 1; // Set to excitation mode
            c->apd_switch = 0; // ready for APD to be calculated
            c->t_ex = time;
            c->dvdt_max  = 0;
            *Ca_JSR_t_ex = Ca_JSR;
        }
    }
    else if (c->ex_switch == 1) // if it is currently in excitation mode
    {
        if (Vm < rep_threshold)
        {
            c->ex_switch = 0; // Set to not excitation mode
        }
    }
}

void dvdt_and_dvdt_max(Current_variables *c, State_variables s, double Vm, double dt)
{
    c->dvdt = (s.Vm - Vm)/dt; // remeber, Vm is updated at start of next step, so is the V at previous step
    if (c->dvdt > c->dvdt_max) c->dvdt_max = c->dvdt;    
}

void APD_voltage_threshold(Current_variables *c, double Vm, double V_threshold, double time)
{
    if (c->apd_switch == 0) // if in state where APD needs to be calculated
    {
        if (Vm < V_threshold) // if Vm is below determined threshold
        {
            c->APD = time - c->t_ex; // APD is time now minus excitaion time
            c->apd_switch = 1; // set to calculated, so that it will only be set again on next beat       
        }
    }

}
// End excitation propertiers ==========================================================//
