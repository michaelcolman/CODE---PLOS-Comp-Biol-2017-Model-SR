#ifndef PARAMS_H
#define PARAMS_H

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "Arguments.h"

// Define the "Cell_params" struct ======================================================
// This contains all model parameters which are global or constant -/
// NOT an array in tissue models -----------------------------------/

typedef struct{

    // General and global parameters =================================
    double R;       // Ideal gas constant || J mol^-1 K^-1
    double F;       // Faraday constant   || C mmol-1
    double T;       // Temperature || K
    double FRT;     // F/(R*T)

    double Cm;      // Membrane capacitance || pF
    int Ntot_CRUs;  // Total number of CRUs in whole cell
    
    double cao;     // extracellular Ca || mM
    double nao;     // extracellular Na || mM
    double ko;      // extracellular K  || mM

    double nai;     // Intracellular Na (if not variable) 
    double ki;      // Intracellular K (if not variable)
    // End general and global ======================================//

    // Parameters associated with membrane ion currents ==============
    double gNa; // Conductance of sodium current s/mF  (ms/uF | ns/pF)
    double gNaL;// Conductance of late sodium current s/mF
    double gto; // Conductance of transient outward current s/mF
    double gCaL; // Conductance of L-type Ca current s/mF
    double gKur; // Conductance ultra-rapid K+ current s/mF
    double gKr; // Conductance rapid delated K+ current s/mF
    double gK1; // Conductance time-independent K+ current s/mF    
    double gKs; // Conductance IKs              s/mF
    
    double gKb; // Background K+ 
    double PNab;
    // End parameters associated with membrane ion currents ========//

    // Cell structure params =========================================
    double vcyt_CRU;    // volume of bulk intracellulr space associated with a single CRU || microL
    double vss_CRU;
    double vjsr_CRU;    
    double vnsr_CRU;
    double vds_CRU;     // this is the average, as the real volume is varied heterogeneously around this average
    double v_ss_cyt;    // ratio: vss/vcyt
    double v_cyt_nsr;   // vcyt/vnsr
    double v_jsr_nsr;   // vjsr/vnsr
    // End cell structure ==========================================//

    // Diffusion time constants ======================================
    double tau_ss_cyt;      // time constant transfer ss to cyto ms
    double tau_ds;          // time-constant in DS (including ds->ss transfer) ms
    double tau_nsr_jsr;     // time-constant transfer nsr to jsr

    double tau_cyt_long;    // time-constant of spatial diffusion, cytoplasm, longitudinal
    double tau_cyt_trans;   // time-constant of spatial diffusion, cytoplasm, transverse
    double tau_ss_long;
    double tau_ss_trans;
    double tau_sr_long;
    double tau_sr_trans;
    // End Diffusion time constants ================================//

    // Jup and Jleak params ==========================================
    double rup;         // Maximal rate of Jup || microM ms-1
    double Hup;         // Power constant for Jup and Jleak
    double Kup_i;       // intracellular Ca constant for Jup || microM
    double Kup_nsr;     // nsr-dependent constant for Jup    || microM

    double rleak;       // maximal rate of Jleak || ms^-1
    double Kleak;       // constant for Kleak || microM
    // End Jup and Jleak ===========================================//

    // Dyad params ===================================================
    // ICaL / LTCC
    int NLTCC;          // Number channels per dyad, global
    double rLTCC;       // Maximal flux rate LTCC per channel   micro mol C-1 ms^-1
    double ICaL_Por;    // Open rate for voltage-independent activation
    double ICaL_Pcr;    // Closed rate for voltage-independent activation
    double ICaL_Ca_bar; // Maximal Ca for inactivation, microM
    double gammaCa;     // Activity coefficient

    // RyR
    int NRyR;           // Number channels per dyad, global
    double rRyR;        // Maximal flux rate through RyR micro m ^3 ms ^-1
    double RyR_Po;      // Open rate ms^-1
    double RyR_power;   // Power Ca_ds is raised to
    double RyR_Koc;     // Open-closed rate, Ca indepdent

    // RyR csqn inactivation
    double RyR_monomer_tau; // baseline time constant mononer form  || ms
    double RyR_mi_tau;      // baseline time constant inactivation by monomer || ms
    double RyR_monomer_beta_tau;  // different time constant for the beta transition rate (not stricly THE time constant then....)
    double RyR_mi_beta_tau;       // same for inactivation unbinding
    double RyR_monomer_grad;        // scales the gradient of the monomer/inactivation relationship
    // End dyad params =============================================//

    // ICa params ====================================================
    double SS_prop;     // proportion of INaCa (and others) in subspace vs bulk space

    // INaCa
    double rNaCa;       // Maximal rate of sodium-calcium exchanger microM .ms^-1
    double INaCa_KCai;  // Cai constant INaCa || microM
    double INaCa_KCao;  // mM
    double INaCa_KNai;  // Nai constant || mM
    double INaCa_KNao;  // mM
    double INaCa_Kda;   // Ca2+ scaling microM
    double INaCa_Ksat;  // Saturation constant
    double INaCa_eta;   // Voltage-sensitivity coefficient

    // ICab
    double rCab;        // maximal rate background Ca current || microM . ms^-1. mV^-1
    double rCap;        // maximal rate PMCA                  || microM . ms^-1
    // End INaCa params ============================================//

    // Buffering parameters ==========================================
    double Kcam;        // Dissasociation constant for calmodulin || microM
    double Bcam;        // Total conc buffering sites calmodulin  || microM
    double Kbsr;        // Dissasociation constant for SR         || microM
    double Bbsr;        // Total conc buffering sites             || microM
    double Kmca;        // Dissasociation constant for myosin     || microM
    double Bmca;        // Total conc buffering sites myosin      || microM
    double Kmmg;        // Dissasociation constant for myosin mg  || microM
    double Bmmg;        // Total conc buffering sites myosin  mg  || microM

    // JSR buffering
    double Kcsqn;       // Dissasociation constant csqn           || mM
    double Bcsqn;       // Total buffering sites csqn             || mM
    // End Buffering parameters ====================================//

    // Full structural model ratios ==================================
    double N_mem_dyads; // ratio of voxels in membrane to number of dyads (mem > dyads)
    double N_cyto_mem;  // ratio of voxels cytoplasm to membrane          (cyto > mem) 
    double N_cyto_SR;   // ratio of number voxels cytoplasm vs SR 
    // End full struct ratios ======================================//

    // Lookup tables =================================================
    // Voltage table ===================
    double * LK_V;  // Lookup table for voltage
    int NV;         // Number of voltage steps 
    int Nva;        // Number of variables in table
    int V_gain;     // Integer number of voltage steps per mV || determine lookup table index
    int V_offset;   // Determine lookup table index
    int size;       // Total size of table
    
        // set variables to integers for table indexes
        int INa_va_ss;
        int INa_va_tau;
        int INa_vi_1_ss;
        int INa_vi_1_tau;
        int INa_vi_2_ss;
        int INa_vi_2_tau;
        int Ito_va_tau;      
        int Ito_vi_tau;      
        int Ito_va_ss;       
        int Ito_vi_ss;  
        int ICaL_va_tau;         
        int ICaL_vi_tau;         
        int ICaL_va_ss;          
        int ICaL_vi_ss;
        int IKur_va_tau;         
        int IKur_vi_tau;         
        int IKur_va_ss;          
        int IKur_vi_ss;
        int IKr_va_ss;
        int IKr_va_tau;
        int IKr_vi_ti;
        int IK1_va_ti;
        // End variable interger indexes
    // End voltage table =============//
    // End lookup tables ===========================================//

} Cell_params;

void Set_params_default(Cell_params *params, int red_factor);
void update_default_params(Cell_params *p, const char * Ionic_model);
void set_params_full_struct_no_SS(Cell_params *p, const char * Ionic_model);

#endif
