#include "FDM.h"
#include <fstream>
#include <stdlib.h>
#include <string.h>

// Set array sizes
void FDM_set_array_sizes(FDM_variables *fdm, int NX, int NY, int NZ)
{
    fdm->NX = NX;
    fdm->NY = NY;
    fdm->NZ = NZ;
}

// Allocate spatial arrays ===============================================================
void FDM_array_allocation_N(FDM_variables *fdm) // allocates arrays which are total size
{
    int N = fdm->NX * fdm->NY * fdm->NZ;
    fdm->geo            = new int[N];
    fdm->geo_index      = new int[N];
}

void FDM_array_allocation_Ncell(FDM_variables *fdm)
{
    int Ncell = fdm->Ncell;
    //printf("Allocating Ncell arrays of size %d\n", Ncell);

    fdm->geo_linear     = new int [Ncell];

    fdm->D              = new double [Ncell];
    fdm->diff           = new double [Ncell];
    fdm->buff           = new double [Ncell];

    fdm->x_minus        = new int[Ncell];
    fdm->x_plus         = new int[Ncell];
    fdm->y_minus        = new int[Ncell];
    fdm->y_plus         = new int[Ncell];
    fdm->z_minus        = new int[Ncell];
    fdm->z_plus         = new int[Ncell];

    //printf("Allocated Ncell arrays of size %d\n", Ncell);

}

void FDM_array_deallocation(FDM_variables *fdm)
{
    delete [] fdm->geo;
    delete [] fdm->geo_index;
    delete [] fdm->geo_linear;
    delete [] fdm->D;
    delete [] fdm->diff;
    delete [] fdm->buff;
    delete [] fdm->x_minus;
    delete [] fdm->x_plus;
    delete [] fdm->y_minus;
    delete [] fdm->y_plus;
    delete [] fdm->z_minus;
    delete [] fdm->z_plus;
}
// End array allocation ================================================================//

// Set the linear index for ==============================================================
void set_cell_index(FDM_variables *fdm)
{
    int count = 0;
    int idx;

    for (int k = 0; k < fdm->NZ; k++)
    {
        for (int j = 0; j < fdm->NY; j++)
        {
            for (int i = 0; i < fdm->NX; i++)
            {
                idx = i + (fdm->NX*j) + (fdm->NX * fdm->NY * k);
                if (fdm->geo[idx] > 0) // if it is an actual cell/node
                {
                    fdm->geo_index[idx] = count; // gives the 1D cell count at 3D idx
                    fdm->geo_linear[count] = fdm->geo[idx]; // Set linear cell to 3D cell
                    count++;
                }   
            }
        }
    }   
    //printf("linear geoemetry index set\n");
}
// end Set the linear index for different dimensional models============================//

// Populate neighbour maps ===============================================================
void FDM_set_neighbours(FDM_variables *fdm, const char *Tissue_type)
{
    if (strcmp(Tissue_type, "1D") == 0)             FDM_set_neighbours_1D(fdm);
    else if (strcmp(Tissue_type, "2D") == 0)        FDM_set_neighbours_2D(fdm);
    else                                            FDM_set_neighbours_3D(fdm); // 3D and 3D geo
}

void FDM_set_neighbours_1D(FDM_variables *fdm)
{
    int count = 0;

    //printf("Setting neighbour map, 1D\n");

    for (int i = 0; i < fdm->NX; i++)
    {
        if (fdm->geo[i] > 0)
        {
            if (i == 0)                 fdm->x_minus[count] = count; // if at edge (small x), then apply BC (neighbour is itself)
            else if (fdm->geo[i-1] < 1) fdm->x_minus[count] = count; // if not edge but neighbour not cell, also apply BC
            else                        fdm->x_minus[count] = fdm->geo_index[i-1]; // otherwise, pass the index of the neighbour 
    
            if (i == fdm->NX-1)         fdm->x_plus[count] = count;
            else if (fdm->geo[i+1] < 1) fdm->x_plus[count] = count;
            else                        fdm->x_plus[count] = fdm->geo_index[i+1];

            count++;
        }
    }
    //printf("Neighbour map set, 1D\n");
}

void FDM_set_neighbours_2D(FDM_variables *fdm)
{
    int count = 0;
    int idx;

    //printf("Setting neighbour map, 2D\n");

    for (int j = 0; j < fdm->NY; j++)
    {
        for (int i = 0; i < fdm->NX; i++)
        {
            idx = i + (fdm->NX*j);
            if (fdm->geo[idx] > 0)
            {
                // x direction
                if (i == 0)                                         fdm->x_minus[count] = count; // if at edge (small x), then apply BC (neighbour is itself)
                else if (fdm->geo[ (i-1) + (fdm->NX*(j)) ] < 1)     fdm->x_minus[count] = count; // if not edge but neighbour not cell, also apply BC (x-1), y
                else                                                fdm->x_minus[count] = fdm->geo_index[ (i-1) + (fdm->NX*(j)) ]; // otherwise, pass the index of the neighbour (x-1), y

                if (i == fdm->NX-1)                                 fdm->x_plus[count] = count;
                else if (fdm->geo[ (i+1) + (fdm->NX*(j)) ] < 1)     fdm->x_plus[count] = count;
                else                                                fdm->x_plus[count] = fdm->geo_index[ (i+1) + (fdm->NX*(j)) ];

                // y direction
                if (j == 0)                                         fdm->y_minus[count] = count; // if at edge (small y), then apply BC (neighbour is itself)
                else if (fdm->geo[ (i) + (fdm->NX*(j-1)) ] < 1)     fdm->y_minus[count] = count; // if not edge but neighbour not cell, also apply BC (y-1), y
                else                                                fdm->y_minus[count] = fdm->geo_index[ (i) + (fdm->NX*(j-1)) ]; // otherwise, pass the index of the neighbour x, (y-1)

                if (j == fdm->NY-1)                                 fdm->y_plus[count] = count;
                else if (fdm->geo[ (i) + (fdm->NX*(j+1)) ] < 1)     fdm->y_plus[count] = count;
                else                                                fdm->y_plus[count] = fdm->geo_index[ (i) + (fdm->NX*(j+1)) ];

                count++;
            }
        }
    }
    //printf("Neighbour map set, 2D\n");
}

void FDM_set_neighbours_3D(FDM_variables *fdm)
{
    int count = 0;
    int idx;

    //printf("Setting neighbour map, 3D\n");

    for (int k = 0; k < fdm->NZ; k++)
    {
        for (int j = 0; j < fdm->NY; j++)
        {
            for (int i = 0; i < fdm->NX; i++)
            {
                idx = i + (fdm->NX*j) + (fdm->NX*fdm->NY*(k));
                if (fdm->geo[idx] > 0)
                {
                    // x direction
                    if (i == 0)                                                             fdm->x_minus[count]     = count; // if at edge (small x), then apply BC (neighbour is itself)
                    else if (fdm->geo[ (i-1) + (fdm->NX*(j)) + (fdm->NX*fdm->NY*(k)) ] < 1) fdm->x_minus[count]     = count; // if not edge but neighbour not cell, also apply BC (x-1), y
                    else                                                                    fdm->x_minus[count]     = fdm->geo_index[ (i-1) + (fdm->NX*(j)) + (fdm->NX*fdm->NY*(k)) ]; // otherwise, pass the index of the neighbour (x-1), y

                    if (i == fdm->NX-1)                                                     fdm->x_plus[count]      = count;
                    else if (fdm->geo[ (i+1) + (fdm->NX*(j)) + (fdm->NX*fdm->NY*(k)) ] < 1) fdm->x_plus[count]      = count;
                    else                                                                    fdm->x_plus[count]      = fdm->geo_index[ (i+1) + (fdm->NX*(j)) + (fdm->NX*fdm->NY*(k)) ];

                    // y direction
                    if (j == 0)                                                             fdm->y_minus[count]     = count; // if at edge (small y), then apply BC (neighbour is itself)
                    else if (fdm->geo[ (i) + (fdm->NX*(j-1)) + (fdm->NX*fdm->NY*(k)) ] < 1) fdm->y_minus[count]     = count; // if not edge but neighbour not cell, also apply BC (y-1), y
                    else                                                                    fdm->y_minus[count]     = fdm->geo_index[ (i) + (fdm->NX*(j-1)) + (fdm->NX*fdm->NY*(k)) ]; // otherwise, pass the index of the neighbour x, (y-1)

                    if (j == fdm->NY-1)                                                     fdm->y_plus[count]      = count;
                    else if (fdm->geo[ (i) + (fdm->NX*(j+1)) + (fdm->NX*fdm->NY*(k)) ] < 1) fdm->y_plus[count]      = count;
                    else                                                                    fdm->y_plus[count]      = fdm->geo_index[ (i) + (fdm->NX*(j+1)) + (fdm->NX*fdm->NY*(k)) ];

                    // z direction
                    if (k == 0)                                                             fdm->z_minus[count]     = count; // if at edge (small z), then apply BC (neighbour is itself)
                    else if (fdm->geo[ (i) + (fdm->NX*(j)) + (fdm->NX*fdm->NY*(k-1)) ] < 1) fdm->z_minus[count]     = count; // if not edge but neighbour not cell, also apply BC (z-1), y
                    else                                                                    fdm->z_minus[count]     = fdm->geo_index[ (i) + (fdm->NX*(j)) + (fdm->NX*fdm->NY*(k-1)) ]; // otherwise, pass the index of the neighbour x,y, z-1 

                    if (k == fdm->NZ-1)                                                     fdm->z_plus[count]      = count;
                    else if (fdm->geo[ (i) + (fdm->NX*(j)) + (fdm->NX*fdm->NY*(k+1)) ] < 1) fdm->z_plus[count]      = count;
                    else                                                                    fdm->z_plus[count]      = fdm->geo_index[ (i) + (fdm->NX*(j)) + (fdm->NX*fdm->NY*(k+1)) ];
                    count++;
                }
            }
        }
    }
    //printf("Neighbour map set, 3D || count check = %d\n", count);
}
// End neighbour maps ==================================================================//

// Diffusion parameters ==================================================================
void set_D_dx(FDM_variables *fdm, double dx, double D1, double D2)
{
    fdm->dx = dx;
    fdm->D1 = D1;
    fdm->D2 = D2;
}

void set_D_isotropic(FDM_variables *fdm)
{
    for (int i = 0; i < fdm->Ncell; i++)
    {
        fdm->D[i] = fdm->D1; // for isotropic, set D in all space to be D1
    }
}
// End diffusion parameters ============================================================//

// Actual FDM coupling functions =========================================================
void calc_diff_1D_iso(FDM_variables *fdm, double *v, int i)
{
    // (v_x-1 + v_x+1 - 2*v_x) / (dx^2)
    // Recall that x_minus[i] = index of cell x -1 to cell ; v[x_minus[i]] = the variable value in that cell
    fdm->diff[i] = fdm->D[i] * ( (v[fdm->x_minus[i]] + v[fdm->x_plus[i]] - 2*v[i])/(fdm->dx*fdm->dx) );
}

void calc_diff_2D_iso(FDM_variables *fdm, double *v, int i)
{
    // (v_x-1 + v_x+1 - 2*v_x) / (dx^2)
    // Recall that x_minus[i] = index of cell x -1 to cell ; v[x_minus[i]] = the variable value in that cell
    fdm->diff[i]    =   fdm->D[i] * ( (v[fdm->x_minus[i]] + v[fdm->x_plus[i]] - 2*v[i])/(fdm->dx*fdm->dx) );
    fdm->diff[i]    +=  fdm->D[i] * ( (v[fdm->y_minus[i]] + v[fdm->y_plus[i]] - 2*v[i])/(fdm->dx*fdm->dx) );
}

void calc_diff_3D_iso(FDM_variables *fdm, double *v, int i)
{
    // (v_x-1 + v_x+1 - 2*v_x) / (dx^2)
    // Recall that x_minus[i] = index of cell x -1 to cell ; v[x_minus[i]] = the variable value in that cell
    fdm->diff[i]    =   fdm->D[i] * ( (v[fdm->x_minus[i]] + v[fdm->x_plus[i]] - 2*v[i])/(fdm->dx*fdm->dx) );
    fdm->diff[i]    +=  fdm->D[i] * ( (v[fdm->y_minus[i]] + v[fdm->y_plus[i]] - 2*v[i])/(fdm->dx*fdm->dx) );
    fdm->diff[i]    +=  fdm->D[i] * ( (v[fdm->z_minus[i]] + v[fdm->z_plus[i]] - 2*v[i])/(fdm->dx*fdm->dx) );
}

void calc_diff_3D_time_constant(FDM_variables *fdm, double *v, int i, double tau_trans, double tau_long)
{
    fdm->diff[i]    =  (v[fdm->x_minus[i]] + v[fdm->x_plus[i]] - 2*v[i])/tau_trans;
    fdm->diff[i]    += (v[fdm->y_minus[i]] + v[fdm->y_plus[i]] - 2*v[i])/tau_trans;
    fdm->diff[i]    += (v[fdm->z_minus[i]] + v[fdm->z_plus[i]] - 2*v[i])/tau_long; // z is longitudinal direction
}
// End FDM coupling functions ==========================================================//
