#ifndef MODULATION_H
#define MODULATION_H

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Arguments.h"
#include "Membrane.h"
#include "Params.h"
#include "CRU.h"

// Model variables which determine het and moulation
void Set_variables_from_arguments(Argument_parameters A, Current_variables *c);
void Set_variables_from_arguments_integrated(Argument_parameters A, Current_variables *c, Dyad_variables *d, SR_fluxes *sr, Membrane_fluxes *mem);

// Heterogeneity scale factors =========
void set_scale_factor_defaults_integrated(Current_variables *c, Dyad_variables *d, SR_fluxes *sr, Membrane_fluxes *mem);

void set_scale_factors_het_integrated(Cell_params p, Current_variables *c, Dyad_variables *d, SR_fluxes *sr, Membrane_fluxes *mem, char const *Ionic_model);
// End het ===========================//

// Modulation scale factors ============
void set_scale_factors_modulation_integrated(Current_variables *c, Dyad_variables *d, SR_fluxes *sr, Membrane_fluxes *mem, double ISO, char const *Remodelling, char const *Drug, char const *Ionic_model);

#endif


