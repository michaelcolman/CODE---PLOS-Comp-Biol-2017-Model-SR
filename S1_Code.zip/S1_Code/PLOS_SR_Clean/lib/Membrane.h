#ifndef CURRENTS_H
#define CURRENTS_H

#include <math.h>
#include "Params.h"
#include "Arguments.h"

// STRUCTS ****************************************************************************************

// Define the "State_variables" struct ==================================================
// This contains all of the time-dependent variables which must ----/
// be tracked by the ionic model for numerical integration ---------/
typedef struct{

    //Voltage
    double Vm; // mV

    // Fast sodim current / "Phase 1 depolarising current" ===========
    double INa_va;      // voltage-dependent activation gate
    double INa_vi_1;    // voltage-dependent inactivation gate 1
    double INa_vi_2;    // voltage-dependent inactivation gate 2
    // End fast sodium current =====================================//
    
    // Late sodim current / "Phase 1 depolarising current" ===========
    double INaL_va;      // voltage-dependent activation gate
    double INaL_vi;      // voltage-dependent inactivation gate 
    // End Late sodium current =====================================//

    // Transient outward / "Phase 1 repolarising current" ============
    double Ito_va;      // voltage-dependent activation gate
    double Ito_vi;      // voltage-dependent inactivation gate

    double Ito_vi_f;    // fast inactivation gate
    double Ito_vi_s;    // slow inactivation gate
    // End transient outward current ===============================//
    
    // "ICaL" (non spatial) / "Phase 2 depolarising current" =========
    double ICaL_va;      // voltage-dependent activation gate
    double ICaL_vi;      // voltage-dependent inactivation gate
    // End ICaL non sptial current =================================//
    
    // Ultra-Rapid Potassium (IKur) / "Phase 2 repolarising current"==
    double IKur_va;      // voltage-dependent activation gate
    double IKur_vi;      // voltage-dependent inactivation gate
    // End IKur =================== ================================//
    
    // Rapid Potassium (IKr) / "Phase 3 repolarising current" ========
    double IKr_va;      // voltage-dependent activation gate

    double IKr_va_f;    // fast
    double IKr_va_s;    // slow
    // End IKr =====================================================//

    // IKs ===========================================================
    double IKs_va_1;
    double IKs_va_2;
    // End IKs =====================================================//
    
    // IK1 ORd
    double IK1_va;

} State_variables;
// End "State_variables" struct =======================================================//


// Define the "Current_variables" struct ================================================
// This contains non-state variables, which are computed multiple ---/
// times, or control heterogeneity ----------------------------------/
// This struct is an array in tissue models -------------------------/
typedef struct{

    // Cell model, type and modulation ===============================
    char const *Ionic_model;    // The ionic model used
    char const *celltype;               // controls the celltype/region of the cell model
    double ISO;                 // ISO concentration (microM)
    char const *Remodelling;    // Remodelling
    char const *Drug;           // Pharmacological agent
    // End cell model, type and modulation =========================//

    // Cai for Ca-dependent currets (NOT Ca currents)
    double Cai;

    // Currents ======================================================
    double Itot;    // Total ionic current A/F (i.e. "pA/pF")
    double INa;     // A/F
    double INaL;    // A/F
    double Ito;     // A/F
    double ICaL;    // Whole-cell ICaL / minimal model ICaL A/F
    double IKur;    // A/F
    double IKr;     // A/F
    double IKs;     // A/F
    double IK1;     // A/F

    double IKb;     // Background K+, A/F
    double INab;    // Background Na+
    
    // Ca currents
    double INaCa;   // sodium-calcium exchanger A/F
    double INaCa_ss;   
    double ICab;
    double ICab_ss;
    double ICap;
    double ICap_ss; 
    // End currents ================================================//

    // Reversal potentials ===========================================
    double ENa;             // Reversal potential Na, mV
    double EK;              // Potassium
    double EKs;             // IKs (mixed potassoim sodium)
    // End reversal potentials =====================================//

    // Variables associated with currents ============================
    // Fast sodium current =============
    double INa_va_al;       // alpha rate constant for INa_va : ms^-1
    double INa_va_b;        // beta rate constant for INa_va   : ms^-1
    double INa_vi_1_al;     // ms^-1
    double INa_vi_1_b;      // ms^-1
    double INa_vi_2_al;     //ms^-1
    double INa_vi_2_b;      // ms^-1
    double INa_va_tau;      // time constant of INa_va       : ms
    double INa_vi_1_tau;    // ms
    double INa_vi_2_tau;    // ms
    double INa_va_ss;       // Steady-state of INa_va gate
    double INa_vi_1_ss;     // Steady-state of INa_vi_1 gate
    double INa_vi_2_ss;     // Steady-state of INa_vi_2 gate
    // End Fast sodium current =======//

    // Late sodium current =============
    double INaL_va_ss;      // steady state voltage activation
    double INaL_va_tau;     // time constant voltage activation
    double INaL_vi_ss;      // inac 
    double INaL_vi_tau;   
    // End late sodium ===============//

    // Transient outward current =======
    double Ito_va_tau;      // time constant voltage activation
    double Ito_vi_tau;      // time constant voltage inactivation
    double Ito_va_ss;       // Steady-state voltage activation
    double Ito_vi_ss;       // Steady-state voltage inactivation

    double Ito_vi_f_tau;    // time constant fast inactivation || ORd model
    double Ito_vi_s_tau;    // time constant slow inactivation

    double Ito_vi_pF;       // proportion of fast inactivation gate || ORd model
    double Ito_vi_pS;       // proportion of slow inactivation gate
    // End Transient outward =========//

    // ICaL minimal current =========
    double ICaL_va_tau;      // time constant voltage activation
    double ICaL_vi_tau;      // time constant voltage inactivation
    double ICaL_va_ss;       // Steady-state voltage activation
    double ICaL_vi_ss;       // Steady-state voltage inactivation
    // End Transient outward =========//

    // Ultra-rapid potassium ===========
    double IKur_va_tau;      // time constant voltage activation
    double IKur_vi_tau;      // time constant voltage inactivation
    double IKur_va_ss;       // Steady-state voltage activation
    double IKur_vi_ss;       // Steady-state voltage inactivation
    // End ultra rapid  K+ ===========//

    // Rapid delayed potassium =========
    double IKr_va_al;       // alpha for activation gate
    double IKr_va_b;        // beta activation gate
    double IKr_va_tau;      // time constant voltage activation
    double IKr_va_ss;       // Steady-state voltage activation
    double IKr_vi_ti;       // Time-independent voltage inactivation

    double IKr_va_f_tau;    // time constant fast activation
    double IKr_va_s_tau;

    double IKr_va_pF;       // proprtion of activation gate fasr
    double IKr_va_pS;       // slow
    // End rapid  K+ =================//

    // Slow delayed potassium ==========
    double IKs_va_ss;       // steady state
    double IKs_va_1_tau;    // time constant 1
    double IKs_va_2_tau;
    double IKs_ca_ti;       // Ca, time-independent activation
    // End IKs =======================//

    // Time-independent K+ current =====
    double IK1_va_ti;       // Voltage-dependent time-independent gate
    
    // ORd 
    double IK1_va_ss;
    double IK1_va_tau;
    // End IK1 =======================//

    // Background currents =============
    double IKb_x;
    double vffrt;
    double vfrt;
    double FNab;
    // End background ================//
    // End variables associated with currents ======================//

    // Stimulus variables ============================================
    double stimduration; // duration of stimulus current : ms
    int    durationint; // integer value of duration
    double stimmag; // magnitude of stimulus current : pA/pF
    int    intBCL; // integer counter equivlent of BCL 
    int    stimflag; // flag variable for whetther or not to apply stimulus
    int    stimcount; // counter of number of times stim has been applied

    int    stimflag_S2; // flag for S2 stimulus
    int    stimcount_S2; // counter for S2 stimulus

    double Istim;       // Stimulus current
    double Istim_S2;    // Stimulus current for S2
    // End stimulus variables ======================================//

    // Current scale factors =========================================
    // (to control het / remodelling / pharmacological modulation ====
    double GNa; // scales fast sodium current
    double GNaL; 
    double Gto; // scales Ito / Ip1r
    double GCaL; // scales ICaL non-spatial / Ip2d
    double GKur;  // IKur / Ip2r
    double GKr; // IKr / Ip3r 
    double GK1; // IK1 / Ip4r (resting potential)
    double GKs; // IKs scale

    double GKb; 
    double GNab;

    double Ito_va_ss_vshift; // Shift of the V1/2 of Ito voltage activation
    // End current scale factors ===================================//

    // Measurement variables / excitation properties =================
    double dvdt;        // rate of change of voltage respect to time
    double dvdt_max;    // max dvdt (updated per excitation)
    double t_ex;        // time of excitation
    int    ex_switch;   // switch which determines if cell is in excitation state (0 = not excited; 1 = excited)
    int    apd_switch;  // switch for if APD has been calculated on this beat (0 = not calculated; 1 = calculated)
    double APD;         // APD 
    // End measurement variables ===================================// 

    // Lookup table index variables :: here as vary per cell in tissue
    int Vm_int;         // Integer counter of V for lookup
    int lk_index;       // index for lookup table item
    // End lookup table index ======================================//

} Current_variables;
// End "Current_variables" struct ======================================================//



// FUNCTIONS **************************************************************************************

// Global functions ======================================================================
// lib/Membrane.c
//Compute and update currents
void compute_Itot_integrated(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt, const char *Ionic_model);

// Initial conditions
void initial_conditions_membrane(State_variables *s, const char * Ionic_model); // Sets initial conditions for the state variables

// Rush larsen method
double rush_larsen(double y, double ss, double tau, double dt);

// Stim current
void Stim_setup(Current_variables *c, int BCL, int S2, double dt);
void comp_Istim(Current_variables *c, double Stim_period, double time, int time_int);
void comp_Istim_S2(Current_variables *c, double Stim_period, double S2, double time, int time_int);

// Measurement variables
void initiate_measurement_variables(Current_variables *c); // Sets initial values
void determine_excitation_state_integrated(Current_variables *c, double *Ca_JSR_t_ex, double Ca_JSR, double Vm, double ex_threshold, double rep_threshold, double time); // also sets Ca_JSR t_ex
void dvdt_and_dvdt_max(Current_variables *c, State_variables s, double Vm, double dt); // computes dvdt and updated dvdt_max
void APD_voltage_threshold(Current_variables *c, double Vm, double V_threshold, double time); // determines APD at specific voltage threshold
// End global functions ================================================================//

// Compute and update ion currents =======================================================
// INa used in multiple models (All in lib/Membrane_ORd_currents.cpp, as this is first full model integrated)
void compute_INa(Cell_params p, Current_variables *c, State_variables *s, double Vm); // Computes the current
void set_INa_rates(Cell_params p, Current_variables *c, double Vm); // Sets the transition rates, tau and steady state
void update_gates_INa(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt); // Updates the gating variables
void comp_Erevs(Cell_params p, Current_variables *c); 

// minimal model =====================================================
// ORd model =========================================================
void compute_Itot_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm); // Computes all currents
void set_gate_rates_ORd(Cell_params p, Current_variables *c, double Vm); // Sets all transition rates (inc SS, tau)
void update_gates_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt); // Updates gates
void compute_Itot_ORd_integrated(Cell_params p, Current_variables *c, State_variables *s, double Vm); // compute Itot integrated

void compute_INaL_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm); // Computes the current
void set_INaL_rates_ORd(Cell_params p, Current_variables *c, double Vm); // Sets the transition rates, tau and steady state
void update_gates_INaL_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt); // Updates the gating variables

void compute_Ito_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm); // Computes the current
void set_Ito_rates_ORd(Cell_params p, Current_variables *c, double Vm); // Sets the transition rates, tau and steady state
void update_gates_Ito_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt); // Updates the gating variables

void compute_IKr_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm); // Computes the current
void set_IKr_rates_ORd(Cell_params p, Current_variables *c, double Vm); // Sets the transition rates, tau and steady state
void update_gates_IKr_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt); // Updates the gating variables

void compute_IKs_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm); // Computes the current
void set_IKs_rates_ORd(Cell_params p, Current_variables *c, double Vm); // Sets the transition rates, tau and steady state
void update_gates_IKs_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt); // Updates the gating variables

void compute_IK1_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm); // Computes the current
void set_IK1_rates_ORd(Cell_params p, Current_variables *c, double Vm); // Sets the transition rates, tau and steady state
void update_gates_IK1_ORd(Cell_params p, Current_variables *c, State_variables *s, double Vm, double dt); // Updates the gating variables

void compute_IKb(Cell_params p, Current_variables *c, State_variables *s, double Vm);
void set_variables_IKb(Cell_params p, Current_variables *c, double Vm);
void compute_INab(Cell_params p, Current_variables *c, State_variables *s, double Vm);
void set_variables_INab(Cell_params p, Current_variables *c, double Vm);
// End ORd model ====================================================//
// End compute ion current functions ===================================================//



#endif

