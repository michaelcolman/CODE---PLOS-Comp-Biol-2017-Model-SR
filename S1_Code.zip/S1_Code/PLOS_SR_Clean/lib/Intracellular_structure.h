#ifndef STRUCT_H
#define STRUCT_H

#include <math.h>
#include "FDM.h"
#include "Membrane.h"
#include "Arguments.h"
#include "CRU.h"
#include "Params.h"

typedef struct{

    const char * Structural_model;   // reconstruction datasets, cell size

    double dx;              // space step
    double D;               // Diffusion coefficient um/ms

    // Maps and indexes
    int * Dyad_map;                 // Same for cyto and sr as dyad is both dyadic cleft and JSR
    int * Dyad_cyto_index;          // Takes in dyad number and returns the cyto number to which it corresponds (Ndyads < Ncyto)
    int * Dyad_nsr_index;           // Returns the SR number, which may be different to the cyto at that same voxel

    int * SR_cyto_index;            // relates SR to cyto || SR doesn't need a map as it has an FDM geometry
    int * Mem_map;                  // contains the membrane map
    int * Mem_cyto_index;           // mem to cyto

    int * ss_SS_index;              // relates 1D indexes of high res (in) and low res (out)

    // Sizes
    int Ndyads;     // Number of dyads
    int NSR;        // Number of SR voxels
    int NMem;       // Number of membrane voxels

    // Total sizes
    int NX;
    int NY;
    int NZ;

    // Sizes reduced resolution SS
    int NX2;
    int NY2;
    int NZ2;
    int red_factor; // integer amount by which resolution is down-sampled
    int *Nv1v2;     // Number voxels fine res per reduced res (local, for odd structure)
    int *Nv1v2_linear;  // linearised map

    // files
    const char * cyto_geo_file;
    const char * nsr_geo_file;
    const char * membrane_geo_file;
    const char * dyad_geo_file;
    const char * nsr_neighbour_file;
    

} Intracellular_structural_parameters;

// General settings
void set_array_sizes(Intracellular_structural_parameters *st);
void set_structure_geometry_parameters(Intracellular_structural_parameters *st, const char * Structure_model, const char * Dyad_density);

// Setup functions =======================================================================
void set_and_allocate_FDM_arrays_SS(Intracellular_structural_parameters *st, FDM_variables *fdm_cyto, FDM_variables *fdm_sr, FDM_variables *fdm_ss); // subspace reduced res
void set_and_allocate_FDM_arrays(Intracellular_structural_parameters *st, FDM_variables *fdm_cyto, FDM_variables *fdm_sr); // subspace normal res
void create_or_read_geometries(Intracellular_structural_parameters *st, FDM_variables *fdm_cyto, FDM_variables *fdm_sr, const char * PATH, const char * Structure_model);
void allocate_Ncell_arrays_and_set_linear_geometry_index(Intracellular_structural_parameters *st, FDM_variables *fdm_cyto, FDM_variables *fdm_sr);
void set_dyad_and_membrane_maps(Intracellular_structural_parameters *st, FDM_variables fdm_cyto, const char * PATH, const char * Structure_model);
void set_geometry_relation_indexes(Intracellular_structural_parameters *st, FDM_variables *fdm_cyto, FDM_variables *fdm_sr, const char * Structure_model);


// Idealised geoemtries
void create_idealised_geometry(Intracellular_structural_parameters *st, FDM_variables *fdm);
void create_idealised_dyad_map(Intracellular_structural_parameters *st, int *geo); 

// Real geometries
void read_geometry(Intracellular_structural_parameters *st, FDM_variables *fdm, const char * PATH, const char * file_in);
void read_map(Intracellular_structural_parameters *st, int * map, int *Ncell, const char * PATH, const char * file_in);

void read_SR_neighbours(Intracellular_structural_parameters *st, FDM_variables *fdm, const char * PATH);

// indexes
void create_dyad_cyto_index(Intracellular_structural_parameters *st, int *geo_index, int *geo);
void create_dyad_nsr_index(Intracellular_structural_parameters *st, int *geo_index, int *geo);
void create_Mem_cyto_index(Intracellular_structural_parameters *st, int *geo_index, int *geo);
void create_SR_cyto_index(Intracellular_structural_parameters *st, int *geo_SR, int *geo_cyto_index, int *geo_cyto);

// Reduced resolution function
void create_reduced_resolution_geometry(Intracellular_structural_parameters *st, FDM_variables fdm_cyto, FDM_variables *fdm_ss);
void create_full_reduced_resolution_index(Intracellular_structural_parameters *st, FDM_variables fdm_cyto, FDM_variables fdm_ss);
void map_and_solve_diff_reduced_res_SS(Cell_params p, double * Ca_ss_reduced, FDM_variables *FDM_SS_reduced, FDM_variables FDM_Cyto, Intracellular_structural_parameters st, Ca_variables Ca, double dt);
void map_and_solve_diff_reduced_res_SS_alternative(Cell_params p, double * Ca_ss_reduced, FDM_variables *FDM_SS_reduced, FDM_variables FDM_Cyto, Intracellular_structural_parameters st, Ca_variables Ca, double dt);

// Array allocation / deallocation 
void array_allocation_maps(Intracellular_structural_parameters *st);
void array_allocation_indexes(Intracellular_structural_parameters *st);
void array_deallocation_maps(Intracellular_structural_parameters *st);
void array_deallocation_indexes(Intracellular_structural_parameters *st);

#endif


