#include "Params.h"
#include "Membrane.h"
#include "CRU.h"
#include "FDM.h"
#include "Arguments.h"
#include <fstream>
#include <stdlib.h>

// Initial conditions ====================================================================
void initial_conditions_calcium(Ca_variables *Ca,  Argument_parameters A)
{
    double Cai_IC;
    double SR_IC;
    
    Cai_IC      =   0.08; // microM
    SR_IC       =   800; // microM || 0.8 mM

    if (A.Cai_IC_arg    == 1)       Cai_IC  = A.Cai_IC;
    if (A.Ca_SR_IC_arg  == 1)       SR_IC   = A.Ca_SR_IC;

    Ca->DS      =   Cai_IC;
    Ca->SS      =   Ca->DS;
    Ca->CYTO    =   Ca->DS;

    Ca->NSR     =   SR_IC;
    Ca->JSR     =   Ca->NSR;
}

void initial_conditions_dyad_stochastic(Dyad_variables *d)
{
    for (int i; i < d->NRyR; i++)
    {
        d->RyR_state[i] = 0; // initially in closed state
    }
    d->Monomer      = 0.0;

    for (int i; i < d->NLTCC; i++)
    {
        d->va_state[i] = 0; // initially in closed state of voltage inactivation
        d->vi_state[i] = 1; // initially in not inactivated state
        d->ci_state[i] = 1;
    }
}
// End Initial conditions ==============================================================//

// Compute CRU functons ==================================================================
void comp_J_ds_ss(Cell_params p, Dyad_variables d, double Ca_ds, double Ca_ss, double *reac_ss)
{
    *reac_ss      +=  ((Ca_ds - Ca_ss)/p.tau_ds) * (d.vol_ds/p.vss_CRU);
}

void comp_J_ds_cyto(Cell_params p, Dyad_variables d, double Ca_ds, double Ca_cyto, double *reac_cyto)
{
    *reac_cyto      +=  ((Ca_ds - Ca_cyto)/p.tau_ds) * (d.vol_ds/p.vcyt_CRU);
}

void comp_J_ss_cyto(Cell_params p, Dyad_variables d, double Ca_ss, double Ca_cyto, double *reac_ss, double *reac_cyto)
{
    *reac_ss      += -(Ca_ss - Ca_cyto)/p.tau_ss_cyt;                        // J_ss_cyto, SS reaction
    *reac_cyto    +=  ((Ca_ss - Ca_cyto)/p.tau_ss_cyt)*p.v_ss_cyt;           // J_ss_cyto, CYTO reaction
}

void comp_J_nsr_jsr(Cell_params p, Dyad_variables d, double Ca_nsr, double Ca_jsr, double *reac_nsr, double *reac_jsr)
{
    *reac_jsr     +=  (Ca_nsr - Ca_jsr)/p.tau_nsr_jsr;                       // J_nsr_jsr, JSR reaction
    *reac_nsr     += -((Ca_nsr - Ca_jsr)/p.tau_nsr_jsr)*p.v_jsr_nsr;         // J_nsr_jsr, NSR reaction
}

void comp_dyad_3D(Cell_params p, Dyad_variables *d, double Ca_ds, double Ca_jsr, double Ca_couple, double *reac_jsr, double time, double Vm, double dt)
{
    // RyR stochastic ================================================ 
    set_RyR_rates(p, d, Ca_ds);                                 // Set transition rates
    set_and_update_monomer_state(p, d, 1e-3*Ca_jsr, dt);        // Ca_jsr in mM
    update_RyR_stochastic(d, dt);                               // Update state, monte-carlo
    comp_Krel(p, d, d->NRyR_O1);                                // Comp Krel
    d->Jrel                 = d->Krel*(Ca_jsr - Ca_ds);         // Jrel
    *reac_jsr               += -d->Jrel*(d->vol_ds/p.vjsr_CRU); // Ca JSR reaction term
    // End RyR =====================================================//

    // LTCC ==========================================================
    set_LTCC_rates(p, d, Ca_ds, Vm);        // Set the rates
    comp_ICaL_bar(p, d, Ca_ds, Vm);         // Comp ICaL_bar
    update_LTCC_stochastic(d, dt);          // Update gating variables (monte-carlo)
    d->JCaL = -d->NLTCC_O * d->ICaL_bar;     // compute the flux
    // End LTCC ====================================================//
}

void comp_SR_fluxes(Cell_params p, SR_fluxes *sr, double Ca_cyto, double Ca_nsr, double *reac_cyto, double *reac_nsr)
{
    comp_Jup_Jleak(p, sr, Ca_cyto, Ca_nsr);                   // compute Jup and Jleak
    *reac_cyto       += -(sr->Jup - sr->Jleak);               // Update the reaction of bulk cyto with Jup-Jleak
    *reac_nsr        += (sr->Jup - sr->Jleak)*p.v_cyt_nsr;    // Update the reaction of nsr with Jup-Jleak || recall v_cyt_nsr is the ratio of volumes
}

void comp_membrane_fluxes_struct(Cell_params p, Membrane_fluxes *mem, double Ca_cyto, double Ca_ss, double *reac_cyto, double *reac_ss, double Vm)
{
    compute_JMEM_struct(p, mem, Ca_cyto, Ca_ss, Vm);                 // Calculates fluxes for membrane Ca currents (JNaCa, JCab, JCap)
    *reac_cyto       += mem->JCa;                              // Update cyto reaction term
    *reac_ss         += mem->JCa_ss;                           // Update subspace reaction term
}
// End comp CRU functions ==============================================================//

// Jup and Jleak =========================================================================
void comp_Jup_Jleak(Cell_params p, SR_fluxes *sr, double Ca_cyto, double Ca_nsr)
{
    comp_Jup(p, sr, Ca_cyto, Ca_nsr);
    comp_Jleak(p, sr, Ca_cyto, Ca_nsr);
}

void comp_Jup(Cell_params p, SR_fluxes *sr, double Ca_cyto, double Ca_nsr)
{
    // Formulation from Shannon et al 2004, Biophys J 87:3351-3371
    sr->cai_term = pow(Ca_cyto/p.Kup_i, p.Hup);
    sr->casr_term = pow(Ca_nsr/p.Kup_nsr, p.Hup);

    sr->Jup = sr->Gup * p.rup * ( (sr->cai_term - sr->casr_term)/(1 + sr->cai_term + sr->casr_term) );
}

void comp_Jleak(Cell_params p, SR_fluxes *sr, double Ca_cyto, double Ca_nsr)
{
    // Formulation from Shiferaw et al. 2003, Biophys J 85:3666-3686 
    sr->Jleak = sr->Gleak * p.rleak * ( (Ca_nsr*Ca_nsr)/( (Ca_nsr*Ca_nsr) + (p.Kleak*p.Kleak) ) )*(Ca_nsr - Ca_cyto);    
}
// End Jup and Jleak ===================================================================//

// Dyad functions ========================================================================
// RyR
void set_RyR_rates(Cell_params p, Dyad_variables *d, double Ca_ds)
{
    d->KCO = d->RyR_Po * p.RyR_Po * pow(Ca_ds, p.RyR_power);
    d->KOC = p.RyR_Koc;

    d->KAI = d->mi_al;
    d->KIA = d->mi_b; 
}


void set_and_update_monomer_state(Cell_params p, Dyad_variables *d, double Ca_jsr, double dt)
{
    d->csqn         = (p.Bcsqn*p.Kcsqn)/(Ca_jsr + p.Kcsqn);
    d->csqn_ca      = p.Bcsqn - d->csqn;

    d->mon_ss       = 1/(1.0 + exp(-6.5*(d->csqn-6.37)));
    d->mon_al       = d->mon_ss/p.RyR_monomer_tau;
    d->mon_b        = (1-d->mon_ss)/(p.RyR_monomer_beta_tau);

    d->Monomer      = d->Monomer + dt * ( d->mon_al*(1-d->Monomer) - d->mon_b * d->Monomer);
    
    d->mi_ss        = 1/(1.0 + exp(p.RyR_monomer_grad*12.0*(d->Monomer-0.5)));
    d->mi_al        = (1-d->mi_ss)/p.RyR_mi_tau; // alpha is transition to mi (not away from it)
    d->mi_b         = d->mi_ss/(p.RyR_mi_beta_tau);
}

void comp_Krel(Cell_params p, Dyad_variables *d, double NRyR_O)
{
    d->Krel = NRyR_O * (p.rRyR/(1e9*d->vol_ds));
}

// LTCC
void comp_ICaL_bar(Cell_params p, Dyad_variables *d, double Ca_ds, double Vm)
{
    d->z        =  Vm*p.FRT;  // (Vm*F)(R*T)

    if (Ca_ds > 40) d->Ca_eff = 40; // maximum Ca "seen" by LTCC || for cleanliness
    else d->Ca_eff = Ca_ds;

    d->ICaL_bar = (1.0/(1e9*d->vol_ds)) * 4* p.rLTCC * d->z * p.F * ( (0.5 * p.gammaCa * d->Ca_eff*1e-3 * exp(2*d->z) -p.gammaCa*p.cao)/(exp(2*d->z) - 1)); // Ca_eff converted to mM
}

void set_LTCC_rates(Cell_params p, Dyad_variables *d, double Ca_ds, double Vm)
{
    // Voltage activation gate 
    d->ICaL_va_ss                   = 1.0/(1 + exp(-(Vm-5.0)/6.24) );  // Steady-state
    if (Vm != 5.00)
    {
        d->ICaL_va_tau              = d->ICaL_va_ss*(1-exp(-(Vm-5.0)/6.24))/(0.035*(Vm-5.0));  // Time constant
    }
    else d->ICaL_va_tau             = d->ICaL_va_ss*(1-exp(-(1e-10)/6.24))/(0.035*(1e-10));

    d->ICaL_va_al_01                = d->ICaL_va_ss/d->ICaL_va_tau;         // Rate from state va0 to va1 (V-dependent)
    d->ICaL_va_b_01                 = (1-d->ICaL_va_ss)/d->ICaL_va_tau;     // Rate from state va1 to va0
    d->ICaL_va_al_12                = p.ICaL_Por * d->LTCC_Po;              // Rate from va1 to va2 (V-independent)
    d->ICaL_va_b_12                 = p.ICaL_Pcr;                           // Rate from va2 to va1 (V-independent)

    // Voltage inactivation gate
    d->ICaL_vi_ss                   = 1.0/(1 + exp((Vm - (-32.06))/8.6) ); // Steady-state 
    d->ICaL_vi_tau                  = 1.0/(0.0197*exp(- (0.0337*(Vm - (-7)))*(0.0337*(Vm - (-7))) ) + 0.02 );  // Time constant
    d->ICaL_vi_al                   = d->ICaL_vi_ss/d->ICaL_vi_tau;
    d->ICaL_vi_b                    = (1-d->ICaL_vi_ss)/d->ICaL_vi_tau;

    // Ca dependent inactivation gate
    d->Ca_Ca_bar                    = Ca_ds/p.ICaL_Ca_bar;
    d->ICaL_ci_tau                  = 15;
    d->ICaL_ci_ss                   = 1/(1 + d->Ca_Ca_bar*d->Ca_Ca_bar);
    d->ICaL_ci_al                   = d->ICaL_ci_ss/d->ICaL_ci_tau;
    d->ICaL_ci_b                    = (1-d->ICaL_ci_ss)/d->ICaL_ci_tau;
}
// End dyad functions ==================================================================//

// Membrane fluxes =======================================================================
void compute_IMEM_Struct(Cell_params p, CRU_averages cru, Current_variables *c)
{
    float factor    = p.N_mem_dyads; // average per voxel -> total per dyad, so that it can be multiplied by Ntotal dyads to get total flux/current

    c->INaCa      =  factor * compute_current_from_flux(p, cru.JNACA, 1, p.vcyt_CRU); // NOTE: 1 is passed as valence

    c->ICab       =  factor * compute_current_from_flux(p, cru.JCAB, 2, p.vcyt_CRU); // NOTE: 2 is passed as valence

    c->ICap       =  factor * compute_current_from_flux(p, cru.JCAP, 2, p.vcyt_CRU); // NOTE: 2 is passed as valence
}

double compute_current_from_flux(Cell_params p, double flux, int valence, double vol)
{
    double I; // current, A/F
    I = flux * (1e6/p.Cm) * valence * p.F * vol * p.Ntot_CRUs;
    return I; 
}

void compute_JMEM_struct(Cell_params p, Membrane_fluxes *mem, double Ca_cyto, double Ca_ss, double Vm)
{
    mem->JNaCa       = mem->GNaCa * (1-p.SS_prop)*comp_JNaCa(p, mem, Ca_cyto, Vm);
    mem->JNaCa_ss    = 0;

    mem->JCab        = mem->GCab * (1-p.SS_prop)*comp_JCab(p, Ca_cyto, Vm);
    mem->JCab_ss     = 0;

    mem->JCap        = mem->GCap * (1-p.SS_prop)*comp_JCap(p, Ca_cyto);
    mem->JCap_ss     = 0;

    mem->JCa         = mem->JNaCa - mem->JCab - mem->JCap;
    mem->JCa_ss      = 0;
}

double comp_JNaCa(Cell_params p, Membrane_fluxes *m, double Cai, double Vm)
{
    // Formulation from Shannon et al 2004, Biophys J 87:3351-3371
    double JNaCa;

    m->z = Vm*p.FRT;  // (Vm*F)(R*T)
    m->Ka = 1/(1+pow((p.INaCa_Kda/Cai),3));

    m->t1 = p.INaCa_KCai * pow(p.nao,3) * (1 + pow((p.nai/p.INaCa_KNai),3));
    m->t2 = pow(p.INaCa_KNao,3) * Cai * (1 + (Cai/p.INaCa_KCai));
    m->t3 = (p.INaCa_KCao*pow(p.nai,3)) + (pow(p.nai,3) * p.cao) + (pow(p.nao,3) * Cai);

    m->denomenator = (m->t1 + m->t2 + m->t3) * (1 + p.INaCa_Ksat * exp((p.INaCa_eta-1)*m->z));
    m->numerator = p.rNaCa * m->Ka * ( (exp(p.INaCa_eta*m->z) * pow(p.nai,3) * p.cao) - (exp((p.INaCa_eta-1)*m->z) * pow(p.nao,3) * Cai )  );

    JNaCa = m->numerator/m->denomenator;

    return JNaCa;
}

double comp_JCab(Cell_params p, double Cai, double Vm)
{
    double JCab;

    double ecab = ((p.R*p.T)/(2*p.F))*log(p.cao/(1e-3*Cai)); // convert Cai to mM 
    JCab        = p.rCab*(Vm-ecab);
    return JCab;
}

double comp_JCap(Cell_params p, double Cai)
{
    double JCap;
    JCap        = (p.rCap*Cai)/(0.5 + Cai);
    return JCap;
}
// End membrane fluxes =================================================================//

// Buffering =============================================================================
void comp_buffering(Cell_params p, double *Bcyto, double *Bss, double *Bjsr, double Ca_cyto, double Ca_ss, double Ca_jsr)
{
    buffering_cyto(p, Bcyto, Ca_cyto);
    buffering_subspace(p, Bss, Ca_ss);
    buffering_jSR(p, Bjsr, Ca_jsr);
}

void buffering_cyto(Cell_params p, double *Bcyto, double Ca)
{
    *Bcyto   =  (p.Kcam*p.Bcam)/(pow(Ca + p.Kcam, 2));
    *Bcyto   += (p.Kbsr*p.Bbsr)/(pow(Ca + p.Kbsr, 2));
    *Bcyto   += (p.Kmca*p.Bmca)/(pow(Ca + p.Kmca, 2));
    *Bcyto   += (p.Kmmg*p.Bmmg)/(pow(Ca + p.Kmmg, 2));
    *Bcyto   += 1;
    *Bcyto   = 1/(*Bcyto);
}

void buffering_subspace(Cell_params p, double *Bss, double Ca)
{
    *Bss   =  (p.Kcam*p.Bcam)/(pow(Ca + p.Kcam, 2));
    *Bss   += (1.5*p.Kbsr*p.Bbsr)/(pow(Ca + 1.5*p.Kbsr, 2));
    *Bss   += (0.5*p.Kmca*0.5*p.Bmca)/(pow(Ca + 0.5*p.Kmca, 2));
    *Bss   += (1.5*p.Kmmg*p.Bmmg)/(pow(Ca + 1.5*p.Kmmg, 2));
    *Bss   *= 0.1;
    *Bss   += 1;
    *Bss   = 1/(*Bss);
}

void buffering_jSR(Cell_params p, double *Bjsr, double Ca)
{
    *Bjsr    = 1/( 1 + (p.Kcsqn*p.Bcsqn)/pow((p.Kcsqn + 1e-3*Ca),2)); // 1e-3 is to convert Ca_jsr to mM (buffering is dimensionless; params are in mM)
}
// End Buffering =======================================================================//

// Array allocation ======================================================================
void Ca_array_allocation_compart(int Ncell, Ca_variables *Ca)
{
    Ca->ds          = new double [Ncell];
    Ca->ss          = new double [Ncell];
    Ca->cyto        = new double [Ncell];
    Ca->nsr         = new double [Ncell];
    Ca->jsr         = new double [Ncell];

    Ca->ss_reac     = new double [Ncell];
    Ca->cyto_reac   = new double [Ncell];
    Ca->nsr_reac    = new double [Ncell];
    Ca->jsr_reac    = new double [Ncell];

    Ca->bcyto       = new double [Ncell];
    Ca->bss         = new double [Ncell];
    Ca->bjsr        = new double [Ncell];
}

void Ca_array_allocation_struct(int NCYTO, int NSR, int NDYADS, Ca_variables *Ca)
{
    Ca->ds          = new double [NDYADS];
    Ca->ss          = new double [NCYTO];
    Ca->cyto        = new double [NCYTO];
    Ca->nsr         = new double [NSR];
    Ca->jsr         = new double [NDYADS];

    Ca->ss_reac     = new double [NCYTO];
    Ca->cyto_reac   = new double [NCYTO];
    Ca->nsr_reac    = new double [NSR];
    Ca->jsr_reac    = new double [NDYADS];

    Ca->bcyto       = new double [NCYTO];
    Ca->bss         = new double [NCYTO];
    Ca->bjsr        = new double [NDYADS];
}


void Ca_array_deallocation(Ca_variables *Ca)
{
    
    delete  [] Ca->ds;
    delete  [] Ca->ss;
    delete  [] Ca->cyto;
    delete  [] Ca->jsr;
    delete  [] Ca->nsr;
    
    delete  [] Ca->ss_reac;
    delete  [] Ca->cyto_reac;
    delete  [] Ca->nsr_reac;
    delete  [] Ca->jsr_reac;

    delete  [] Ca->bcyto;
    delete  [] Ca->bss;
    delete  [] Ca->bjsr;
}

void Dyad_array_allocation(Dyad_variables *d)
{
    d->RyR_state    = new int [d->NRyR];
    d->va_state     = new int [d->NLTCC];
    d->vi_state     = new int [d->NLTCC];
    d->ci_state     = new int [d->NLTCC];
}

void Dyad_array_deallocation(Dyad_variables *d)
{
    delete [] d->RyR_state;
    delete [] d->va_state;
    delete [] d->vi_state;
    delete [] d->ci_state;
}
// End Array allocation ================================================================//

// Stochastic integration ================================================================
void update_RyR_stochastic(Dyad_variables *d, double dt)
{
    d->NRyR_O1 = d->NRyR_C1 = d->NRyR_O2 = d->NRyR_C2 = 0; // zero total state occupancy

    for (int i = 0; i < d->NRyR; i++)
    {
        d->rand = d->mtrand1(); // assign rand to  randomly generated number
        if (d->rand > 1.0) printf("RAND GREATER THAN 1");
        else if (d->rand < 0.0) printf("RAND LESS THAN 0");

        switch (d->RyR_state[i])
        {    
            case 0: // if currently in closed state, not inactivated (C1)
                if (d->rand <= d->KCO*dt) // if random number is less than probability of transition within dt, do the transition
                {
                    d->RyR_state[i] = 1; // do transition
                    d->NRyR_O1 ++;          // count transition
                    break;                  // break case statement
                }
                else if (d->rand <= (d->KCO + d->KAI)*dt) // else, if the random number is between the prob of transition 1 and 1+2, do transition 2
                {
                    d->RyR_state[i] = 2; // do transition -> state "2" is C2
                    d->NRyR_C2 ++;          // count transition
                    break;                  // break case statement
                } 
                else if (d->rand <= 1) // otherwise, same state
                {
                    d->RyR_state[i] = 0; // no transition
                    d->NRyR_C1 ++;          // count it as in closed state. No need to set state, as already there (but will anyway!)
                    break;
                }

            case 1: // if currently in open state, not inactivated (O1)
                if (d->rand <= d->KOC*dt) // if random number is less than probability of transition within dt, do the transition
                {   
                    d->RyR_state[i] = 0; // do transition
                    d->NRyR_C1 ++;          // count transition
                    break;                  // break case statement
                }
                else if (d->rand <= (d->KOC + d->KAI)*dt) // else, if the random number is between the prob of transition 1 and 1+2, do transition 2
                {
                    d->RyR_state[i] = 3; // do transition -> state "3" is O2
                    d->NRyR_O2 ++;          // count transition
                    break;                  // break case statement
                }
                else if (d->rand <= 1) // 
                {
                    d->RyR_state[i] = 1; // no transition
                    d->NRyR_O1 ++;          // count it as in closed state. No need to set state, as already there (but will anyway!)
                    break;
                }

            case 2: // if currently in closed state, inactivated (C2)
                if (d->rand <= d->KCO*dt) // if random number is less than probability of transition within dt, do the transition
                {
                    d->RyR_state[i] = 3; // do transition
                    d->NRyR_O2 ++;          // count transition
                    break;                  // break case statement
                }
                else if (d->rand <= (d->KCO + d->KIA)*dt) // else, if the random number is between the prob of transition 1 and 1+2, do transition 2
                {
                    d->RyR_state[i] = 0; // do transition -> state "2" is C2
                    d->NRyR_C1 ++;          // count transition
                    break;                  // break case statement
                }
                else if (d->rand <= 1) // otherwise, same state
                {
                    d->RyR_state[i] = 2; // no transition
                    d->NRyR_C2 ++;          // count it as in closed state. No need to set state, as already there (but will anyway!)
                    break;
                }

            case 3: // if currently in open state, inactivated (O2)
                if (d->rand <= d->KOC*dt) // if random number is less than probability of transition within dt, do the transition
                {
                    d->RyR_state[i] = 2; // do transition
                    d->NRyR_C2 ++;          // count transition
                    break;                  // break case statement
                }
                else if (d->rand <= (d->KOC + d->KIA)*dt) // else, if the random number is between the prob of transition 1 and 1+2, do transition 2
                {
                    d->RyR_state[i] = 1; // do transition -> state "3" is O2
                    d->NRyR_O1 ++;          // count transition
                    break;                  // break case statement
                }
                else if (d->rand <= 1) // 
                {
                    d->RyR_state[i] = 3; // no transition
                    d->NRyR_O2 ++;          // count it as in closed state. No need to set state, as already there (but will anyway!)
                    break;
                }
        } // end switch 
    } // end for
} // end RyR stochastic

// LTCC stochastic
void update_LTCC_stochastic(Dyad_variables *d, double dt)
{
    d->NLTCC_O = 0;

    for (int i = 0; i < d->NLTCC; i++)
    {
        d->rand = d->mtrand1(); // assign rand to  randomly generated number
        if (d->rand > 1.0) printf("RAND GREATER THAN 1");
        else if (d->rand < 0.0) printf("RAND LESS THAN 0");
    
        // This works by cyling through states, if no transition occurs in first state, check for transition in second state, then third
        if (d->va_state[i] == 0) // closed state 0 voltage activation
        {
            if (d->rand <= d->ICaL_va_al_01 * dt) d->va_state[i] = 1; // if rand if less than alpha rate va state 0-1, transition to state 1
            else
            {
                if (d->vi_state[i] == 0) // if voltage inactivation state is in 0
                {
                    if (d->rand <= (d->ICaL_vi_al + d->ICaL_va_al_01) * dt) d->vi_state[i] = 1;
                    else
                    {
                        if (d->ci_state[i] == 0)
                        {
                            if (d->rand <= (d->ICaL_ci_al + d->ICaL_vi_al + d->ICaL_va_al_01) * dt) d->ci_state[i] = 1;
                        }
                        else if (d->ci_state[i] == 1)
                        {
                            if (d->rand <= (d->ICaL_ci_b + d->ICaL_vi_al + d->ICaL_va_al_01) * dt) d->ci_state[i] = 0;
                        }
                    }
                }
                else if (d->vi_state[i] == 1)
                {
                    if (d->rand <= (d->ICaL_vi_b + d->ICaL_va_al_01) * dt) d->vi_state[i] = 0;
                    else
                    {
                        if (d->ci_state[i] == 0)
                        {
                            if (d->rand <= (d->ICaL_ci_al + d->ICaL_vi_b + d->ICaL_va_al_01) * dt) d->ci_state[i] = 1;
                        }
                        else if (d->ci_state[i] == 1)
                        {
                            if (d->rand <= (d->ICaL_ci_b + d->ICaL_vi_b + d->ICaL_va_al_01) * dt) d->ci_state[i] = 0;
                        }
                    }
                }
            }
        }
        else if (d->va_state[i] == 1)
        {
            if (d->rand <= d->ICaL_va_b_01 * dt) d->va_state[i] = 0;
            else if (d->rand <= (d->ICaL_va_al_12 + d->ICaL_va_b_01) * dt) d->va_state[i] = 2;
            else
            {
                if (d->vi_state[i] == 0)
                {
                    if (d->rand <= (d->ICaL_vi_al + d->ICaL_va_al_12 + d->ICaL_va_b_01) * dt) d->vi_state[i] = 1;
                    else
                    {
                        if (d->ci_state[i] == 0)
                        {
                            if (d->rand <= (d->ICaL_ci_al + d->ICaL_vi_al + d->ICaL_va_al_12 + d->ICaL_va_b_01) * dt) d->ci_state[i] = 1;
                        }
                        else if (d->ci_state[i] == 1)
                        {
                            if (d->rand <= (d->ICaL_ci_b + d->ICaL_vi_al + d->ICaL_va_al_12 + d->ICaL_va_b_01) * dt) d->ci_state[i] = 0;
                        }
                    }
                }
                else if (d->vi_state[i] == 1)
                {
                    if (d->rand <= (d->ICaL_vi_b + d->ICaL_va_al_12 + d->ICaL_va_b_01) * dt) d->vi_state[i] = 0;
                    else
                    {
                        if (d->ci_state[i] == 0)
                        {
                            if (d->rand <= (d->ICaL_ci_al + d->ICaL_vi_b + d->ICaL_va_al_12 + d->ICaL_va_b_01) * dt) d->ci_state[i] = 1;
                        }
                        else if (d->ci_state[i] == 1)
                        {
                            if (d->rand <= (d->ICaL_ci_b + d->ICaL_vi_b + d->ICaL_va_al_12 + d->ICaL_va_b_01) * dt) d->ci_state[i] = 0;
                        }
                    }
                }
            }
        }
        else if (d->va_state[i] == 2)
        {
            if (d->rand <= d->ICaL_va_b_12*dt) d->va_state[i] = 1;
            else
            {
                if (d->vi_state[i] == 0)
                {
                    if (d->rand <= (d->ICaL_vi_al + d->ICaL_va_b_12)*dt) d->vi_state[i] = 1;
                    else
                    {
                        if (d->ci_state[i] == 0)
                        {
                            if (d->rand <= (d->ICaL_ci_al + d->ICaL_vi_al + d->ICaL_va_b_12)*dt) d->ci_state[i] = 1;
                        }
                        else if (d->ci_state[i] == 1)
                        {
                            if (d->rand <= (d->ICaL_ci_b + d->ICaL_vi_al + d->ICaL_va_b_12)*dt) d->ci_state[i] = 0;
                        }
                    }
                }
                else if (d->vi_state[i] == 1)
                {
                    if (d->rand <= (d->ICaL_vi_b + d->ICaL_va_b_12)*dt) d->vi_state[i] = 0;
                    else
                    {
                        if (d->ci_state[i] == 0)
                        {
                            if (d->rand <= (d->ICaL_ci_al + d->ICaL_vi_b + d->ICaL_va_b_12) * dt) d->ci_state[i] = 1;
                        }
                        else if (d->ci_state[i] == 1)
                        {
                            if (d->rand <= (d->ICaL_ci_b + d->ICaL_vi_b + d->ICaL_va_b_12 ) * dt) d->ci_state[i] = 0;
                        }
                    }
                }
            }
        }

        if (d->va_state[i] == 2 && d->vi_state[i] == 1 && d->ci_state[i] == 1) d->NLTCC_O ++; // if open state 2, inactivation state 1 for v and Ca, then channel is open
    } // end for
} // End LTCC stochastic
