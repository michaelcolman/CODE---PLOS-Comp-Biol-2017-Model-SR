// Takes cross section data and creates vtk of cropped

#include <stdio.h>


#define NX (100)
#define NY (52)
#define NZ (52)

#define NX2 (50)
#define NY2 (26)
#define NZ2 (52)

float Var_in[NX][NY][NZ];
//double Var_out[NX2][NY2][NZ2];

int main(int argc, char *argv[])
{
    FILE *in;
    FILE *in2;
    FILE *out;
    int i, j, k;
    float temp;

    int time;
    time = atoi(argv[2]);

    char *str_in;
    str_in = malloc (50*sizeof(char));
    sprintf(str_in, "%s_1D_output_%04d.dat", argv[1], time);
    in = fopen(str_in, "r");
    printf("%s\n", str_in);

    str_in = argv[3];
    in2 = fopen(str_in, "r");
    

    for (k = 0; k < NZ; k++)
    {
        for (j = 0; j < NY; j++)
        {
            for (i = 0; i < NX; i++)
            {
                    fscanf(in2, "%f ", &temp);
                    if (temp > 0) fscanf(in, "%f ", &Var_in[i][j][k]);
                    else Var_in[i][j][k] = -100;
                    //if (Var_in[i][j][k] > 0) printf("%f\n", Var_in[i][j][k]);
            }
        }
    }


    char *str_out;
    str_out = malloc (50*sizeof(char));
    sprintf(str_out, "%s_output_%04d.vtk", argv[1], time);    

    out = fopen(str_out, "wt");

    fprintf (out, "# vtk DataFile Version 3.0\n");
    fprintf (out, "vtk output\n");
    fprintf (out, "ASCII\n");
    fprintf (out, "DATASET STRUCTURED_POINTS\n");
    fprintf (out, "DIMENSIONS %d %d %d\n",NX2,NY2,NZ2);
    fprintf (out, "SPACING 1 1 1\n");
    fprintf (out, "ORIGIN 0 0 0\n");
    fprintf (out, "POINT_DATA %d\n", NX2*NY2*NZ2);
    fprintf (out, "SCALARS ImageFile float 1\n");
    fprintf (out, "LOOKUP_TABLE default\n");

    for (k = 0; k < NZ2; k++)
    {
        for (j = 0; j < NY2; j++)
        {
            for (i = 0; i < NX2; i++)
            {
                    fprintf(out, "%f ", Var_in[i][j][k]);
            }
            fprintf(out, "\n");
        }
    fprintf(out, "\n");
    }

    fclose(out);

} // end main
